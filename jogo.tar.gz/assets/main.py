"""Ponto de entrada do jogo, igual para computador, web (pygbag) e executável (PyInstaller)."""

import asyncio

import pygame  # O pygbag precisa ver este import aqui para incluir o Pygame na versão web.

from src.jogo import Jogo
from src.sistemas.recursos import registrar_erro


async def main():
    jogo = Jogo()
    try:
        await jogo.rodar()
    except Exception:
        registrar_erro()
        raise
    pygame.quit()


# Precisa ser a última linha: no navegador, o que vier depois não roda.
asyncio.run(main())
