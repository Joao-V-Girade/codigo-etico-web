"""Constantes técnicas do jogo. Textos, nomes e cores ficam em jogo/data/, nunca aqui."""

LARGURA_TELA = 320
ALTURA_TELA = 180
FPS = 60

# Liga as teclas de depuração. Só funcionam fora do navegador.
DEBUG = True
