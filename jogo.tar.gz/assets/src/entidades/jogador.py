"""A Ada andando pelo mapa, em 4 direções e com colisão só nos pés, como em RPGs vistos de cima."""

import pygame

from src.sistemas.entrada import esta_pressionada
from src.sistemas.recursos import carregar_imagem

VELOCIDADE = 72  # pixels por segundo
QUADROS_POR_SEGUNDO = 8
LARGURA_PES = 12
ALTURA_PES = 8
ALTURA_SPRITE = 30
DIRECOES = {"cima": (0, -1), "baixo": (0, 1), "esquerda": (-1, 0), "direita": (1, 0)}


class Jogador:
    def __init__(self, coluna, linha, tamanho_tile):
        self.quadros = {
            direcao: [
                carregar_imagem(f"assets/sprites/ada/ada_mapa_{direcao}_{nome}.png")
                for nome in ("parada", "passo_1", "parada", "passo_2")
            ]
            for direcao in DIRECOES
        }
        self.direcao = "baixo"
        self.tempo = 0.0
        self.andando = False
        self.colocar_em(coluna, linha, tamanho_tile)

    def colocar_em(self, coluna, linha, tamanho_tile, direcao=None):
        """Põe os pés da Ada no centro do tile pedido."""
        self.x = float(coluna * tamanho_tile + (tamanho_tile - LARGURA_PES) // 2)
        self.y = float(linha * tamanho_tile + (tamanho_tile - ALTURA_PES) // 2)
        if direcao:
            self.direcao = direcao

    @property
    def pes(self):
        return pygame.Rect(int(self.x), int(self.y), LARGURA_PES, ALTURA_PES)

    def direcao_pressionada(self):
        for direcao in DIRECOES:
            if esta_pressionada(direcao):
                return direcao
        return None

    def mover(self, dt, bloqueado):
        """bloqueado é uma função que recebe um retângulo e diz se ele bate em algo."""
        direcao = self.direcao_pressionada()
        self.andando = direcao is not None
        if not direcao:
            self.tempo = 0.0
            return
        self.direcao = direcao
        self.tempo += dt
        dx, dy = DIRECOES[direcao]
        novo_x = self.x + dx * VELOCIDADE * dt
        novo_y = self.y + dy * VELOCIDADE * dt
        if not bloqueado(pygame.Rect(int(novo_x), int(novo_y), LARGURA_PES, ALTURA_PES)):
            self.x, self.y = novo_x, novo_y

    # ---------- Andar sozinho, nas cenas (cenas/roteiro.py) ----------
    def tile(self, tamanho_tile):
        centro = self.pes.center
        return centro[0] // tamanho_tile, centro[1] // tamanho_tile

    def alvo_do_tile(self, coluna, linha, tamanho_tile):
        """A posição (x, y) que deixa os pés no centro do tile, a mesma de colocar_em."""
        return (float(coluna * tamanho_tile + (tamanho_tile - LARGURA_PES) // 2),
                float(linha * tamanho_tile + (tamanho_tile - ALTURA_PES) // 2))

    def andar_para(self, alvo, dt, velocidade=1.0):
        """Dá um passo em direção ao alvo, primeiro na horizontal e depois na vertical.

        Devolve True quando chega. A animação de andar é a mesma de quando o jogador aperta as setas.
        """
        passo = VELOCIDADE * velocidade * dt
        dx, dy = alvo[0] - self.x, alvo[1] - self.y
        if abs(dx) > 0.01:
            self.direcao = "direita" if dx > 0 else "esquerda"
            self.x += max(-passo, min(passo, dx))
        elif abs(dy) > 0.01:
            self.direcao = "baixo" if dy > 0 else "cima"
            self.y += max(-passo, min(passo, dy))
        chegou = abs(alvo[0] - self.x) <= 0.01 and abs(alvo[1] - self.y) <= 0.01
        self.andando = not chegou
        self.tempo = self.tempo + dt if self.andando else 0.0
        if chegou:
            self.x, self.y = alvo
        return chegou

    def parar(self):
        self.andando = False
        self.tempo = 0.0

    def ponto_a_frente(self):
        """O ponto logo à frente dos pés: é ali que a Ada interage com as coisas."""
        dx, dy = DIRECOES[self.direcao]
        centro = self.pes.center
        return centro[0] + dx * 12, centro[1] + dy * 12

    def desenhar(self, tela, camera):
        indice = int(self.tempo * QUADROS_POR_SEGUNDO) % 4 if self.andando else 0
        imagem = self.quadros[self.direcao][indice]
        # Alinha a imagem pelos pés, porque alguns quadros têm alturas diferentes.
        x = self.pes.centerx - 12 - camera[0]
        y = self.pes.bottom - ALTURA_SPRITE - camera[1]
        tela.blit(imagem, (x, y))
