"""Personagem do mapa. As falas de cada um ficam no arquivo do mapa, em "dialogos".

Nas cenas (cenas/roteiro.py), o NPC também pode andar: ele sai do tile do mapa e vai até outro.
Como os NPCs ainda têm um desenho só, o passo aparece como um balanço leve.
"""

import pygame

from src.sistemas.recursos import carregar_imagem

VELOCIDADE = 72  # pixels por segundo, a mesma da Ada
BALANCO_POR_SEGUNDO = 8


class Npc:
    def __init__(self, dados, tamanho_tile):
        self.id = dados["id"]
        self.condicao = dados.get("condicao")  # Sem condição, o NPC está sempre no mapa.
        self.dialogos = dados["dialogos"]
        self.imagem = carregar_imagem(f"assets/sprites/{dados['sprite']}.png")
        self.tile_px = tamanho_tile
        self.andando = False
        self.tempo = 0.0
        self.colocar_em(dados["x"], dados["y"])

    def colocar_em(self, coluna, linha):
        self.x, self.y = self.alvo_do_tile(coluna, linha)

    @property
    def corpo(self):
        """O que bloqueia a passagem é só a parte de baixo, como na Ada."""
        return pygame.Rect(int(self.x), int(self.y), self.tile_px - 4, self.tile_px - 4)

    @property
    def base(self):
        return self.corpo.bottom

    # ---------- Andar sozinho, nas cenas ----------
    def tile(self, tamanho_tile=None):
        centro = self.corpo.center
        return centro[0] // self.tile_px, centro[1] // self.tile_px

    def alvo_do_tile(self, coluna, linha, tamanho_tile=None):
        return float(coluna * self.tile_px + 2), float(linha * self.tile_px + 4)

    def andar_para(self, alvo, dt, velocidade=1.0):
        """Mesma regra da Ada: horizontal primeiro, depois vertical. Devolve True ao chegar."""
        passo = VELOCIDADE * velocidade * dt
        dx, dy = alvo[0] - self.x, alvo[1] - self.y
        if abs(dx) > 0.01:
            self.x += max(-passo, min(passo, dx))
        elif abs(dy) > 0.01:
            self.y += max(-passo, min(passo, dy))
        chegou = abs(alvo[0] - self.x) <= 0.01 and abs(alvo[1] - self.y) <= 0.01
        self.andando = not chegou
        self.tempo = self.tempo + dt if self.andando else 0.0
        if chegou:
            self.x, self.y = alvo
        return chegou

    def parar(self):
        self.andando = False
        self.tempo = 0.0

    def desenhar(self, tela, camera):
        x = self.corpo.centerx - self.imagem.get_width() // 2 - camera[0]
        y = self.corpo.bottom - self.imagem.get_height() - camera[1]
        if self.andando and int(self.tempo * BALANCO_POR_SEGUNDO) % 2:
            y -= 1
        tela.blit(self.imagem, (x, y))
