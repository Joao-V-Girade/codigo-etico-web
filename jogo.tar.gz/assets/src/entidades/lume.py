"""O Lume, que segue a Ada pelo mapa flutuando, com as hélices girando."""

import math

from src.sistemas.recursos import carregar_imagem

DISTANCIA_ATRAS = 18
SUAVIDADE = 4.0
ALTURA_DE_VOO = 34
QUADROS_POR_SEGUNDO = 10


class Lume:
    def __init__(self, x, y):
        self.quadros = [carregar_imagem("assets/sprites/lume/lume_normal.png"), carregar_imagem("assets/sprites/lume/lume_helice.png")]
        self.x = float(x)
        self.y = float(y)
        self.tempo = 0.0

    def seguir(self, dt, jogador):
        self.tempo += dt
        destino_x = jogador.pes.centerx - 8 - DISTANCIA_ATRAS
        destino_y = jogador.pes.bottom - ALTURA_DE_VOO
        fator = min(1.0, SUAVIDADE * dt)
        self.x += (destino_x - self.x) * fator
        self.y += (destino_y - self.y) * fator

    def desenhar(self, tela, camera):
        quadro = self.quadros[int(self.tempo * QUADROS_POR_SEGUNDO) % 2]
        balanco = math.sin(self.tempo * 3) * 2
        tela.blit(quadro, (int(self.x) - camera[0], int(self.y + balanco) - camera[1]))
