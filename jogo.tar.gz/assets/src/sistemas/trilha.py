"""Escolhe a música sozinha, olhando o que está na tela (P23).

O jogo chama atualizar_trilha(jogo) a cada quadro, e nenhuma outra parte precisa saber de música. Pedir a
música que já toca não faz nada, então ela não recomeça ao abrir um menu ou uma fala.
"""

from src.cenas.batalha import CenaBatalha
from src.cenas.titulo import CenaTitulo
from src.sistemas import audio

FASE_DO_FINAL = "final_demo"


def atualizar_trilha(jogo):
    audio.definir_volume(jogo.estado.configuracoes["volume"])
    luta = next((cena for cena in reversed(jogo.cenas) if isinstance(cena, CenaBatalha)), None)
    if luta:
        # Na derrota, só o som da derrota: a música volta com "Tentar de novo".
        if luta.modo == "derrota":
            audio.tocar_musica(None)
        else:
            audio.tocar_musica_da_luta(luta.id_inimigo, luta.luta.forma)
    elif jogo.efeitos.ativo:
        audio.tocar_musica(None)  # A Falha e o apagão: o silêncio faz parte da cena.
    elif isinstance(jogo.cenas[0], CenaTitulo):
        audio.tocar_musica_do_mapa("titulo")
    elif jogo.mundo is None:
        audio.tocar_musica_do_mapa("titulo")  # Nome, dificuldade e abertura.
    elif jogo.estado.flags.get("fase") == FASE_DO_FINAL:
        audio.tocar_musica_do_mapa("final")
    else:
        audio.tocar_musica_do_mapa(jogo.mundo.mapa.nome)
