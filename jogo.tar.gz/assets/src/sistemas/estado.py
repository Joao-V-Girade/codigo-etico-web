"""Tudo o que o jogador já fez: flags da história, itens, nome e configurações. Não depende do Pygame."""

# Configurações do menu de pausa (D51). A demo não salva, então elas valem só até fechar o jogo.
CONFIGURACOES_PADRAO = {"velocidade_texto": "normal", "flashes": True, "volume": 100}


class Estado:
    def __init__(self, nome="ADA", modo_historia=False):
        self.nome = nome
        self.modo_historia = modo_historia
        self.flags = {}
        self.itens = {}
        self.arquivo = set()
        self.configuracoes = dict(CONFIGURACOES_PADRAO)
        # Pedidos que as falas fazem e que outra parte do jogo atende depois.
        self.pedido_de_batalha = None
        self.pedido_de_mapa = None
        self.pedido_de_fase = None
        self.pedido_de_cena = None
        self.pedido_de_tela = None
        self.efeito_tela = None

    def condicao_ok(self, condicao):
        """Confere uma condição do roteiro, como {"tem_lume": true} ou {"dante_confianca": {"min": 2}}.

        true quer dizer "tem algum valor": {"zim_resultado": true} vale para "restaurado" e "destruido".
        false e null querem dizer "ainda não tem valor".
        """
        if not condicao:
            return True
        for chave, esperado in condicao.items():
            if chave == "tem_item_nao":
                if esperado in self.itens:
                    return False
                continue
            valor = self.flags.get(chave)
            if isinstance(esperado, dict):
                numero = valor or 0
                if "min" in esperado and numero < esperado["min"]:
                    return False
                if "max" in esperado and numero > esperado["max"]:
                    return False
            elif esperado is True:
                if not valor:
                    return False
            elif esperado is False or esperado is None:
                if valor:
                    return False
            elif valor != esperado:
                return False
        return True

    def aplicar_efeitos(self, efeitos):
        """Aplica o campo "efeitos" de uma fala ou escolha."""
        if not efeitos:
            return
        self.flags.update(efeitos.get("definir", {}))
        for chave, quantidade in efeitos.get("somar", {}).items():
            self.flags[chave] = self.flags.get(chave, 0) + quantidade
        if "dar_item" in efeitos:
            item = efeitos["dar_item"]
            self.itens[item] = self.itens.get(item, 0) + efeitos.get("quantidade", 1)
        for item in efeitos.get("dar_itens", []):
            self.itens[item] = self.itens.get(item, 0) + 1
        if "arquivo" in efeitos:
            entradas = efeitos["arquivo"]
            self.arquivo.update(entradas if isinstance(entradas, list) else [entradas])
        if "iniciar_batalha" in efeitos:
            self.pedido_de_batalha = efeitos["iniciar_batalha"]
        if "ir_para_mapa" in efeitos:
            self.pedido_de_mapa = efeitos["ir_para_mapa"]
        if "ir_para_fase" in efeitos:
            self.pedido_de_fase = efeitos["ir_para_fase"]
        if "efeito_tela" in efeitos:
            self.efeito_tela = efeitos["efeito_tela"]
        if "cena" in efeitos:
            self.pedido_de_cena = efeitos["cena"]
        if "ir_para_tela" in efeitos:
            self.pedido_de_tela = efeitos["ir_para_tela"]

    def primeira_opcao(self, opcoes):
        """De uma lista de {"condicao", "id" ou "cena"}, devolve a primeira cuja condição vale."""
        for opcao in opcoes:
            if self.condicao_ok(opcao.get("condicao")):
                return opcao
        return None

    def primeiro_dialogo(self, opcoes):
        opcao = self.primeira_opcao(opcoes)
        return opcao.get("id") if opcao else None
