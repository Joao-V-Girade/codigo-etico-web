"""Salvar e continuar o jogo (D80). Só o jogo completo salva: a demo é curta (09, seção 1).

O jogo salva nas tomadas 💾 do roteiro. O save guarda o Estado inteiro (nome, dificuldade, flags,
itens, Arquivo do Lume e Configurações) e o lugar da Ada no mapa.

- montar_save() e ler_save() são funções puras, testadas com pytest.
- gravar() e carregar() escolhem onde guardar: no computador e no .exe, um arquivo save.json na
  pasta do usuário. No navegador, o armazenamento da própria página (localStorage), que continua
  lá depois de fechar a aba.
"""

import json
import os
import sys

from src.sistemas.estado import CONFIGURACOES_PADRAO, Estado
from src.sistemas.recursos import EH_WEB

VERSAO_DO_SAVE = 1
CHAVE_WEB = "codigo_etico_save"


# ---------- Funções puras ----------
def montar_save(estado, mapa, coluna, linha, direcao="baixo"):
    """Transforma o jogo de agora num dicionário que pode virar JSON."""
    return {
        "versao_do_save": VERSAO_DO_SAVE,
        "nome": estado.nome,
        "modo_historia": estado.modo_historia,
        # As flags "dev_" são de teste (D99): ao continuar, o robô da rua volta escondido.
        "flags": {nome: valor for nome, valor in estado.flags.items() if not nome.startswith("dev_")},
        "itens": dict(estado.itens),
        "arquivo": sorted(estado.arquivo),
        "configuracoes": dict(estado.configuracoes),
        "lugar": {"mapa": mapa, "x": coluna, "y": linha, "direcao": direcao},
    }


def ler_save(dados):
    """Faz o caminho de volta: devolve (Estado, lugar). Save estragado ou de outra versão devolve None."""
    try:
        if dados.get("versao_do_save") != VERSAO_DO_SAVE:
            return None
        estado = Estado(dados["nome"], dados["modo_historia"])
        estado.flags = dict(dados["flags"])
        estado.itens = dict(dados["itens"])
        estado.arquivo = set(dados["arquivo"])
        # Uma configuração nova, que não existia quando o jogo foi salvo, fica com o valor padrão.
        estado.configuracoes = {**CONFIGURACOES_PADRAO, **dados.get("configuracoes", {})}
        lugar = dados["lugar"]
        return estado, {"mapa": lugar["mapa"], "x": int(lugar["x"]), "y": int(lugar["y"]), "direcao": lugar.get("direcao", "baixo")}
    except (AttributeError, KeyError, TypeError, ValueError):
        return None


# ---------- Onde guardar ----------
def pasta_dos_saves():
    """No Windows, %APPDATA%\\CodigoEtico. Os testes usam CODIGO_ETICO_SAVES para não mexer no save de verdade."""
    if os.environ.get("CODIGO_ETICO_SAVES"):
        return os.environ["CODIGO_ETICO_SAVES"]
    if sys.platform == "win32" and os.environ.get("APPDATA"):
        return os.path.join(os.environ["APPDATA"], "CodigoEtico")
    return os.path.join(os.path.expanduser("~"), ".codigo_etico")


def _arquivo():
    return os.path.join(pasta_dos_saves(), "save.json")


def _armazenamento_web():
    import platform  # No pygbag, este módulo dá acesso à página (platform.window).

    return platform.window.localStorage


def gravar(dados):
    """Guarda o save. Devolve True se deu certo."""
    texto = json.dumps(dados, ensure_ascii=False)
    try:
        if EH_WEB:
            _armazenamento_web().setItem(CHAVE_WEB, texto)
        else:
            os.makedirs(pasta_dos_saves(), exist_ok=True)
            with open(_arquivo(), "w", encoding="utf-8") as arquivo:
                arquivo.write(texto)
        return True
    except Exception:  # Sem permissão, disco cheio ou navegador bloqueando: o jogo continua sem salvar.
        return False


def carregar():
    """Lê o save guardado. Devolve o dicionário, ou None se não houver save."""
    try:
        if EH_WEB:
            texto = _armazenamento_web().getItem(CHAVE_WEB)
        else:
            if not os.path.exists(_arquivo()):
                return None
            with open(_arquivo(), encoding="utf-8") as arquivo:
                texto = arquivo.read()
        return json.loads(texto) if texto else None
    except Exception:
        return None


def existe_save():
    return carregar() is not None
