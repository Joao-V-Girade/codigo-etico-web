"""Cores do jogo por nome, como "vila.laranja", lidas de data/paleta.json (D33)."""

from src.sistemas.recursos import ler_json

_paleta = None


def cor(nome):
    """Devolve a cor em texto ("#rrggbb"), o formato que o Pygame e a fonte do jogo aceitam."""
    global _paleta
    if _paleta is None:
        _paleta = ler_json("data/paleta.json")
    grupo, chave = nome.split(".")
    return _paleta[grupo][chave]
