"""Som e música (P23). O resto do jogo só diz o nome do som: tocar_som("pulo"), tocar_musica("vila").

Cada nome e o arquivo dele ficam em data/sons.json, e os arquivos, em assets/sons/ (sempre OGG, por causa da
web). O jogo nunca depende do som: sem placa de som, sem o arquivo ou com um nome desconhecido, nada acontece.
"""

import os
import time

import pygame

from src.sistemas.recursos import caminho_recurso, ler_json

PASTA = "assets/sons"
INTERVALO_DO_MESMO_SOM = 0.05  # Segundos. Evita que o mesmo som se empilhe, como um por letra do texto.
TEMPO_DE_SAIDA = 400  # Milissegundos que a música leva para sumir.

_dados = None
_efeitos = {}  # nome -> pygame.mixer.Sound, ou None quando não deu para carregar
_ultima_vez = {}
_volume = 1.0  # O volume das Configurações, de 0 a 1.
_musica = None


def _catalogo():
    global _dados
    if _dados is None:
        _dados = ler_json("data/sons.json")
    return _dados


def _ligado():
    return pygame.mixer.get_init() is not None


def _caminho(dados):
    caminho = caminho_recurso(f"{PASTA}/{dados['arquivo']}")
    return caminho if os.path.exists(caminho) else None


def _carregar_efeito(nome):
    """Lê o arquivo uma vez só. Guarda None se ele faltar ou estiver estragado, para não tentar de novo."""
    if nome not in _efeitos:
        dados = _catalogo()["efeitos"].get(nome)
        caminho = _caminho(dados) if dados else None
        try:
            _efeitos[nome] = pygame.mixer.Sound(caminho) if caminho else None
        except pygame.error:
            _efeitos[nome] = None
    return _efeitos[nome]


def tocar_som(nome):
    """Toca um efeito. Devolve True se tocou."""
    if not _ligado() or _volume <= 0:
        return False
    agora = time.monotonic()
    if agora - _ultima_vez.get(nome, -1.0) < INTERVALO_DO_MESMO_SOM:
        return False
    efeito = _carregar_efeito(nome)
    if efeito is None:
        return False
    _ultima_vez[nome] = agora
    efeito.set_volume(_volume * _catalogo()["efeitos"][nome].get("volume", 1.0))
    return efeito.play() is not None


def tocar_pulo(corpo):
    """O som do pulo que o corpo vai dar agora. Quem não pode pular não faz som."""
    if corpo.no_chao:
        tocar_som("pulo")
    elif corpo.pulos_no_ar > 0:
        tocar_som("pulo_duplo")


def tocar_musica(nome):
    """Troca a música, em repetição. Pedir a que já está tocando não recomeça. None para a música."""
    global _musica
    if nome == _musica:
        return
    _musica = nome
    if not _ligado():
        return
    dados = _catalogo()["musicas"].get(nome) if nome else None
    caminho = _caminho(dados) if dados else None
    if caminho is None:
        pygame.mixer.music.fadeout(TEMPO_DE_SAIDA)
        return
    try:
        pygame.mixer.music.load(caminho)
        pygame.mixer.music.set_volume(_volume * dados.get("volume", 1.0))
        pygame.mixer.music.play(-1)
    except pygame.error:
        pygame.mixer.music.stop()


def tocar_musica_do_mapa(nome):
    """A música de um lugar: um mapa, "titulo" ou "final". Um lugar sem música própria usa a padrão."""
    musicas = _catalogo().get("musica_dos_mapas", {})
    tocar_musica(musicas.get(nome, musicas.get("padrao")))


def tocar_musica_da_luta(id_inimigo, forma=1):
    """A música da luta. Cada chefe tem a sua, e a ÍRIS tem outra na segunda forma. O resto usa a padrão."""
    musicas = _catalogo().get("musica_das_lutas", {})
    da_forma = musicas.get(f"{id_inimigo}{forma}") if forma > 1 else None
    tocar_musica(da_forma or musicas.get(id_inimigo, musicas.get("padrao")))


def musica_atual():
    return _musica


def definir_volume(porcentagem):
    """Recebe o volume das Configurações, de 0 a 100, e já muda a música. No zero, tudo se cala na hora."""
    global _volume
    novo = max(0, min(100, porcentagem)) / 100
    if novo == _volume:
        return  # A trilha pede a cada quadro: só trabalha quando muda.
    _volume = novo
    if _ligado():
        if _volume == 0:
            pygame.mixer.stop()
        dados = _catalogo()["musicas"].get(_musica) or {}
        pygame.mixer.music.set_volume(_volume * dados.get("volume", 1.0))


def esquecer_tudo():
    """Volta ao começo. O jogo não usa: serve para os testes, que abrem e fecham o Pygame várias vezes."""
    global _dados, _musica, _volume
    _dados, _musica, _volume = None, None, 1.0
    _efeitos.clear()
    _ultima_vez.clear()
