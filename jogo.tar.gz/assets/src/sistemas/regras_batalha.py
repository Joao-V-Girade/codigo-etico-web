"""As regras da batalha: vida, energia, Integridade, Estabilidade, Piedade e itens. Não depende do Pygame.

Aqui mora o centro educativo do combate. Por isso ele não depende da ação: se a arena ou a caixa de
desvio mudarem (D25), PIEDADE, RESTAURAR e Reconfiguração continuam iguais.
"""

import math

from src.sistemas.memoria_chefe import MemoriaChefe

ESTABILIDADE_MAXIMA = 100
AVISO_DE_INTEGRIDADE = 0.2
PARCELA_GUIADA_MAXIMA = 0.5
PADROES_SEM_MEMORIA = ("peneira",)
DOSSIE_MAXIMO = 100
AUTONOMIA_MAXIMA = 100
USOS_POR_NIVEL = 2


class Luta:
    def __init__(self, inimigo, regras, itens, modo_historia=False, estado=None):
        self.inimigo = inimigo
        self.itens = itens
        ada = regras["ada"]
        # A vida imita as Placas de Vida que o jogador teria naquele ponto do jogo (D66).
        self.vida_maxima = inimigo.get("vida_da_ada", ada["vida"])
        self.vida = self.vida_maxima
        self.energia_maxima = ada["energia"]
        self.energia = ada["energia"]
        self.energia_por_turno = ada["energia_por_turno"]
        self.integridade_maxima = inimigo["integridade"]
        self.integridade = inimigo["integridade"]
        self.estabilidade = 0
        self.turno = 1
        self._usos = {}
        # O Lume avisa uma vez antes de o jogador destruir sem perceber (05, seção 8).
        self.aviso_pendente = False
        self._falta_avisar = "fala_integridade_20" in inimigo
        # Só chefes têm memória. Nada dela é guardado depois da batalha (D49).
        self.memoria = MemoriaChefe(inimigo["memoria"]) if "memoria" in inimigo else None
        self.modo_historia = modo_historia
        self.estado = estado
        self.aceleracao = regras["aceleracao"]
        self._acumulado_guiado = 0.0
        self._turno_da_proxima_ult = None
        # A mecânica única de cada chefe (D63). Os números ficam em "mecanica", em data/inimigos.json.
        self.mecanica = inimigo.get("mecanica", {})
        self.rotulos = 0  # CRIVO: quantos rótulos RISCO estão colados na Ada.
        self.dossie = 0.0  # VIGIA: quanto ela já registrou, de 0 a 100.
        self.engajamento = 0  # ECO: sobe quando o jogador acerta uma cópia.
        self.autonomia = AUTONOMIA_MAXIMA  # ÍRIS: cai quando um fio prende a Ada.
        self.plataformas_cortadas = set()  # ÍRIS: o que ela já cortou por "eficiência".
        self.plataforma_marcada = None  # ÍRIS: o que ela vai cortar depois do próximo COMBATE.
        self.forma = 1  # ÍRIS: depois da primeira ult, ela se transforma e recupera a vida (D69).
        self.turnos_na_forma2 = 0  # ÍRIS: os ataques ficam mais fortes conforme a segunda forma avança.
        self.revisao_pendente = False  # ÍRIS: cortar 3 fios faz o próximo turno ter um ataque a menos.
        self.transformacao_pendente = False
        self.perguntas_feitas = 0  # ÍRIS: as perguntas do ato final.
        # A ult vem com metade da vida e abre a fase 2. A segunda vem com 1/3 da vida (D68).
        self.vida_da_ult = regras["vida_da_ult"]
        self.segunda_fase = regras["segunda_fase"]
        self.usos_da_ult = 0
        self.ult_pendente = False
        self.fase = 1
        self.usos_de_ataque = {}  # Quantas vezes cada ataque já foi usado: repetir deixa ele mais forte (D66).
        self._baralho = []
        self._lista_do_baralho = None
        self._ultimo_turno = []
        self.exo_quente = False  # Exo: bateu num pilar neste COMBATE.

    # ---------- Situação ----------
    @property
    def destruido(self):
        return self.integridade <= 0

    @property
    def derrotada(self):
        return self.vida <= 0

    @property
    def pode_restaurar(self):
        """A ÍRIS só pode ser restaurada depois de fazer as perguntas dela: é a hora da reflexão."""
        perguntas = len(self.inimigo.get("perguntas", ()))
        return self.estabilidade >= ESTABILIDADE_MAXIMA and self.perguntas_feitas >= perguntas

    @property
    def fator_de_velocidade(self):
        """Um turno completo é a ação do jogador mais a do inimigo. A partir do 5º, os ataques aceleram.

        Há um limite, para os ataques continuarem possíveis de desviar.
        """
        dados = self.aceleracao
        velocidade = self.inimigo.get("velocidade", {})
        inicial = velocidade.get("inicial", 1.0)
        maxima = velocidade.get("maxima", dados["maximo"])
        turnos_acelerados = max(0, self.turno - dados["a_partir_do_turno"] + 1)
        return min(maxima, inicial + turnos_acelerados * dados["por_turno"])

    @property
    def em_fase2(self):
        """Chefes mudam de ataques quando a Integridade cai ou a Estabilidade sobe (05, seção 5)."""
        if "ult" in self.inimigo:
            return self.fase == 2  # Quem tem ult só muda de fase depois dela.
        regra = self.inimigo.get("fase2_quando")
        if not regra:
            return False
        fracao = self.integridade / self.integridade_maxima
        return fracao < regra["integridade_abaixo"] or self.estabilidade > regra["estabilidade_acima"]

    # ---------- Segunda forma e ato final da ÍRIS (D66) ----------
    def transformar(self):
        """A vida volta, com outro corpo e outro ataque supremo."""
        self.forma = 2
        self.transformacao_pendente = False
        self.integridade = self.vida_depois_da_transformacao()
        self.turno = 1  # A contagem recomeça: a aceleração por turno volta para o começo (D69).
        self._entrar_na_fase2()

    def vida_depois_da_transformacao(self):
        """Quanto ela volta a ter fica em "vida_recuperada" (D69). Quem já tem mais que isso não perde nada."""
        fracao = self.inimigo["segunda_forma"]["vida_recuperada"]
        return max(self.integridade, math.ceil(self.integridade_maxima * fracao))

    def _entrar_na_fase2(self):
        """Na fase 2, todos os ataques ficam mais fortes e o chefe aprende ainda mais rápido com o jogador."""
        self.fase = 2
        self._baralho = []
        if self.memoria:
            dados = self.segunda_fase
            self.memoria.a_partir_do_turno = 0
            self.memoria.parcela_guiada = min(dados["parcela_maxima"], self.memoria.parcela_guiada + dados["parcela_extra"])
            self.memoria.esquecimento *= dados["esquecimento"]

    def depois_do_supremo(self):
        """A primeira ult é o que abre a fase 2. Na ÍRIS, ela vem com a transformação."""
        if self.usos_da_ult == 1 and self.fase == 1:
            if "segunda_forma" in self.inimigo:
                self.transformacao_pendente = True
            else:
                self._entrar_na_fase2()

    def _vida_da_proxima_ult(self):
        if "ult" not in self.inimigo or self.usos_da_ult >= 2:
            return None
        fracao = self.vida_da_ult["segunda"] if self.usos_da_ult else self.vida_da_ult["primeira"]
        return math.ceil(self.integridade_maxima * fracao)

    def sufixo_visual(self):
        return "2" if self.forma == 2 else ""

    @property
    def ult_atual(self):
        if self.forma == 2:
            return self.inimigo["segunda_forma"]["ult"]
        return self.inimigo.get("ult")

    @property
    def em_ato_final(self):
        """Depois da segunda ult, ou com muita Estabilidade, a ÍRIS quase para de atacar e faz perguntas, como no roteiro."""
        if "perguntas" not in self.inimigo:
            return False
        return (self.forma == 2 and self.usos_da_ult >= 2) or self.estabilidade >= self.inimigo["estabilidade_das_perguntas"]

    def proxima_pergunta(self):
        perguntas = self.inimigo.get("perguntas", ())
        return perguntas[self.perguntas_feitas] if self.perguntas_feitas < len(perguntas) else None

    # ---------- Rotação e evolução dos ataques (D66) ----------
    def proximos_ataques(self, lista, quantos, sorte):
        """Sorteia sem repetir: um ataque só volta quando todos os outros já saíram, e nunca em dois turnos seguidos.

        A primeira rodada de cada lista segue a ordem dos dados, para o primeiro ataque ser sempre o que ensina.
        """
        fila = []
        if self._lista_do_baralho != lista:
            self._lista_do_baralho = list(lista)
            self._baralho = list(lista)
            if self.forma == 2:
                # Na segunda forma, só o primeiro é fixo: assim, cada tentativa mostra outros ataques.
                resto = self._baralho[1:]
                sorte.shuffle(resto)
                self._baralho[1:] = resto
        for _ in range(quantos):
            if not self._baralho:
                novo = list(lista)
                sorte.shuffle(novo)
                # O que acabou de sair vai para o fim da nova rodada.
                novo.sort(key=lambda nome: nome in self._ultimo_turno or nome in fila)
                self._baralho = novo
            candidatos = [nome for nome in self._baralho if nome not in fila]
            escolhido = next((nome for nome in candidatos if nome not in self._ultimo_turno), candidatos[0] if candidatos else self._baralho[0])
            self._baralho.remove(escolhido)
            fila.append(escolhido)
        self._ultimo_turno = fila
        return fila

    def registrar_ataque(self, nome):
        """Conta o uso e devolve o nível: 1º uso, nível 0. Do 2º ao 3º, nível 1. Do 4º ao 5º, nível 2. E assim por diante."""
        if not self.inimigo.get("chefe"):
            return 0
        usos = self.usos_de_ataque.get(nome, 0) + 1
        self.usos_de_ataque[nome] = usos
        return usos // USOS_POR_NIVEL + (self.segunda_fase["nivel_extra"] if self.em_fase2 else 0) + self.nivel_pelo_tempo

    @property
    def nivel_pelo_tempo(self):
        """Um ataque só volta depois dos outros 19: sem isto, a repetição quase não apareceria na segunda forma (D69)."""
        if self.forma != 2:
            return 0
        return self.turnos_na_forma2 // self.mecanica["turnos_por_nivel"]

    def limite_do_supremo(self, padrao):
        ult = self.ult_atual or {}
        return ult.get("limite", padrao)

    def deve_usar_ult(self):
        """Diz se chegou a hora do ataque supremo: só depende da vida do chefe (D68)."""
        if not self.ult_pendente:
            return False
        self.ult_pendente = False
        self.usos_da_ult += 1
        return True

    @property
    def memoria_em_uso(self):
        """O chefe observa desde o começo, mas só usa o que viu a partir de certo turno (05, seção 5)."""
        return self.memoria is not None and self.turno >= self.memoria.a_partir_do_turno

    def alvo_guiado(self, nome_do_padrao, caixa):
        """Diz se o próximo ataque mira no hábito do jogador. Devolve um ponto (x, y) ou None.

        Limites de justiça (D49): no máximo 1 em cada 2 ataques, metade disso no Modo História, e o
        padrão Peneira nunca usa memória, porque a lição dele depende de as regras serem fixas.
        """
        if not self.memoria_em_uso or nome_do_padrao in PADROES_SEM_MEMORIA:
            return None
        terco, _ = self.memoria.habito("terco")
        if terco is None:
            return None
        maxima = self.segunda_fase["parcela_maxima"] if self.em_fase2 else PARCELA_GUIADA_MAXIMA
        parcela = min(self.memoria.parcela_guiada, maxima)
        if self.modo_historia:
            parcela /= 2
        if self.mecanica.get("tipo") == "dossie":
            # Sem dados, a VIGIA não prevê: quanto mais vazio o Dossiê, menos ataques guiados.
            if self.dossie < self.mecanica["dossie_minimo_para_guiar"]:
                return None
            parcela *= self.dossie / DOSSIE_MAXIMO
        self._acumulado_guiado += parcela
        if self._acumulado_guiado < 1.0:
            return None
        self._acumulado_guiado -= 1.0
        return caixa[0] + caixa[2] * (2 * terco + 1) // 6, caixa[1] + caixa[3] - 8

    # ---------- Dano ----------
    def ferir_inimigo(self, dano):
        """Tira Integridade e devolve quanto tirou. Antes do aviso do Lume, não passa de 20%."""
        piso = 0
        if self._falta_avisar:
            piso = math.ceil(self.integridade_maxima * AVISO_DE_INTEGRIDADE)
        vida_da_ult = self._vida_da_proxima_ult()
        if vida_da_ult is not None:
            piso = max(piso, vida_da_ult)  # O chefe nunca passa da ult sem usá-la.
        novo = max(piso, self.integridade - dano)
        aplicado = max(0, self.integridade - novo)
        self.integridade -= aplicado
        if vida_da_ult is not None and self.integridade <= vida_da_ult:
            self.ult_pendente = True
        elif self._falta_avisar and self.integridade <= piso:
            self.aviso_pendente = True
        return aplicado

    def concluir_aviso(self):
        self.aviso_pendente = False
        self._falta_avisar = False

    def ferir_ada(self, dano):
        self.vida = max(0, self.vida - dano)

    def gastar_energia(self, custo):
        if self.energia < custo:
            return False
        self.energia -= custo
        return True

    def fim_de_turno(self):
        self.energia = min(self.energia_maxima, self.energia + self.energia_por_turno)
        self.turno += 1
        self.exo_quente = False
        if self.forma == 2:
            self.turnos_na_forma2 += 1

    # ---------- Mecânica única de cada chefe (D63) ----------
    @property
    def multiplicador_da_velocidade(self):
        """CRIVO: cada rótulo pesa e deixa a Ada mais lenta, na arena e na caixa."""
        return 1.0 - self.rotulos * self.mecanica.get("perda_de_velocidade", 0.0)

    @property
    def multiplicador_do_pulo(self):
        return 1.0 - self.rotulos * self.mecanica.get("perda_de_pulo", 0.0)

    def colar_rotulo(self):
        if self.mecanica.get("tipo") == "rotulos":
            self.rotulos = min(self.mecanica["maximo"], self.rotulos + 1)

    def tirar_rotulo(self):
        self.rotulos = max(0, self.rotulos - 1)

    def registrar_no_dossie(self, quantidade):
        self.dossie = min(DOSSIE_MAXIMO, self.dossie + quantidade)

    @property
    def dossie_cheio(self):
        return self.dossie >= DOSSIE_MAXIMO

    def subir_engajamento(self):
        self.engajamento = min(self.mecanica["maximo"], self.engajamento + 1)

    def baixar_engajamento(self):
        self.engajamento = max(0, self.engajamento - 1)

    def ataques_no_turno(self):
        """Quantos ataques vêm neste turno. Exo: quem bateu num pilar está quente demais e só consegue 1."""
        if self.exo_quente or self.em_ato_final:
            return 1
        if self.forma == 2:
            return self.mecanica["ataques_na_forma2"] - (1 if self.revisao_pendente else 0)
        return self.inimigo.get("padroes_por_turno", 1)

    def pausa_entre_ataques(self, padrao):
        """ÍRIS: um respiro entre um ataque e outro, mais curto na segunda forma. Os outros chefes usam o tempo padrão."""
        if self.mecanica.get("tipo") != "autonomia":
            return padrao
        return self.mecanica["pausa_na_forma2" if self.forma == 2 else "pausa_entre_ataques"]

    def instalar_revisao(self):
        """ÍRIS, segunda forma: cortar 3 fios devolve a revisão humana por um turno."""
        if self.forma == 2:
            self.revisao_pendente = True

    def pode_recusar(self):
        """ÍRIS, segunda forma: o X na caixa gasta AUTONOMIA para a mini Ada escapar."""
        return self.forma == 2 and self.autonomia >= self.mecanica["custo_do_recusar"]

    def recusar(self):
        self.perder_autonomia(self.mecanica["custo_do_recusar"])

    def perder_autonomia(self, quantidade):
        self.autonomia = max(0.0, self.autonomia - quantidade)

    def devolver_autonomia(self, quantidade):
        self.autonomia = min(AUTONOMIA_MAXIMA, self.autonomia + quantidade)

    def puxao_da_autonomia(self):
        """ÍRIS: com a AUTONOMIA baixa, a mini Ada é puxada. É só uma força: o jogador sempre consegue reagir."""
        if self.mecanica.get("tipo") != "autonomia" or self.autonomia >= self.mecanica["autonomia_para_puxar"]:
            return 0.0
        fracao = 1 - self.autonomia / self.mecanica["autonomia_para_puxar"]
        return fracao * self.mecanica["puxao_na_caixa"]

    def texto_da_mecanica(self, textos):
        """A situação da mecânica, para mostrar na tela. Vazio quando não há nada para mostrar."""
        tipo = self.mecanica.get("tipo")
        if tipo == "rotulos" and self.rotulos:
            return f"{textos['mecanica_rotulos']} {self.rotulos}/{self.mecanica['maximo']}"
        if tipo == "dossie":
            return f"{textos['mecanica_dossie']} {int(self.dossie)}%"
        if tipo == "engajamento" and self.engajamento:
            return f"{textos['mecanica_engajamento']} {self.engajamento}/{self.mecanica['maximo']}"
        if tipo == "autonomia":
            return f"{textos['mecanica_autonomia']} {int(self.autonomia)}%"
        if tipo == "pilares" and self.exo_quente:
            return textos["mecanica_exo_quente"]
        return ""

    # ---------- Piedade ----------
    def acoes_de_piedade(self):
        """As ações que ainda valem: sem as já usadas, as esgotadas e as que pedem evidência que falta."""
        acoes = []
        for acao in self.inimigo["piedade"]:
            usos = self._usos.get(acao["id"], 0)
            if acao.get("uma_vez") and usos:
                continue
            if "maximo_total" in acao and usos * acao["valor"] >= acao["maximo_total"]:
                continue
            if "requer_item" in acao and acao["requer_item"] not in self.itens:
                continue
            if "condicao" in acao and not (self.estado and self.estado.condicao_ok(acao["condicao"])):
                continue
            acoes.append(acao)
        return acoes

    def usar_piedade(self, acao):
        """Sobe a Estabilidade e devolve as falas que devem aparecer."""
        usos = self._usos.get(acao["id"], 0)
        self._usos[acao["id"]] = usos + 1
        self.estabilidade = min(ESTABILIDADE_MAXIMA, self.estabilidade + acao["valor"])
        if acao.get("limpa_rotulos"):
            self.rotulos = 0
        if acao.get("corta_dossie"):
            self.dossie /= 2
        if acao.get("baixa_engajamento"):
            self.baixar_engajamento()
        if "devolve_autonomia" in acao:
            self.devolver_autonomia(acao["devolve_autonomia"])
        if "falas_alternadas" in acao:
            return [acao["falas_alternadas"][usos % len(acao["falas_alternadas"])]]
        return acao.get("falas", [])

    # ---------- Itens ----------
    def itens_usaveis(self, catalogo):
        """Só os itens que curam ou dão energia. Itens-chave e evidências não aparecem na mochila da luta."""
        lista = []
        for item_id, quantidade in self.itens.items():
            dados = catalogo.get(item_id, {})
            if quantidade > 0 and not dados.get("chave") and ("vida" in dados or "energia" in dados):
                lista.append(item_id)
        return lista

    def item_faz_efeito(self, dados):
        if "vida" in dados and self.vida < self.vida_maxima:
            return True
        return "energia" in dados and self.energia < self.energia_maxima

    def usar_item(self, item_id, dados):
        """Aplica o item e gasta uma unidade. Se ele não faria efeito, nada é gasto."""
        if not self.item_faz_efeito(dados):
            return False
        if "vida" in dados:
            cura = self.vida_maxima if dados["vida"] == "total" else dados["vida"]
            self.vida = min(self.vida_maxima, self.vida + cura)
        if "energia" in dados:
            self.energia = min(self.energia_maxima, self.energia + dados["energia"])
        self.itens[item_id] -= 1
        if self.itens[item_id] <= 0:
            del self.itens[item_id]
        return True


def avaliar_reconfiguracao(opcoes, marcadas, marcar):
    """Confere as regras marcadas. Devolve ("errada", índice), ("faltam", None) ou ("certa", None)."""
    for indice in sorted(marcadas):
        if not opcoes[indice]["certa"]:
            return "errada", indice
    if len(marcadas) < marcar:
        return "faltam", None
    return "certa", None
