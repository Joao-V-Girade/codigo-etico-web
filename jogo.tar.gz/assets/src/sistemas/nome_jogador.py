"""Regras do nome digitado na tela de título (cena 0.1). Não depende do Pygame, para ser testada."""

# Tabela própria, em vez do módulo unicodedata, que pode faltar no Python da versão web.
_SEM_ACENTO = str.maketrans("áàâãäéèêëíìîïóòôõöúùûüçÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇ", "aaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC")


def sem_acento(texto):
    return texto.translate(_SEM_ACENTO)


def letras_permitidas(teclas, acentos):
    """As letras do teclado da tela e as variações com acento (D32), em maiúscula e minúscula."""
    maiusculas = set("".join(teclas)) | set("".join(acentos.values()))
    return maiusculas | {letra.lower() for letra in maiusculas}


def acrescentar(nome, texto, permitidas, maximo):
    """Junta ao nome o que foi digitado, ignorando o que não for letra e o que passar do limite."""
    for letra in texto:
        if len(nome) >= maximo:
            break
        if letra in permitidas:
            nome += letra
    return nome


def validar_nome(nome, padrao):
    """Devolve (nome final, motivo da recusa). Sem nome, vale o padrão. Os nomes reservados voltam."""
    nome = nome.strip() or padrao
    comparar = sem_acento(nome).upper()
    if comparar == "IRIS":
        return None, "nome_iris"
    if comparar == "LUME":
        return None, "nome_lume"
    return nome, None
