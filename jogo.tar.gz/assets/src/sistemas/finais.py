"""Qual final acontece e os números do painel "Suas escolhas" (05, seção 12, e roteiro/finais.md).

São funções puras: recebem as flags da história e não dependem do Pygame, para serem testadas com pytest.
"""

MODULOS = ("crivo", "vigia", "eco")
# Estes têm uma linha própria no painel ou no epílogo, então não contam como inimigos.
FORA_DA_CONTA = {f"{m}_resultado" for m in MODULOS} | {"iris_resultado", "dante_resultado"}


def calcular_final(flags):
    """Devolve "C" (aceitou o acordo), "A" (ÍRIS restaurada), "B" (ÍRIS destruída) ou None (ainda sem final)."""
    if flags.get("aceitou_acordo"):
        return "C"
    return {"restaurado": "A", "destruido": "B"}.get(flags.get("iris_resultado"))


def contar_resultados(flags):
    """Conta os módulos, as evidências e os inimigos. O resultado entra nas flags, para as falas usarem.

    Um Fragmento desligado com segurança conta como restaurado: foi a escolha de PIEDADE.
    """
    modulos = [flags.get(f"{m}_resultado") for m in MODULOS]
    inimigos = [valor for chave, valor in flags.items() if chave not in FORA_DA_CONTA]
    return {
        "modulos_restaurados": modulos.count("restaurado"),
        "modulos_destruidos": modulos.count("destruido"),
        "evidencias_total": sum(flags.get(f"evidencias_f{n}", 0) for n in (1, 2, 3)),
        "inimigos_restaurados": inimigos.count("restaurado") + inimigos.count("desligado"),
        "inimigos_destruidos": inimigos.count("destruido"),
    }
