"""Acha e carrega arquivos do jogo nas três formas de rodar: computador, web e executável."""

import json
import os
import sys
import traceback

import pygame

EH_WEB = sys.platform == "emscripten"
EH_EXECUTAVEL = hasattr(sys, "_MEIPASS")

_imagens = {}


def caminho_recurso(relativo):
    """Recebe um caminho como "data/nomes.json" e devolve onde ele está de verdade.

    Dentro do .exe, o PyInstaller descompacta os arquivos numa pasta temporária (sys._MEIPASS).
    Nas outras formas, os arquivos estão na pasta jogo/, três níveis acima deste arquivo.
    """
    if EH_EXECUTAVEL:
        base = sys._MEIPASS
    else:
        base = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return os.path.join(base, relativo)


def ler_json(relativo):
    with open(caminho_recurso(relativo), encoding="utf-8") as arquivo:
        return json.load(arquivo)


def carregar_imagem(relativo):
    """Carrega um PNG uma vez só e guarda, para não ler o mesmo arquivo a cada quadro."""
    if relativo not in _imagens:
        _imagens[relativo] = pygame.image.load(caminho_recurso(relativo)).convert_alpha()
    return _imagens[relativo]


def registrar_erro():
    """Guarda o motivo de o jogo ter fechado. Sem terminal, seria a única pista. Na web, o navegador já mostra."""
    if EH_WEB:
        return
    pasta = pasta_de_prints()
    os.makedirs(pasta, exist_ok=True)
    with open(os.path.join(pasta, "ultimo_erro.txt"), "w", encoding="utf-8") as arquivo:
        arquivo.write(traceback.format_exc())


def pasta_de_prints():
    """Onde o F12 salva os prints. Nunca é a pasta temporária do executável."""
    if EH_EXECUTAVEL:
        base = os.path.dirname(sys.executable)
    else:
        base = os.path.dirname(caminho_recurso(""))
        base = os.path.dirname(base)
    return os.path.join(base, "capturas", "jogo")
