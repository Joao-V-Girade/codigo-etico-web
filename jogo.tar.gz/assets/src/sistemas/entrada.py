"""Traduz teclas em ações do jogo. O resto do código fala em "confirmar", nunca em "tecla Espaço"."""

import sys

import pygame

TECLAS = {
    "cima": (pygame.K_UP, pygame.K_w),
    "baixo": (pygame.K_DOWN, pygame.K_s),
    "esquerda": (pygame.K_LEFT, pygame.K_a),
    "direita": (pygame.K_RIGHT, pygame.K_d),
    "confirmar": (pygame.K_SPACE, pygame.K_RETURN),
    "cancelar": (pygame.K_x, pygame.K_ESCAPE),
    "menu": (pygame.K_c,),
    "impulso": (pygame.K_LSHIFT, pygame.K_RSHIFT),
}

# Botões do mouse, usados só na arena: o esquerdo atira e o direito carrega o tiro forte.
BOTOES_DO_MOUSE = {"tiro_mouse": 1, "carga_mouse": 3}


def ajustar_a_pagina_web():
    """Dois acertos que só existem no navegador. No computador e no .exe, não faz nada.

    - O botão direito abriria o menu do navegador por cima do jogo, então ele é bloqueado.
    - O pygbag calcula a proporção da tela antes de o jogo definir o tamanho dela, e a imagem ficava
      espremida num quadrado. Pedir um novo cálculo depois de abrir a tela mantém o formato 16:9.
    """
    if sys.platform == "emscripten":
        import platform  # No pygbag, este módulo dá acesso à página.

        platform.window.eval("document.addEventListener('contextmenu', function (e) { e.preventDefault(); });")
        platform.window.window_resize()


def acao_do_evento(evento):
    """Se o evento for uma tecla apertada, devolve a ação ligada a ela (ou None)."""
    if evento.type != pygame.KEYDOWN:
        return None
    for acao, teclas in TECLAS.items():
        if evento.key in teclas:
            return acao
    return None


def acao_do_mouse(evento):
    """Se o evento for um clique, devolve a ação ligada ao botão (ou None)."""
    if evento.type != pygame.MOUSEBUTTONDOWN:
        return None
    for acao, botao in BOTOES_DO_MOUSE.items():
        if evento.button == botao:
            return acao
    return None


def esta_pressionada(acao):
    """Diz se alguma tecla ou botão do mouse da ação está sendo segurado agora."""
    if acao in BOTOES_DO_MOUSE:
        return pygame.mouse.get_pressed()[BOTOES_DO_MOUSE[acao] - 1]
    estado = pygame.key.get_pressed()
    return any(estado[tecla] for tecla in TECLAS[acao])
