"""Efeitos que cobrem a tela inteira, pedidos pelas falas com "efeito_tela" (a Falha, cena 0.7).

- "glitch": a imagem treme em faixas e fica avermelhada, como uma tela com defeito.
- "apagao": a tela fica preta por 2 segundos e a luz volta aos poucos.
Com os flashes desligados nas Configurações, nada pisca: o glitch vira só um tom vermelho fixo.
"""

import random

import pygame

from src.sistemas.cores import cor

DURACAO = {"glitch": 1.6, "apagao": 2.6}
TEMPO_ESCURO = 2.0  # O apagão fica totalmente preto por este tempo e depois clareia.
ALTURA_FAIXA = 6
DESLOCAMENTO_MAXIMO = 10


class EfeitosDeTela:
    def __init__(self):
        self.nome = None
        self.tempo = 0.0
        self.sorte = random.Random()

    @property
    def ativo(self):
        return self.nome is not None

    def iniciar(self, nome):
        if nome in DURACAO:
            self.nome = nome
            self.tempo = 0.0

    def atualizar(self, dt):
        if self.nome:
            self.tempo += dt
            if self.tempo >= DURACAO[self.nome]:
                self.nome = None

    def desenhar(self, tela, flashes=True):
        if self.nome == "glitch":
            self._glitch(tela, flashes)
        elif self.nome == "apagao":
            self._apagao(tela)

    def _glitch(self, tela, flashes):
        largura, altura = tela.get_size()
        tom = pygame.Surface((largura, altura), pygame.SRCALPHA)
        if flashes:
            copia = tela.copy()
            for y in range(0, altura, ALTURA_FAIXA):
                if self.sorte.random() < 0.35:
                    dx = self.sorte.randint(-DESLOCAMENTO_MAXIMO, DESLOCAMENTO_MAXIMO)
                    tela.blit(copia, (dx, y), (0, y, largura, ALTURA_FAIXA))
            alfa = 60 + int(60 * self.sorte.random())
        else:
            alfa = 70
        vermelho = pygame.Color(cor("vermelho.vermelho"))
        tom.fill((vermelho.r, vermelho.g, vermelho.b, alfa))
        tela.blit(tom, (0, 0))

    def _apagao(self, tela):
        if self.tempo < TEMPO_ESCURO:
            alfa = 255
        else:
            fracao = (self.tempo - TEMPO_ESCURO) / (DURACAO["apagao"] - TEMPO_ESCURO)
            alfa = int(255 * max(0.0, 1.0 - fracao))
        preto = pygame.Surface(tela.get_size(), pygame.SRCALPHA)
        tinta = pygame.Color(cor("neutros.tinta"))
        preto.fill((tinta.r, tinta.g, tinta.b, alfa))
        tela.blit(preto, (0, 0))
