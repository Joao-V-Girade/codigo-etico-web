"""Anda pelas falas de um diálogo: condições, efeitos, escolhas e "ir_para". Não depende do Pygame."""


class Conversa:
    def __init__(self, dialogos, inicio, estado):
        self.dialogos = dialogos
        self.estado = estado
        self.falas = []
        self.indice = 0
        self.terminou = False
        self._entrar(inicio)

    def _entrar(self, sequencia):
        self.sequencia_atual = sequencia
        self.falas = self.dialogos[sequencia]
        self.indice = -1
        self._proxima_valida()

    def _proxima_valida(self):
        """Pula as falas cuja condição não vale e aplica os efeitos da que vai aparecer."""
        self.indice += 1
        while self.indice < len(self.falas):
            fala = self.falas[self.indice]
            if self.estado.condicao_ok(fala.get("condicao")):
                self.estado.aplicar_efeitos(fala.get("efeitos"))
                return
            self.indice += 1
        self.terminou = True

    @property
    def fala(self):
        return None if self.terminou else self.falas[self.indice]

    @property
    def escolhas(self):
        return self.fala.get("escolhas", []) if self.fala else []

    def avancar(self):
        """Vai para a próxima fala. Se a fala atual tem escolhas, é preciso usar escolher()."""
        if self.terminou or self.escolhas:
            return
        destino = self.fala.get("ir_para")
        if destino:
            self._entrar(destino)
        else:
            self._proxima_valida()

    def escolher(self, indice):
        opcao = self.escolhas[indice]
        self.estado.aplicar_efeitos(opcao.get("efeitos"))
        if "ir_para" in opcao:
            self._entrar(opcao["ir_para"])
        else:
            self.falas = []
            self.terminou = True
