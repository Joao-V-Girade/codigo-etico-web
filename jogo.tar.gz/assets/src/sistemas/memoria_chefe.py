"""A memória dos chefes (D49, D50): conta os hábitos do jogador durante a luta. Não depende do Pygame.

É gratuita: só uma tabela de contagens em Python, sem API, internet ou biblioteca extra. Cada leitura
faz as contagens antigas perderem um pouco de peso. Por isso, mudar o jeito de jogar sempre funciona:
o chefe "esquece" o que você parou de fazer. Nada é guardado depois da batalha.
"""

LEITURAS_MINIMAS = 3.0  # Com menos que isto, o chefe ainda não tem certeza de nada.
FORCA_MINIMA = 0.45  # Um hábito só conta se aparecer em boa parte das leituras.


class MemoriaChefe:
    def __init__(self, dados):
        self.esquecimento = dados["esquecimento"]
        self.a_partir_do_turno = dados["a_partir_do_turno"]
        self.parcela_guiada = dados["parcela_guiada"]
        self.tabelas = {}

    def observar(self, categoria, valor):
        """Registra uma leitura, como observar("altura_do_tiro", "chao")."""
        tabela = self.tabelas.setdefault(categoria, {})
        for chave in tabela:
            tabela[chave] *= self.esquecimento
        tabela[valor] = tabela.get(valor, 0.0) + 1.0

    def habito(self, categoria):
        """Devolve (valor, força de 0 a 1) do hábito mais forte, ou (None, 0) se ainda não há certeza."""
        tabela = self.tabelas.get(categoria)
        if not tabela:
            return None, 0.0
        total = sum(tabela.values())
        valor = max(tabela, key=tabela.get)
        forca = tabela[valor] / total
        if total < LEITURAS_MINIMAS or forca < FORCA_MINIMA:
            return None, 0.0
        return valor, forca
