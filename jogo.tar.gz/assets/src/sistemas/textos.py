"""Troca chaves como {LUME} e {JONAS^} pelos nomes de data/nomes.json (decisão D29)."""

import re

from src.sistemas.recursos import ler_json

_CHAVE = re.compile(r"\{([A-Z_]+)(\^?)\}")
_nomes = None


def _carregar_nomes():
    global _nomes
    if _nomes is None:
        _nomes = ler_json("data/nomes.json")
    return _nomes


def resolver(texto, nome_jogador="ADA"):
    """Devolve o texto com os nomes no lugar. Com ^, o nome sai em maiúsculas."""

    def trocar(encontrado):
        chave = encontrado.group(1)
        valor = nome_jogador if chave == "NOME" else _carregar_nomes().get(chave, encontrado.group(0))
        return valor.upper() if encontrado.group(2) else valor

    return _CHAVE.sub(trocar, texto)
