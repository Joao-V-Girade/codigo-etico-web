"""Acha o caminho mais curto entre dois tiles do mapa, para as cenas em que alguém anda sozinho.

Usa busca em largura: olha primeiro todos os tiles a 1 passo, depois a 2, e assim por diante, até
encontrar o destino. Só anda em 4 direções, como o jogador. Não depende do Pygame.
"""

from collections import deque

VIZINHOS = ((1, 0), (-1, 0), (0, 1), (0, -1))


def achar_caminho(livre, inicio, destinos):
    """livre(coluna, linha) diz se dá para pisar no tile. destinos é um tile ou uma lista de tiles.

    Devolve a lista de tiles do caminho, sem o tile de início, até o destino mais perto.
    Devolve [] se já estiver num destino e None se não houver caminho.
    """
    if isinstance(destinos, tuple):
        destinos = [destinos]
    destinos = set(map(tuple, destinos))
    inicio = tuple(inicio)
    if inicio in destinos:
        return []
    veio_de = {inicio: None}
    fila = deque([inicio])
    while fila:
        atual = fila.popleft()
        for dx, dy in VIZINHOS:
            vizinho = (atual[0] + dx, atual[1] + dy)
            if vizinho in veio_de or not (vizinho in destinos or livre(*vizinho)):
                continue
            veio_de[vizinho] = atual
            if vizinho in destinos:
                caminho = [vizinho]
                while veio_de[caminho[-1]] != inicio:
                    caminho.append(veio_de[caminho[-1]])
                return caminho[::-1]
            fila.append(vizinho)
    return None


def direcao_entre(de, para):
    """Para onde olhar, saindo do tile "de" e indo para o tile "para"."""
    dx, dy = para[0] - de[0], para[1] - de[1]
    if abs(dx) >= abs(dy):
        return "direita" if dx > 0 else "esquerda"
    return "baixo" if dy > 0 else "cima"
