"""Carrega e desenha os mapas de data/mapas/. Cada camada é uma lista de linhas de texto (D37).

"variantes" mudam alguns tiles conforme a história, como as folhas e os papéis na praça quando o
ZIM é destruído: [{"condicao": {...}, "camada": "chao" ou "objetos", "tiles": [[x, y, "letra"], ...]}].

O arquivo do tileset pode ter, sem ser obrigatório (D116): "opcoes" e "mosaico" em cada tile, que dão mais
de um desenho à mesma letra, e "bordas", que põem desenhos por cima conforme o vizinho. Só muda o desenho:
o que bloqueia a passagem continua sendo só "solido". Tudo é desenhado uma vez, ao montar o mapa.
"""

import random

import pygame

from src.sistemas.recursos import carregar_imagem, ler_json

VIZINHO = {"c": (0, 0), "n": (0, -1), "s": (0, 1), "o": (-1, 0), "l": (1, 0), "no": (-1, -1), "ne": (1, -1), "so": (-1, 1), "se": (1, 1)}


class Mapa:
    def __init__(self, nome):
        self.dados = ler_json(f"data/mapas/{nome}.json")
        self.nome = nome
        tileset = ler_json(f"data/tiles/{self.dados['tileset']}.json")
        self.tamanho = tileset["tamanho"]
        self.tiles = tileset["tiles"]
        self.folha = carregar_imagem(f"assets/tiles/{self.dados['tileset']}.png")
        self.cobertos = tileset.get("cobertos", "")
        self.bordas = self._separar_bordas(tileset.get("bordas", []))
        self.variantes = self.dados.get("variantes", [])
        self.frente = self.dados.get("frente", [])
        self.colunas = max(len(linha) for linha in self.dados["chao"])
        self.linhas = len(self.dados["chao"])
        self.largura = self.colunas * self.tamanho
        self.altura = self.linhas * self.tamanho
        self.ativas = None
        self.montar(tuple(False for _ in self.variantes))
        self.superficie_frente = self._desenhar(("frente", self.frente))

    def montar(self, ativas):
        """Aplica as variantes ligadas (uma lista de True/False, na ordem do arquivo) e redesenha o chão."""
        self.ativas = tuple(ativas)
        camadas = {"chao": [list(linha) for linha in self.dados["chao"]], "objetos": [list(linha) for linha in self.dados["objetos"]]}
        for variante, ligada in zip(self.variantes, self.ativas):
            if not ligada:
                continue
            grade = camadas[variante.get("camada", "objetos")]
            for x, y, letra in variante["tiles"]:
                while len(grade[y]) <= x:
                    grade[y].append(".")
                grade[y][x] = letra
        self.chao = ["".join(linha) for linha in camadas["chao"]]
        self.objetos = ["".join(linha) for linha in camadas["objetos"]]
        self.superficie_chao = self._desenhar(("chao", self.chao), ("objetos", self.objetos))

    def _separar_bordas(self, bordas):
        """Deixa à mão, para cada camada e letra, só as regras que podem valer neste mapa."""
        separadas = {}
        for numero, regra in enumerate(bordas):
            if self.nome not in regra.get("mapas", [self.nome]):
                continue
            for letra in regra["em"]:
                separadas.setdefault((regra["camada"], letra), []).append((numero, regra))
        return separadas

    def _desenhar(self, *camadas):
        """Desenha as camadas uma vez só numa imagem, em vez de tile por tile a cada quadro."""
        imagem = pygame.Surface((self.largura, self.altura), pygame.SRCALPHA)
        for nome, camada in camadas:
            for y, linha in enumerate(camada):
                for x, letra in enumerate(linha):
                    if letra in self.tiles:
                        self._carimbar(imagem, self._indice(self.tiles[letra], x, y), x, y)
                    for numero, regra in self.bordas.get((nome, letra), ()):
                        indice = self._indice_da_borda(numero, regra, nome, camada, x, y)
                        if indice is not None:
                            self._carimbar(imagem, indice, x, y)
        return imagem

    def _carimbar(self, imagem, indice, x, y):
        t = self.tamanho
        imagem.blit(self.folha, (x * t, y * t), (indice * t, 0, t, t))

    @staticmethod
    def _sortear(lista, x, y, numero=0):
        """O sorteio depende só do lugar: o mapa sai sempre igual."""
        return lista[random.Random(x * 131 + y * 977 + numero * 53).randrange(len(lista))]

    def _indice(self, tile, x, y):
        if "mosaico" in tile:
            return tile["mosaico"][y % 4 * 4 + x % 4]
        if "opcoes" in tile:
            return self._sortear(tile["opcoes"], x, y)
        return tile["indice"]

    def _indice_da_borda(self, numero, regra, nome, camada, x, y):
        """O desenho da borda neste lugar, ou None se a regra não valer."""
        dx, dy = VIZINHO[regra["lado"]]
        vizinho = self._letra(camada, x + dx, y + dy)
        if vizinho is None:  # Fora do mapa
            vizinho = "#"
            if "#" not in regra["vizinhos"]:
                return None
        if nome == "chao" and (dx or dy) and (self._letra(self.objetos, x + dx, y + dy) or "#") in self.cobertos:
            return None  # O vizinho está debaixo de uma parede.
        if (vizinho in regra["vizinhos"]) == regra["vizinhos"].startswith("!"):
            return None
        return self._sortear(regra["indices"], x, y, numero)

    @staticmethod
    def _letra(camada, x, y):
        if 0 <= y < len(camada) and 0 <= x < len(camada[y]):
            return camada[y][x]
        return None

    def tile_solido(self, coluna, linha):
        if not (0 <= coluna < self.colunas and 0 <= linha < self.linhas):
            return True
        if linha >= len(self.objetos) or coluna >= len(self.objetos[linha]):
            return False
        info = self.tiles.get(self.objetos[linha][coluna])
        return bool(info and info["solido"])

    def bate_em_parede(self, retangulo):
        """Diz se um retângulo encosta em algum tile que bloqueia a passagem."""
        t = self.tamanho
        for linha in range(retangulo.top // t, (retangulo.bottom - 1) // t + 1):
            for coluna in range(retangulo.left // t, (retangulo.right - 1) // t + 1):
                if self.tile_solido(coluna, linha):
                    return True
        return False
