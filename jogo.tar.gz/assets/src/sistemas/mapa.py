"""Carrega e desenha os mapas de data/mapas/. Cada camada é uma lista de linhas de texto (D37).

"variantes" mudam alguns tiles conforme a história, como as folhas e os papéis na praça quando o
ZIM é destruído: [{"condicao": {...}, "camada": "chao" ou "objetos", "tiles": [[x, y, "letra"], ...]}].
"""

import pygame

from src.sistemas.recursos import carregar_imagem, ler_json


class Mapa:
    def __init__(self, nome):
        self.dados = ler_json(f"data/mapas/{nome}.json")
        self.nome = nome
        tileset = ler_json(f"data/tiles/{self.dados['tileset']}.json")
        self.tamanho = tileset["tamanho"]
        self.tiles = tileset["tiles"]
        self.folha = carregar_imagem(f"assets/tiles/{self.dados['tileset']}.png")
        self.variantes = self.dados.get("variantes", [])
        self.frente = self.dados.get("frente", [])
        self.colunas = max(len(linha) for linha in self.dados["chao"])
        self.linhas = len(self.dados["chao"])
        self.largura = self.colunas * self.tamanho
        self.altura = self.linhas * self.tamanho
        self.ativas = None
        self.montar(tuple(False for _ in self.variantes))
        self.superficie_frente = self._desenhar(self.frente)

    def montar(self, ativas):
        """Aplica as variantes ligadas (uma lista de True/False, na ordem do arquivo) e redesenha o chão."""
        self.ativas = tuple(ativas)
        camadas = {"chao": [list(linha) for linha in self.dados["chao"]], "objetos": [list(linha) for linha in self.dados["objetos"]]}
        for variante, ligada in zip(self.variantes, self.ativas):
            if not ligada:
                continue
            grade = camadas[variante.get("camada", "objetos")]
            for x, y, letra in variante["tiles"]:
                while len(grade[y]) <= x:
                    grade[y].append(".")
                grade[y][x] = letra
        self.chao = ["".join(linha) for linha in camadas["chao"]]
        self.objetos = ["".join(linha) for linha in camadas["objetos"]]
        self.superficie_chao = self._desenhar(self.chao, self.objetos)

    def _desenhar(self, *camadas):
        """Desenha as camadas uma vez só numa imagem, em vez de tile por tile a cada quadro."""
        imagem = pygame.Surface((self.largura, self.altura), pygame.SRCALPHA)
        for camada in camadas:
            for y, linha in enumerate(camada):
                for x, letra in enumerate(linha):
                    if letra in self.tiles:
                        recorte = (self.tiles[letra]["indice"] * self.tamanho, 0, self.tamanho, self.tamanho)
                        imagem.blit(self.folha, (x * self.tamanho, y * self.tamanho), recorte)
        return imagem

    def tile_solido(self, coluna, linha):
        if not (0 <= coluna < self.colunas and 0 <= linha < self.linhas):
            return True
        if linha >= len(self.objetos) or coluna >= len(self.objetos[linha]):
            return False
        info = self.tiles.get(self.objetos[linha][coluna])
        return bool(info and info["solido"])

    def bate_em_parede(self, retangulo):
        """Diz se um retângulo encosta em algum tile que bloqueia a passagem."""
        t = self.tamanho
        for linha in range(retangulo.top // t, (retangulo.bottom - 1) // t + 1):
            for coluna in range(retangulo.left // t, (retangulo.right - 1) // t + 1):
                if self.tile_solido(coluna, linha):
                    return True
        return False
