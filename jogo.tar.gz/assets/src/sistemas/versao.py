"""Demo ou jogo completo (D79). Os dois são o mesmo código: só muda onde a história para.

A demo termina no final da demo, logo depois do CRIVO. O jogo completo segue para as Fases 2 a 4 e
os três finais, e liga as tomadas de salvar. A escolha fica em data/versao.json. No computador, a
variável de ambiente CODIGO_ETICO_VERSAO passa por cima do arquivo, para testar sem editá-lo.
"""

import os

from src.sistemas.recursos import ler_json

VERSOES = ("demo", "completo")


def versao():
    escolhida = os.environ.get("CODIGO_ETICO_VERSAO") or ler_json("data/versao.json")["versao"]
    return escolhida if escolhida in VERSOES else "demo"


def eh_completo():
    return versao() == "completo"
