"""Coração do jogo: a janela, o loop principal e a pilha de cenas."""

import asyncio
import os
from datetime import datetime

import pygame

from config import ALTURA_TELA, FPS, LARGURA_TELA
from src.cenas.abertura import CenaAbertura
from src.cenas.cartaz import CenaCartaz
from src.cenas.dialogo import CenaDialogo
from src.cenas.mundo import CenaMundo
from src.cenas.teste_base import CenaTesteBase
from src.cenas.titulo import CenaTitulo
from src.sistemas.efeitos_tela import EfeitosDeTela
from src.sistemas.entrada import ajustar_a_pagina_web
from src.sistemas.estado import Estado
from src.sistemas.recursos import EH_WEB, caminho_recurso, ler_json, pasta_de_prints
from src.sistemas.textos import resolver
from src.ui.fonte import Fonte

# Onde a Ada acorda ao começar um jogo novo (cena 0.3).
INICIO = {"mapa": "quarto", "x": 4, "y": 4, "direcao": "baixo"}


class Jogo:
    def __init__(self, comecar="titulo"):
        """comecar="titulo" abre a tela de título. Os testes usam "oficina" para cair direto no mapa."""
        pygame.init()
        # O ícone da janela e da barra de tarefas é o mesmo do atalho (ferramentas/gerar_icone.py).
        try:
            pygame.display.set_icon(pygame.image.load(caminho_recurso("assets/icone.png")))
        except (pygame.error, FileNotFoundError):
            pass
        # SCALED amplia a tela de 320x180 para a janela, sem borrar os pixels.
        self.tela = pygame.display.set_mode((LARGURA_TELA, ALTURA_TELA), pygame.SCALED)
        pygame.display.set_caption(resolver("{JOGO}"))
        ajustar_a_pagina_web()
        self.relogio = pygame.time.Clock()
        self.rodando = True
        self.fonte = Fonte()
        self.estado = Estado()
        self.efeitos = EfeitosDeTela()
        self.mundo = None
        # A cena do topo da pilha recebe as teclas. As de baixo continuam sendo desenhadas.
        if comecar == "titulo":
            self.cenas = [CenaTitulo(self)]
        else:
            self.mundo = CenaMundo(self, comecar)
            self.cenas = [self.mundo]

    def empilhar(self, cena):
        self.cenas.append(cena)

    def desempilhar(self):
        self.cenas.pop()

    def trocar(self, cena):
        self.cenas = [cena]

    # ---------- Começo e fim ----------
    def novo_jogo(self, nome, modo_historia=False):
        """Depois do nome e da dificuldade: estado novo, abertura e, por fim, o quarto da Ada."""
        configuracoes = self.estado.configuracoes  # As Configurações escolhidas no título continuam valendo.
        self.estado = Estado(nome, modo_historia)
        self.estado.configuracoes = configuracoes
        self.mundo = None
        self.trocar(CenaAbertura(self, self._comecar_exploracao))

    def _comecar_exploracao(self):
        self.mundo = CenaMundo(self, INICIO["mapa"], INICIO["x"], INICIO["y"])
        self.trocar(self.mundo)

    def voltar_ao_titulo(self):
        self.mundo = None
        self.efeitos = EfeitosDeTela()
        self.trocar(CenaTitulo(self))

    def ir_para_fase(self, fase):
        """Uma fala ou cena pediu outra fase. Os dados ficam em interface.json, em "fases".

        "titulo" e "subtitulo" mostram o nome da fase, "mapa" leva até ela e "cena" começa um roteiro de
        data/cenas.json. Fase sem "mapa" e sem "cena" ainda não existe: aparece o fim provisório.
        """
        from src.cenas.roteiro import CenaRoteiro  # Aqui dentro para não haver import circular.

        self.estado.flags["fase"] = fase
        interface = ler_json("data/interface.json")
        dados = interface["fases"].get(fase, {})

        def entrar():
            if "mapa" in dados and self.mundo:
                destino = dados["mapa"]
                self.mundo.carregar_mapa(destino["mapa"], destino["x"], destino["y"], destino.get("direcao", "baixo"))
            if "cena" in dados and self.mundo:
                self.empilhar(CenaRoteiro(self, dados["cena"]))
            elif "mapa" not in dados:
                fim = interface["fim_provisorio"]
                self.empilhar(CenaCartaz(self, fim["linhas"], self.voltar_ao_titulo, instrucao=fim["instrucao"]))

        if dados.get("titulo"):
            self.empilhar(CenaCartaz(self, [], entrar, titulo=dados["titulo"], subtitulo=dados.get("subtitulo"), tempo_sozinho=3.0))
        else:
            entrar()

    def mostrar_tela(self, nome):
        """Telas especiais pedidas por "ir_para_tela". Hoje só existe a dos créditos do fim da demo."""
        if nome != "creditos":
            return
        creditos = ler_json("data/dialogos/final_demo.json")["creditos"]

        def escolher(indice):
            # "Jogar de novo" volta ao título. "Sair" fecha o jogo; no navegador, também volta ao título.
            if indice == 1 and not EH_WEB:
                self.rodando = False
            else:
                self.voltar_ao_titulo()

        self.empilhar(CenaCartaz(self, creditos["linhas"], escolher, opcoes=creditos["opcoes"]))

    # ---------- Pedidos das falas ----------
    def _atender_pedidos(self):
        """Falas podem trocar o mapa e mexer na tela no meio da conversa. Isso é feito aqui."""
        estado = self.estado
        if estado.efeito_tela:
            self.efeitos.iniciar(estado.efeito_tela)
            estado.efeito_tela = None
        if estado.pedido_de_mapa and self.mundo:
            pedido, estado.pedido_de_mapa = estado.pedido_de_mapa, None
            self.mundo.carregar_mapa(pedido["mapa"], pedido["x"], pedido["y"], pedido.get("direcao", "baixo"))

    # ---------- Teclas de apoio ----------
    def alternar_teste_de_teclado(self):
        """F2 abre e fecha a tela de teste de acentos. É provisória, só para a FP1."""
        if isinstance(self.cenas[-1], CenaTesteBase):
            self.desempilhar()
        else:
            self.empilhar(CenaTesteBase(self))

    def salvar_print(self):
        pasta = pasta_de_prints()
        os.makedirs(pasta, exist_ok=True)
        nome = datetime.now().strftime("print_%Y-%m-%d_%H-%M-%S.png")
        pygame.image.save(self.tela, os.path.join(pasta, nome))

    def tratar_eventos(self):
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                self.rodando = False
            elif evento.type == pygame.KEYDOWN and evento.key == pygame.K_F12 and not EH_WEB:
                self.salvar_print()
            elif evento.type == pygame.KEYDOWN and evento.key == pygame.K_F2:
                self.alternar_teste_de_teclado()
            else:
                self.cenas[-1].tratar_evento(evento)

    def desenhar(self):
        # O efeito de tela fica por baixo da caixa de diálogo, para o texto continuar legível.
        topo_eh_fala = isinstance(self.cenas[-1], CenaDialogo)
        de_baixo = self.cenas[:-1] if topo_eh_fala else self.cenas
        for cena in de_baixo:
            cena.desenhar(self.tela)
        if self.efeitos.ativo:
            self.efeitos.desenhar(self.tela, self.estado.configuracoes["flashes"])
        if topo_eh_fala:
            self.cenas[-1].desenhar(self.tela)
        pygame.display.flip()

    async def rodar(self, max_quadros=None):
        """Roda o jogo. max_quadros serve para os testes pararem sozinhos."""
        quadros = 0
        while self.rodando and (max_quadros is None or quadros < max_quadros):
            dt = self.relogio.tick(FPS) / 1000
            await asyncio.sleep(0)  # Devolve o controle ao navegador. Sem isto, a página trava.
            self.passo(dt)
            quadros += 1

    def passo(self, dt):
        """Um quadro do jogo. Separado do loop para os testes poderem avançar quadro a quadro."""
        self.tratar_eventos()
        self.cenas[-1].atualizar(dt)
        self._atender_pedidos()
        self.efeitos.atualizar(dt)
        self.desenhar()
