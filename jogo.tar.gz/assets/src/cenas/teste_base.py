"""Cena provisória da FP1: confere janela, teclas, fonte, imagens e dados nas três formas de rodar.

Será substituída pelo mapa de verdade na FP2.
"""

import pygame

from config import ALTURA_TELA, LARGURA_TELA
from src.cenas.cena import Cena
from src.sistemas.entrada import esta_pressionada
from src.sistemas.recursos import EH_EXECUTAVEL, EH_WEB, carregar_imagem, ler_json
from src.sistemas.textos import resolver

VELOCIDADE = 60  # pixels por segundo
QUADROS_POR_SEGUNDO_ANDANDO = 8
LIMITE_DIGITADO = 24
DIRECOES = {
    "baixo": (0, 1),
    "cima": (0, -1),
    "esquerda": (-1, 0),
    "direita": (1, 0),
}


class CenaTesteBase(Cena):
    def __init__(self, jogo):
        super().__init__(jogo)
        self.textos = ler_json("data/interface.json")["teste_base"]
        paleta = ler_json("data/paleta.json")
        self.cor_chao = paleta["vila"]["folha"]
        self.cor_caixa = jogo.fonte.cores["fundo_caixa"]
        self.cor_borda = jogo.fonte.cores["borda_caixa"]
        self.x = LARGURA_TELA / 2 - 12
        self.y = 62.0
        self.direcao = "baixo"
        self.tempo = 0.0
        self.andando = False
        self.digitado = ""
        self.quadros = {
            direcao: [
                carregar_imagem(f"assets/sprites/ada/ada_mapa_{direcao}_{nome}.png")
                for nome in ("parada", "passo_1", "parada", "passo_2")
            ]
            for direcao in DIRECOES
        }
        pygame.key.start_text_input()

    def tratar_evento(self, evento):
        if evento.type == pygame.TEXTINPUT and len(self.digitado) < LIMITE_DIGITADO:
            self.digitado += evento.text
        elif evento.type == pygame.KEYDOWN and evento.key == pygame.K_BACKSPACE:
            self.digitado = self.digitado[:-1]

    def atualizar(self, dt):
        self.andando = False
        for direcao, (dx, dy) in DIRECOES.items():
            if esta_pressionada(direcao):
                self.x += dx * VELOCIDADE * dt
                self.y += dy * VELOCIDADE * dt
                self.direcao = direcao
                self.andando = True
        self.x = max(0, min(self.x, LARGURA_TELA - 24))
        self.y = max(0, min(self.y, ALTURA_TELA - 92))
        self.tempo = self.tempo + dt if self.andando else 0.0

    def forma_de_rodar(self):
        if EH_WEB:
            return self.textos["forma_web"]
        if EH_EXECUTAVEL:
            return self.textos["forma_executavel"]
        return self.textos["forma_computador"]

    def desenhar(self, tela):
        tela.fill(self.cor_chao)
        indice = int(self.tempo * QUADROS_POR_SEGUNDO_ANDANDO) % 4 if self.andando else 0
        tela.blit(self.quadros[self.direcao][indice], (int(self.x), int(self.y)))

        pygame.draw.rect(tela, self.cor_borda, (8, 116, 304, 56))
        pygame.draw.rect(tela, self.cor_caixa, (10, 118, 300, 52))
        fonte = self.jogo.fonte
        fonte.desenhar(tela, 16, 120, resolver(self.textos["titulo"]) + " - " + self.forma_de_rodar())
        fonte.desenhar(tela, 16, 132, self.textos["instrucao"])
        fonte.desenhar(tela, 16, 144, self.textos["digite"] + " " + self.digitado + "_", fonte.cores["selecionado"])
        fonte.desenhar(tela, 16, 156, self.textos["acentos"], fonte.cores["desativado"], fonte.cores["sombra_desativado"])
