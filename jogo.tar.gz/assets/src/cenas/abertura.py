"""Abertura (cena 0.2): 4 slides com o texto aparecendo letra a letra.

Os textos ficam em data/dialogos/fase0.json ("abertura") e as imagens em data/slides.json.
Espaço avança e X pula a abertura inteira.
"""

import pygame

from config import ALTURA_TELA, LARGURA_TELA
from src.cenas.cena import Cena
from src.cenas.dialogo import LETRAS_POR_SEGUNDO
from src.sistemas.cores import cor
from src.sistemas.entrada import acao_do_evento
from src.sistemas.recursos import carregar_imagem, ler_json
from src.sistemas.textos import resolver
from src.ui.caixa_texto import desenhar_caixa, quebrar_em_linhas

CAIXA = pygame.Rect(8, ALTURA_TELA - 52, LARGURA_TELA - 16, 44)
MARGEM = 8
TEMPO_DE_TROCA = 0.5  # Escurece e clareia entre um slide e outro.


class CenaAbertura(Cena):
    def __init__(self, jogo, depois):
        super().__init__(jogo)
        self.slides = ler_json("data/dialogos/fase0.json")["abertura"]
        self.imagens = ler_json("data/slides.json")
        self.pular = ler_json("data/interface.json")["abertura"]["pular"]
        self.depois = depois
        self.indice = 0
        self.tempo_troca = TEMPO_DE_TROCA
        self.terminou = False
        self._preparar()

    def _preparar(self):
        texto = resolver(self.slides[self.indice]["texto"], self.jogo.estado.nome)
        self.linhas = quebrar_em_linhas(self.jogo.fonte, texto, CAIXA.width - 2 * MARGEM)
        self.total_letras = sum(len(linha) for linha in self.linhas)
        self.letras = 0.0
        dados = self.imagens.get(self.slides[self.indice]["slide"], {"camadas": []})
        self.camadas = [carregar_imagem(f"assets/fundos/{nome}.png") for nome in dados["camadas"]]
        self.chao = carregar_imagem(f"assets/fundos/{dados['chao']}.png") if "chao" in dados else None

    def _terminar(self):
        if not self.terminou:
            self.terminou = True
            self.depois()

    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        if acao == "cancelar":
            self._terminar()
        elif acao == "confirmar" and self.tempo_troca <= 0:
            if self.letras < self.total_letras:
                self.letras = self.total_letras
            elif self.indice + 1 < len(self.slides):
                self.indice += 1
                self.tempo_troca = TEMPO_DE_TROCA
                self._preparar()
            else:
                self._terminar()

    def atualizar(self, dt):
        if self.tempo_troca > 0:
            self.tempo_troca = max(0.0, self.tempo_troca - dt)
            return
        velocidade = LETRAS_POR_SEGUNDO.get(self.jogo.estado.configuracoes["velocidade_texto"], LETRAS_POR_SEGUNDO["normal"])
        self.letras = min(self.total_letras, self.letras + velocidade * 0.6 * dt)

    def desenhar(self, tela):
        fonte = self.jogo.fonte
        tela.fill(cor("neutros.tinta"))
        for imagem in self.camadas:
            tela.blit(imagem, ((LARGURA_TELA - imagem.get_width()) // 2, 0))
        if self.chao:
            tela.blit(self.chao, (0, ALTURA_TELA - self.chao.get_height()))
        if self.tempo_troca > 0:
            escuro = pygame.Surface(tela.get_size(), pygame.SRCALPHA)
            tinta = pygame.Color(cor("neutros.tinta"))
            escuro.fill((tinta.r, tinta.g, tinta.b, int(255 * self.tempo_troca / TEMPO_DE_TROCA)))
            tela.blit(escuro, (0, 0))
            return

        desenhar_caixa(tela, CAIXA, fonte.cores["borda_caixa"], fonte.cores["fundo_caixa"])
        restantes = int(self.letras)
        for i, linha in enumerate(self.linhas):
            parte = linha[:restantes]
            restantes -= len(parte)
            fonte.desenhar(tela, CAIXA.left + MARGEM, CAIXA.top + 4 + i * fonte.altura_linha, parte)
        fonte.desenhar(tela, LARGURA_TELA - 4 - fonte.largura(self.pular), 4, self.pular, fonte.cores["desativado"], fonte.cores["sombra_desativado"])
