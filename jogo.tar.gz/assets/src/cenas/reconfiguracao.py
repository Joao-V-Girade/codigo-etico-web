"""A Reconfiguração: o jogador escolhe as regras novas do módulo. Errar não tem punição (D20).

A tela lembra um terminal antigo. Ao marcar uma regra errada, o Lume explica o problema e o jogador
tenta de novo. É o momento educativo central de cada restauração.
"""

import math

from config import LARGURA_TELA
from src.cenas.cena import Cena
from src.cenas.dialogo import CenaDialogo
from src.sistemas.cores import cor
from src.sistemas.entrada import acao_do_evento
from src.sistemas.recursos import carregar_imagem, ler_json
from src.sistemas.regras_batalha import avaliar_reconfiguracao
from src.sistemas.textos import resolver
from src.ui.caixa_texto import quebrar_em_linhas

X_CAIXINHA = 30
X_TEXTO = 50
LARGURA_DO_TEXTO = LARGURA_TELA - X_TEXTO - 8
Y_TITULO = 4
Y_OPCOES = 22


class CenaReconfiguracao(Cena):
    def __init__(self, jogo, id_reconfiguracao):
        super().__init__(jogo)
        self.dados = ler_json("data/reconfiguracoes.json")[id_reconfiguracao]
        self.textos = ler_json("data/interface.json")["reconfiguracao"]
        self.opcoes = self.dados["opcoes"]
        self.marcar = self.dados["marcar"]
        self.marcadas = set()
        self.indice = 0
        self.tempo = 0.0
        self.terminou = False
        self.lume = carregar_imagem("assets/sprites/lume/lume_normal.png")
        self.linhas = [
            quebrar_em_linhas(jogo.fonte, resolver(opcao["texto"], jogo.estado.nome), LARGURA_DO_TEXTO)
            for opcao in self.opcoes
        ]
        self.intro_pendente = True

    def _falar(self, falas):
        self.jogo.empilhar(CenaDialogo(self.jogo, {"falas": falas}, "falas"))

    @property
    def no_botao_confirmar(self):
        return self.indice == len(self.opcoes)

    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        total = len(self.opcoes) + 1
        if acao == "cima":
            self.indice = (self.indice - 1) % total
        elif acao == "baixo":
            self.indice = (self.indice + 1) % total
        elif acao == "confirmar":
            if self.no_botao_confirmar:
                self._confirmar()
            else:
                self._alternar(self.indice)

    def _alternar(self, indice):
        if indice in self.marcadas:
            self.marcadas.discard(indice)
        elif self.marcar == 1:
            self.marcadas = {indice}  # Com uma regra só, marcar outra troca a escolha.
        elif len(self.marcadas) < self.marcar:
            self.marcadas.add(indice)

    def _confirmar(self):
        resultado, indice = avaliar_reconfiguracao(self.opcoes, self.marcadas, self.marcar)
        if resultado == "errada":
            self.marcadas.discard(indice)
            self._falar([{"quem": "{LUME}", "texto": self.opcoes[indice]["comentario"]}])
        elif resultado == "faltam":
            self._falar([{"texto": self.textos["faltam"]}])
        else:
            self.terminou = True

    def atualizar(self, dt):
        self.tempo += dt
        if self.intro_pendente:
            # A fala só pode abrir depois que esta cena já estiver na pilha.
            self.intro_pendente = False
            self._falar([self.dados["intro"]])
        elif self.terminou:
            self.jogo.desempilhar()

    def desenhar(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        verde = cores["maquina"]
        tela.fill(cor("neutros.tinta"))
        titulo = resolver(self.dados["titulo"], self.jogo.estado.nome)
        fonte.desenhar(tela, (LARGURA_TELA - fonte.largura(titulo)) // 2, Y_TITULO, titulo, verde)

        y = Y_OPCOES
        balanco = int(math.sin(self.tempo * 4))
        for indice, linhas in enumerate(self.linhas):
            selecionada = indice == self.indice
            cor_texto = cores["selecionado"] if selecionada else verde
            caixinha = self.textos["marcada"] if indice in self.marcadas else self.textos["desmarcada"]
            if selecionada:
                tela.blit(self.lume, (10, y + 1 + balanco))
            fonte.desenhar(tela, X_CAIXINHA, y, caixinha, cor_texto)
            for numero, linha in enumerate(linhas):
                fonte.desenhar(tela, X_TEXTO, y + numero * fonte.altura_linha, linha, cor_texto)
            y += len(linhas) * fonte.altura_linha + 3

        y += 4
        selecionado = self.no_botao_confirmar
        cor_botao = cores["selecionado"] if selecionado else cores["texto"]
        if selecionado:
            tela.blit(self.lume, (X_TEXTO - 20, y + 1 + balanco))
        fonte.desenhar(tela, X_TEXTO, y, self.textos["confirmar"], cor_botao)
