"""Caixa de diálogo por cima do mapa: texto letra a letra, nome de quem fala e escolhas.

Uma fala também pode mostrar:
- "tela": um documento, tabela ou gráfico de data/telas.json, acima da caixa (as provas da Fase 1).
- "slide" ou "cartao": uma imagem de tela cheia de data/slides.json, com "titulo" em letras grandes.
- "painel": um quadro com as escolhas do jogador, descrito em "paineis" no mesmo arquivo de falas.
Depois do primeiro slide, cartão ou painel, o fundo continua escuro até a conversa acabar.
"""

import re

import pygame

from config import ALTURA_TELA, LARGURA_TELA
from src.cenas.cena import Cena
from src.sistemas.conversa import Conversa
from src.sistemas.cores import cor
from src.sistemas.entrada import acao_do_evento
from src.sistemas.recursos import carregar_imagem, ler_json
from src.sistemas.textos import resolver
from src.ui.caixa_texto import desenhar_caixa, quebrar_em_linhas
from src.ui.telas import desenhar_tela

# Velocidade do texto, escolhida nas Configurações (D51).
LETRAS_POR_SEGUNDO = {"lenta": 20, "normal": 40, "rapida": 90}
CAIXA = pygame.Rect(8, ALTURA_TELA - 64, LARGURA_TELA - 16, 56)
MARGEM_X = 8
MARGEM_Y = 3
LARGURA_TEXTO = CAIXA.width - 2 * MARGEM_X
MAX_LINHAS = 3
ALTURA_ETIQUETA = 16
ALTURA_ESCOLHA = 13
PISCAR_POR_SEGUNDO = 2

# Quem fala -> cor do nome, em assets/fontes/fonte_jogo.json.
CORES_DOS_NOMES = {
    "{NOME}": "ADA", "{LUME}": "LUME", "{CIDA}": "DONA CIDA", "{JONAS}": "JONAS", "{MAYA}": "MAYA",
    "{RAFA}": "RAFA", "{DANTE}": "DANTE", "{LACERDA}": "LACERDA", "{IRIS}": "ÍRIS",
}


class CenaDialogo(Cena):
    def __init__(self, jogo, dialogos, inicio, caixa=CAIXA):
        """caixa permite mudar a altura: na batalha, as falas ficam acima do menu."""
        super().__init__(jogo)
        self.caixa = caixa
        self.conversa = Conversa(dialogos, inicio, jogo.estado)
        self.falas_de_maquina = ler_json("data/interface.json")["falas_de_maquina"]
        self.dialogos = dialogos
        self.telas = None
        self.slides = None
        self.tela_cheia = False
        self.opcao = 0
        self.tempo_total = 0.0
        self._preparar_fala()

    def _resolver(self, texto):
        return resolver(texto, self.jogo.estado.nome)

    def _preparar_fala(self):
        """Monta as linhas da fala atual, ou fecha a caixa se a conversa acabou."""
        if self.conversa.terminou:
            self.jogo.desempilhar()
            return
        texto = self._resolver(self.conversa.fala.get("texto", ""))
        self.linhas = quebrar_em_linhas(self.jogo.fonte, texto, LARGURA_TEXTO)[:MAX_LINHAS]
        self.total_letras = sum(len(linha) for linha in self.linhas)
        self.letras = 0.0
        self.opcao = 0
        # "pausa" segura a fala na tela por alguns segundos, como o silêncio do Lume esperando.
        self.espera = float(self.conversa.fala.get("pausa", 0))

    @property
    def texto_completo(self):
        return self.letras >= self.total_letras

    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        if acao is None:
            return
        if not self.texto_completo:
            if acao in ("confirmar", "cancelar"):
                self.letras = self.total_letras  # Mostra a fala inteira de uma vez.
            return
        if self.espera > 0:
            return
        escolhas = self.conversa.escolhas
        if escolhas:
            if acao == "cima":
                self.opcao = (self.opcao - 1) % len(escolhas)
            elif acao == "baixo":
                self.opcao = (self.opcao + 1) % len(escolhas)
            elif acao == "confirmar":
                self.conversa.escolher(self.opcao)
                self._preparar_fala()
        elif acao == "confirmar":
            self.conversa.avancar()
            self._preparar_fala()

    def atualizar(self, dt):
        self.tempo_total += dt
        velocidade = LETRAS_POR_SEGUNDO.get(self.jogo.estado.configuracoes["velocidade_texto"], LETRAS_POR_SEGUNDO["normal"])
        self.letras = min(self.total_letras, self.letras + velocidade * dt)
        if self.texto_completo:
            self.espera = max(0.0, self.espera - dt)

    # ---------- Desenho ----------
    def _cor_do_texto(self):
        fonte = self.jogo.fonte
        if self.conversa.fala.get("quem") in self.falas_de_maquina:
            return fonte.cores["maquina"], fonte.cores["sombra"]
        return fonte.cores["texto"], fonte.cores["sombra"]

    def _desenhar_nome(self, tela, quem):
        fonte = self.jogo.fonte
        nomes = fonte.cores["nomes"]
        if quem in self.falas_de_maquina:
            cor = nomes["MODULO"]
        else:
            cor = nomes.get(CORES_DOS_NOMES.get(quem), nomes["NPC"])
        nome = self._resolver(quem).replace("-SISTEMA", "")
        fundo = pygame.Rect(self.caixa.left, self.caixa.top - ALTURA_ETIQUETA + 1, fonte.largura(nome) + 14, ALTURA_ETIQUETA)
        desenhar_caixa(tela, fundo, fonte.cores["borda_caixa"], fonte.cores["fundo_caixa"], 1)
        fonte.desenhar(tela, fundo.left + 7, fundo.top + 1, nome, cor)

    def _desenhar_escolhas(self, tela):
        fonte = self.jogo.fonte
        textos = [self._resolver(opcao["texto"]) for opcao in self.conversa.escolhas]
        largura = max(fonte.largura(texto) for texto in textos) + 22
        altura = len(textos) * ALTURA_ESCOLHA + 8
        caixa = pygame.Rect(self.caixa.right - largura, self.caixa.top - altura - 2, largura, altura)
        desenhar_caixa(tela, caixa, fonte.cores["borda_caixa"], fonte.cores["fundo_caixa"])
        for i, texto in enumerate(textos):
            y = caixa.top + 3 + i * ALTURA_ESCOLHA
            selecionada = i == self.opcao
            cor = fonte.cores["selecionado"] if selecionada else fonte.cores["texto"]
            if selecionada:
                fonte.desenhar(tela, caixa.left + 6, y, "▶", cor)
            fonte.desenhar(tela, caixa.left + 14, y, texto, cor)

    # ---------- Tela cheia (final da demo) ----------
    def _desenhar_fundo(self, tela, fala):
        fonte = self.jogo.fonte
        chave = fala.get("slide") or fala.get("cartao")
        if chave or "painel" in fala:
            self.tela_cheia = True
        if not self.tela_cheia:
            return
        tela.fill(cor("neutros.tinta"))
        if chave:
            if self.slides is None:
                self.slides = ler_json("data/slides.json")
            dados = self.slides.get(chave, {"camadas": []})
            for nome in dados["camadas"]:
                imagem = carregar_imagem(f"assets/fundos/{nome}.png")
                tela.blit(imagem, ((LARGURA_TELA - imagem.get_width()) // 2, 0))
            if "chao" in dados:
                chao = carregar_imagem(f"assets/fundos/{dados['chao']}.png")
                tela.blit(chao, (0, ALTURA_TELA - chao.get_height()))
            if "cartao" in fala:
                # Cartões do epílogo: a imagem fica mais escura, para o texto aparecer.
                escuro = pygame.Surface(tela.get_size(), pygame.SRCALPHA)
                escuro.fill((0, 0, 0, 140))
                tela.blit(escuro, (0, 0))
        if fala.get("titulo"):
            titulo = fonte.grande(self._resolver(fala["titulo"]), 2, fonte.cores["texto"], fonte.cores["fundo_caixa"])
            tela.blit(titulo, ((LARGURA_TELA - titulo.get_width()) // 2, 24))
        if "painel" in fala:
            self._desenhar_painel(tela, self.dialogos["paineis"][fala["painel"]])

    def _desenhar_painel(self, tela, painel):
        fonte = self.jogo.fonte
        flags = self.jogo.estado.flags
        valores = painel.get("valores", {})

        def valor(encontrado):
            bruto = flags.get(encontrado.group(1))
            return valores.get(bruto, str(bruto if bruto is not None else 0))

        linhas = [self._resolver(re.sub(r"\{([a-z_0-9]+)\}", valor, linha)) for linha in painel["linhas"]]
        titulo = self._resolver(painel["titulo"])
        largura = max(fonte.largura(linha) for linha in linhas + [titulo]) + 32
        caixa = pygame.Rect(0, 0, largura, 28 + len(linhas) * 14)
        caixa.midtop = (LARGURA_TELA // 2, 30)
        desenhar_caixa(tela, caixa, fonte.cores["borda_caixa"], fonte.cores["fundo_caixa"])
        fonte.desenhar_centralizado(tela, caixa.top + 6, titulo, fonte.cores["destaque"])
        for i, linha in enumerate(linhas):
            fonte.desenhar(tela, caixa.left + 16, caixa.top + 22 + i * 14, linha)

    def desenhar(self, tela):
        if self.conversa.terminou:
            return
        fonte = self.jogo.fonte
        fala = self.conversa.fala
        self._desenhar_fundo(tela, fala)
        if "tela" in fala:
            if self.telas is None:
                self.telas = ler_json("data/telas.json")
            desenhar_tela(tela, fonte, self.telas[fala["tela"]], self.jogo.estado.nome)
        if not fala.get("texto"):
            # Uma fala sem texto (como o painel) espera o jogador apertar para seguir.
            if int(self.tempo_total * PISCAR_POR_SEGUNDO) % 2 == 0:
                fonte.desenhar(tela, LARGURA_TELA - 20, ALTURA_TELA - 16, "▼")
            return
        placa = fala.get("modo") == "placa"
        if placa:
            desenhar_caixa(tela, self.caixa, fonte.cores["claro_texto"], fonte.cores["claro_fundo"])
            cor, sombra = fonte.cores["claro_texto"], fonte.cores["claro_sombra"]
        else:
            desenhar_caixa(tela, self.caixa, fonte.cores["borda_caixa"], fonte.cores["fundo_caixa"])
            cor, sombra = self._cor_do_texto()

        if fala.get("quem"):
            self._desenhar_nome(tela, fala["quem"])

        restantes = int(self.letras)
        for i, linha in enumerate(self.linhas):
            parte = linha[:restantes]
            restantes -= len(parte)
            fonte.desenhar(tela, self.caixa.left + MARGEM_X, self.caixa.top + MARGEM_Y + i * fonte.altura_linha, parte, cor, sombra)

        if self.texto_completo and self.espera <= 0:
            if self.conversa.escolhas:
                self._desenhar_escolhas(tela)
            elif int(self.tempo_total * PISCAR_POR_SEGUNDO) % 2 == 0:
                fonte.desenhar(tela, self.caixa.right - 12, self.caixa.bottom - 15, "▼", cor, sombra)
