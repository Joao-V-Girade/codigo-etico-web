"""Telas cheias de texto: o nome da fase que começa, os créditos e o fim da parte jogável.

Cada uma aparece aos poucos e, quando o jogador confirma, chama a função "depois". Com "opcoes",
aparece uma lista para escolher, e "depois" recebe o número da opção escolhida.
"""

from config import ALTURA_TELA, LARGURA_TELA
from src.cenas.cena import Cena
from src.sistemas.cores import cor
from src.sistemas.entrada import acao_do_evento
from src.sistemas.textos import resolver
from src.ui.caixa_texto import quebrar_em_linhas
from src.ui.menu import ListaDeOpcoes

TEMPO_PARA_APARECER = 0.8
TEMPO_MINIMO = 0.6  # Evita que um Espaço apertado sem querer pule a tela na hora.
ALTURA_LINHA = 13
LARGURA_DO_TEXTO = LARGURA_TELA - 32


class CenaCartaz(Cena):
    def __init__(self, jogo, linhas, depois, titulo=None, subtitulo=None, instrucao=None, tempo_sozinho=None, opcoes=None):
        """titulo e subtitulo saem grandes. tempo_sozinho fecha o cartaz sem precisar apertar nada."""
        super().__init__(jogo)
        nome = jogo.estado.nome
        self.titulo = resolver(titulo, nome) if titulo else None
        self.subtitulo = resolver(subtitulo, nome) if subtitulo else None
        self.linhas = []
        for linha in linhas:
            texto = resolver(linha, nome)
            self.linhas += quebrar_em_linhas(jogo.fonte, texto, LARGURA_DO_TEXTO) if texto else [""]
        self.instrucao = resolver(instrucao, nome) if instrucao else None
        self.lista = ListaDeOpcoes([resolver(o, nome) for o in opcoes]) if opcoes else None
        self.depois = depois
        self.tempo_sozinho = tempo_sozinho
        self.tempo = 0.0
        self.fechou = False

    def _fechar(self, *escolha):
        if self.fechou:
            return
        self.fechou = True
        self.jogo.desempilhar()
        self.depois(*escolha)

    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        if self.tempo < TEMPO_MINIMO or self.tempo_sozinho is not None:
            return
        if self.lista:
            escolhida = self.lista.tratar_acao(acao)
            if escolhida is not None:
                self._fechar(escolhida)
        elif acao in ("confirmar", "cancelar"):
            self._fechar()

    def atualizar(self, dt):
        self.tempo += dt
        if self.tempo_sozinho is not None and self.tempo >= self.tempo_sozinho:
            self._fechar()

    def desenhar(self, tela):
        fonte = self.jogo.fonte
        tela.fill(cor("neutros.tinta"))
        if self.tempo < TEMPO_PARA_APARECER * 0.3:
            return  # Um instante de tela preta antes do texto.
        grandes = []
        if self.titulo:
            grandes.append(fonte.grande(self.titulo, 2, fonte.cores["texto"]))
        if self.subtitulo:
            grandes.append(fonte.grande(self.subtitulo, 2, fonte.cores["destaque"]))
        # Centraliza o bloco inteiro na altura, deixando espaço para a instrução ou as opções embaixo.
        espaco_embaixo = self.lista.altura() + 6 if self.lista else 18
        altura_total = sum(imagem.get_height() + 6 for imagem in grandes) + len(self.linhas) * ALTURA_LINHA
        y = max(6, (ALTURA_TELA - espaco_embaixo - altura_total) // 2)
        for imagem in grandes:
            tela.blit(imagem, ((tela.get_width() - imagem.get_width()) // 2, y))
            y += imagem.get_height() + 6
        for linha in self.linhas:
            fonte.desenhar_centralizado(tela, y, linha)
            y += ALTURA_LINHA
        if self.tempo < TEMPO_MINIMO:
            return
        if self.lista:
            x = (LARGURA_TELA - self.lista.largura(fonte)) // 2
            self.lista.desenhar(tela, fonte, x, ALTURA_TELA - self.lista.altura() - 4)
        elif self.instrucao:
            fonte.desenhar_centralizado(tela, ALTURA_TELA - 16, self.instrucao, fonte.cores["desativado"], fonte.cores["sombra_desativado"])
