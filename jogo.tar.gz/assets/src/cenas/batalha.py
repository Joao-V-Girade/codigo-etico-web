"""A batalha em turnos (D40). Esta cena só controla de quem é a vez e desenha o menu.

As regras ficam em sistemas/regras_batalha.py, a arena em batalha/arena_tiro.py e o turno do
inimigo em batalha/caixa_desvio.py. Cada parte pode mudar sem mexer nas outras.
"""

import math
import random

import pygame

from src.batalha.arena_tiro import ArenaTiro
from src.batalha.caixa_desvio import CaixaDesvio
from src.cenas.cena import Cena
from src.cenas.dialogo import LARGURA_TEXTO, MAX_LINHAS, CenaDialogo
from src.cenas.reconfiguracao import CenaReconfiguracao
from src.sistemas.cores import cor
from src.sistemas.entrada import acao_do_evento
from src.sistemas.recursos import carregar_imagem, ler_json
from src.sistemas.regras_batalha import Luta
from src.sistemas.textos import resolver
from src.ui.barras import desenhar_barra
from src.ui.caixa_texto import desenhar_caixa, paginar, quebrar_em_linhas

CAIXA_TEXTO = pygame.Rect(8, 94, 304, 56)
Y_STATUS = 151
Y_BOTOES = 164
LARGURA_BOTAO = 70
ALTURA_BOTAO = 14
INTERVALO_BOTOES = 8
BOTOES = ("combate", "analisar", "piedade", "item")
CORES_BOTOES = {"combate": "vila.laranja_forte", "analisar": "vitrine.ciano", "piedade": "vila.sol", "item": "verde.limao"}
ALTURA_LINHA_LISTA = 13
LINHAS_NA_LISTA = 4
Y_INIMIGO_PEQUENO = 30
Y_CHEFE = 12  # O chefe de 96x96 fica um pouco atrás da caixa.
TAMANHO_DO_INIMIGO_PEQUENO = 48
TEMPO_DESMONTANDO = 1.4
TEMPO_TRANSFORMANDO = 1.8


class CenaBatalha(Cena):
    def __init__(self, jogo, id_inimigo, dialogos, com_tutorial=True, itens_iniciais=None):
        super().__init__(jogo)
        self.id_inimigo = id_inimigo
        self.dialogos = dialogos
        self.dados = ler_json("data/inimigos.json")[id_inimigo]
        self.regras = ler_json("data/batalha.json")
        interface = ler_json("data/interface.json")
        self.textos = interface["batalha"]
        self.catalogo_itens = ler_json("data/itens.json")
        # Guarda a mochila do começo da luta, para "tentar de novo" começar igual.
        self.itens_iniciais = dict(jogo.estado.itens) if itens_iniciais is None else dict(itens_iniciais)
        self.luta = Luta(self.dados, self.regras, jogo.estado.itens, modo_historia=jogo.estado.modo_historia, estado=jogo.estado)
        self.avisou_peneira = False
        self.tutorial = com_tutorial and self.dados.get("tutorial", False)
        self.ja_viu_arena = False
        self.ja_viu_desvio = False
        self.avisou_estabilidade = False
        self.avisou_fase2 = False
        self.fila_guardada = None
        self.tempo_transformando = 0.0

        self.modo = "menu"
        self.botao = 0
        self.lista = []
        self.lista_indice = 0
        self.lista_topo = 0
        self.mensagem_da_lista = None
        self.frase = ""
        self.depois = None
        self.arena = None
        self.caixa = None
        self.tempo = 0.0
        self.tempo_de_dano = 0.0
        self.tempo_desmontando = 0.0
        self.sorte = random.Random()

        self.sprites = self._carregar_sprites(id_inimigo)
        self.imagens_botoes = {nome: carregar_imagem(f"assets/ui/botao_{nome}.png") for nome in BOTOES}
        self.icone_restaurar = carregar_imagem("assets/ui/icone_restaurar.png")
        self.lume = [carregar_imagem("assets/sprites/lume/lume_normal.png"), carregar_imagem("assets/sprites/lume/lume_helice.png")]

        self._escolher_frase()
        if self.tutorial:
            # A fala só pode abrir depois que esta cena já estiver na pilha, no primeiro quadro.
            self.modo = "espera"
            self.depois = lambda: self._falar(self.dados["tutorial_falas"], self._abrir_menu)

    def _carregar_sprites(self, id_visual):
        pasta = "assets/sprites/inimigos"
        return {
            nome: carregar_imagem(f"{pasta}/{id_visual}_{nome}.png")
            for nome in ("frente_1", "frente_2", "piscando", "ataque_1", "ataque_2", "dano")
        }

    # ---------- Falas ----------
    def _resolver(self, texto):
        return resolver(texto, self.jogo.estado.nome)

    def _falar(self, falas, depois):
        """Mostra as falas e, quando a caixa fechar, chama a função "depois"."""
        self.modo = "espera"
        self.depois = depois
        self.jogo.empilhar(CenaDialogo(self.jogo, {"falas": falas}, "falas", caixa=CAIXA_TEXTO))

    def _escolher_frase(self):
        if self.luta.pode_restaurar and "frase_estavel" in self.dados:
            self.frase = self._resolver(self.dados["frase_estavel"])
        elif self.dados.get("frases"):
            self.frase = self._resolver(self.sorte.choice(self.dados["frases"]))
        else:
            self.frase = ""

    # ---------- Menu ----------
    def _abrir_menu(self):
        self.modo = "menu"
        self.depois = None
        self._escolher_frase()

    def tratar_evento(self, evento):
        if self.modo == "arena":
            self.arena.tratar_evento(evento)
            return
        if self.modo == "desvio":
            self.caixa.tratar_evento(evento)
            return
        acao = acao_do_evento(evento)
        if acao is None:
            return
        if self.modo == "menu":
            self._evento_no_menu(acao)
        elif self.modo == "lista":
            self._evento_na_lista(acao)
        elif self.modo == "derrota" and acao == "confirmar":
            self._tentar_de_novo()

    def _evento_no_menu(self, acao):
        if acao == "esquerda":
            self.botao = (self.botao - 1) % len(BOTOES)
        elif acao == "direita":
            self.botao = (self.botao + 1) % len(BOTOES)
        elif acao == "confirmar":
            {
                "combate": self._escolher_combate,
                "analisar": self._analisar,
                "piedade": self._abrir_piedade,
                "item": self._abrir_itens,
            }[BOTOES[self.botao]]()

    def _abrir_lista(self, opcoes, mensagem=None):
        self.modo = "lista"
        self.lista = opcoes
        self.lista_indice = 0
        self.lista_topo = 0
        self.mensagem_da_lista = mensagem

    def _evento_na_lista(self, acao):
        if acao == "cancelar":
            self._abrir_menu()
            return
        if not self.lista:
            return
        if acao == "cima":
            self.lista_indice = (self.lista_indice - 1) % len(self.lista)
        elif acao == "baixo":
            self.lista_indice = (self.lista_indice + 1) % len(self.lista)
        elif acao == "confirmar":
            self.lista[self.lista_indice]["ao_escolher"]()
            return
        if self.lista_indice < self.lista_topo:
            self.lista_topo = self.lista_indice
        elif self.lista_indice >= self.lista_topo + LINHAS_NA_LISTA:
            self.lista_topo = self.lista_indice - LINHAS_NA_LISTA + 1

    # ---------- As quatro ações ----------
    def _escolher_combate(self):
        if self.tutorial and not self.ja_viu_arena and "tutorial_arena" in self.dados:
            self.ja_viu_arena = True
            self._falar(self.dados["tutorial_arena"], self._iniciar_arena)
        else:
            self._iniciar_arena()

    def _iniciar_arena(self):
        self.modo = "arena"
        self.arena = ArenaTiro(self.jogo, self.luta, self.regras, self.id_inimigo, self.textos)

    def _analisar(self):
        texto = self._resolver(self.dados["analisar"])
        partes = paginar(self.jogo.fonte, texto, LARGURA_TEXTO, MAX_LINHAS)
        self._falar([{"quem": "{LUME}", "texto": parte} for parte in partes], self._turno_do_inimigo)

    def _abrir_piedade(self):
        opcoes = []
        if self.luta.pode_restaurar:
            opcoes.append({"texto": self.textos["restaurar"], "destaque": True, "ao_escolher": self._restaurar})
        for acao in self.luta.acoes_de_piedade():
            opcoes.append({"texto": self._resolver(acao["texto"]), "ao_escolher": lambda a=acao: self._usar_piedade(a)})
        if self.dados.get("pode_fugir"):
            opcoes.append({"texto": self.textos["fugir"], "ao_escolher": self._fugir})
        self._abrir_lista(opcoes)

    def _usar_piedade(self, acao):
        falas = self.luta.usar_piedade(acao)
        self.jogo.estado.aplicar_efeitos(acao.get("efeitos"))
        self._falar(falas, self._turno_do_inimigo)

    def _abrir_itens(self):
        opcoes = []
        for item_id in self.luta.itens_usaveis(self.catalogo_itens):
            dados = self.catalogo_itens[item_id]
            quantidade = self.jogo.estado.itens[item_id]
            texto = f"{self._resolver(dados['nome'])} x{quantidade}"
            opcoes.append({"texto": texto, "ao_escolher": lambda i=item_id: self._usar_item(i)})
        self._abrir_lista(opcoes, None if opcoes else self.textos["mochila_vazia"])

    def _usar_item(self, item_id):
        dados = self.catalogo_itens[item_id]
        if not self.luta.usar_item(item_id, dados):
            self._falar([{"texto": self.textos["sem_efeito"]}], self._abrir_itens)
            return
        nome = self._resolver(dados["nome"])
        self._falar([{"texto": f"{self.textos['usou']} {nome}."}], self._turno_do_inimigo)

    def _fugir(self):
        self._falar([{"texto": self.textos["fugiu"]}], self.jogo.desempilhar)

    # ---------- Turno do inimigo ----------
    def _turno_do_inimigo(self):
        if self.luta.aviso_pendente:
            self.luta.concluir_aviso()
            self._falar(self.dados["fala_integridade_20"], self._turno_do_inimigo)
            return
        if self.tutorial and not self.ja_viu_desvio and "tutorial_desvio" in self.dados:
            self.ja_viu_desvio = True
            self._falar(self.dados["tutorial_desvio"], self._iniciar_desvio)
            return
        if "ult" not in self.dados and self.luta.em_fase2 and not self.avisou_fase2:
            self.avisou_fase2 = True  # Só o chefe de teste, que não tem ult, muda de fase aqui.
            if "fala_fase2" in self.dados:
                self._falar(self.dados["fala_fase2"], self._iniciar_desvio)
                return
        self._iniciar_desvio()

    def _comecar_transformacao(self):
        self.modo = "transformando"
        self.tempo_transformando = 0.0

    def _terminar_transformacao(self):
        self.luta.transformar()
        self.sprites = self._carregar_sprites(self.id_inimigo + self.luta.sufixo_visual())
        self._avisar_fase2()

    def _avisar_fase2(self):
        self.avisou_fase2 = True
        if "fala_fase2" in self.dados:
            self._falar(self.dados["fala_fase2"], self._abrir_menu)
        else:
            self._abrir_menu()

    def _iniciar_ult(self):
        """O ataque supremo toma o turno inteiro, sozinho."""
        ult = self.luta.ult_atual
        self.modo = "desvio"
        self.caixa = CaixaDesvio(self.jogo, self.luta, self.regras, [ult["padrao"]], CAIXA_TEXTO, titulo=ult["nome"])

    def _fazer_pergunta(self, pergunta):
        """No ato final, a ÍRIS pergunta. As respostas não dão nem tiram pontos: são reflexão."""
        self.luta.perguntas_feitas += 1
        dialogos = {
            "pergunta": [{"quem": "{IRIS}", "texto": pergunta["texto"], "escolhas": [{"texto": r, "ir_para": "retorno"} for r in pergunta["respostas"]]}],
            "retorno": [{"quem": "{IRIS}", "texto": pergunta["retorno"]}],
        }
        self.modo = "espera"
        self.depois = self._ataque_do_turno
        self.jogo.empilhar(CenaDialogo(self.jogo, dialogos, "pergunta", caixa=CAIXA_TEXTO))

    def _ataque_do_turno(self):
        if self.fila_guardada:
            fila, self.fila_guardada = self.fila_guardada, None
        else:
            if self.luta.em_ato_final:
                padroes = self.dados["padroes_ato_final"]
            else:
                padroes = self.dados["padroes_fase2"] if self.luta.em_fase2 else self.dados["padroes"]
            fila = self.luta.proximos_ataques(padroes, self.luta.ataques_no_turno(), self.sorte)
        if "peneira" in fila and "fala_durante_peneira" in self.dados and not self.avisou_peneira:
            self.avisou_peneira = True
            self.fila_guardada = fila
            self._falar([self.dados["fala_durante_peneira"]], self._ataque_do_turno)
            return
        self.modo = "desvio"
        self.caixa = CaixaDesvio(self.jogo, self.luta, self.regras, fila, CAIXA_TEXTO)
        self.caixa.com_revisao = self.luta.revisao_pendente
        self.luta.revisao_pendente = False  # A REVISÃO vale para um turno só.

    def _iniciar_desvio(self):
        if self.luta.deve_usar_ult():
            self._falar(self.luta.ult_atual["falas"], self._iniciar_ult)
            return
        pergunta = self.luta.proxima_pergunta() if self.luta.em_ato_final else None
        if pergunta:
            self._fazer_pergunta(pergunta)
            return
        self._ataque_do_turno()

    def _fim_do_desvio(self):
        foi_supremo = bool(self.caixa.titulo)
        self.caixa = None
        self.luta.fim_de_turno()
        if self.luta.derrotada:
            self.modo = "derrota"
            return
        if foi_supremo:
            self.luta.depois_do_supremo()
            if self.luta.transformacao_pendente:
                self._falar(self.dados["segunda_forma"]["falas"], self._comecar_transformacao)
                return
            if self.luta.em_fase2 and not self.avisou_fase2:
                self._avisar_fase2()
                return
        if self.luta.pode_restaurar and not self.avisou_estabilidade and "fala_estabilidade_100" in self.dados:
            self.avisou_estabilidade = True
            self._falar(self.dados["fala_estabilidade_100"], self._abrir_menu)
            return
        self._abrir_menu()

    # ---------- Fins da batalha ----------
    def _restaurar(self):
        self.modo = "espera"
        self.depois = self._terminar_restaurado
        self.jogo.empilhar(CenaReconfiguracao(self.jogo, self.dados["reconfiguracao"]))

    def _terminar_restaurado(self):
        self._encerrar(self.dados.get("apos_restaurar"))

    def _encerrar(self, sequencia):
        self.jogo.desempilhar()
        # Chefes de outras fases ainda não têm falas no Prólogo: testados aqui, a luta só termina (D56).
        if sequencia in self.dialogos:
            self.jogo.empilhar(CenaDialogo(self.jogo, self.dialogos, sequencia))

    def _tentar_de_novo(self):
        self.jogo.estado.itens.clear()
        self.jogo.estado.itens.update(self.itens_iniciais)
        self.jogo.desempilhar()
        self.jogo.empilhar(CenaBatalha(self.jogo, self.id_inimigo, self.dialogos, com_tutorial=False, itens_iniciais=self.itens_iniciais))

    # ---------- Atualização ----------
    def atualizar(self, dt):
        self.tempo += dt
        self.tempo_de_dano = max(0.0, self.tempo_de_dano - dt)
        if self.modo == "espera":
            depois, self.depois = self.depois, None
            if depois:
                depois()
        elif self.modo == "arena":
            self.arena.atualizar(dt)
            if self.arena.terminou:
                self._fim_da_arena()
        elif self.modo == "desvio":
            antes = self.luta.vida
            self.caixa.atualizar(dt)
            if self.luta.vida < antes:
                self.tempo_de_dano = 0.2
            if self.caixa.terminou:
                self._fim_do_desvio()
        elif self.modo == "transformando":
            self.tempo_transformando += dt
            if self.tempo_transformando >= TEMPO_TRANSFORMANDO:
                self._terminar_transformacao()
        elif self.modo == "desmontando":
            self.tempo_desmontando += dt
            if self.tempo_desmontando >= TEMPO_DESMONTANDO:
                self._encerrar(self.dados.get("apos_destruir"))

    def _fim_da_arena(self):
        self.arena.finalizar()
        self.arena = None
        if self.luta.destruido:
            self.modo = "desmontando"
        else:
            self._turno_do_inimigo()

    # ---------- Desenho ----------
    def _sprite_do_inimigo(self):
        if self.tempo_de_dano > 0 or self.modo == "desmontando":
            return self.sprites["dano"]
        if self.modo == "desvio":
            return self.sprites["ataque_1" if int(self.tempo * 8) % 2 else "ataque_2"]
        if int(self.tempo) % 5 == 4 and int(self.tempo * 8) % 8 == 0:
            return self.sprites["piscando"]
        return self.sprites["frente_1" if int(self.tempo * 3) % 2 else "frente_2"]

    def _desenhar_fundo(self, tela):
        tela.fill(cor("neutros.tinta"))
        cenario = self.regras["arenas"][self.dados["arena"]]
        faixa = cor(cenario["cor_de_fundo"])
        pygame.draw.rect(tela, faixa, (0, 74, 320, 3))
        pygame.draw.rect(tela, faixa, (0, 80, 320, 1))
        pygame.draw.rect(tela, faixa, (0, 84, 320, 1))

    def _desenhar_inimigo(self, tela):
        imagem = self._sprite_do_inimigo()
        x = (320 - imagem.get_width()) // 2
        y = Y_INIMIGO_PEQUENO if imagem.get_height() <= TAMANHO_DO_INIMIGO_PEQUENO else Y_CHEFE
        if self.modo == "desmontando":
            x += int(math.sin(self.tempo_desmontando * 40) * 3)
            y += int(self.tempo_desmontando * 6)
            sorte = random.Random(int(self.tempo_desmontando * 12))
            tela.blit(imagem, (x, y))
            for _ in range(6):
                faisca = (x + sorte.randrange(imagem.get_width()), y + sorte.randrange(imagem.get_height()))
                pygame.draw.rect(tela, cor(sorte.choice(("vila.sol", "vila.laranja_forte", "neutros.branco"))), (*faisca, 2, 2))
            return
        tela.blit(imagem, (x, y))

    def _desenhar_transformacao(self, tela):
        """Provisório (FP4): clarões cada vez mais fortes até a segunda forma aparecer."""
        fracao = min(1.0, self.tempo_transformando / TEMPO_TRANSFORMANDO)
        if int(self.tempo_transformando * (6 + fracao * 18)) % 2:
            clarao = pygame.Surface(tela.get_size(), pygame.SRCALPHA)
            vermelho = pygame.Color(cor("vermelho.vermelho"))
            clarao.fill((vermelho.r, vermelho.g, vermelho.b, int(60 + fracao * 150)))
            tela.blit(clarao, (0, 0))

    def _desenhar_barras_do_inimigo(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        nome = self._resolver(self.dados["nome"])
        fonte.desenhar(tela, 8, 1, nome, cores["nomes"]["MODULO"])
        if self.luta.pode_restaurar:
            tela.blit(self.icone_restaurar, (10 + fonte.largura(nome), 3))
        fonte.desenhar(tela, 104, 1, self.textos["integridade"], cores["texto"])
        integridade = self.luta.integridade / self.luta.integridade_maxima
        if self.modo == "transformando":  # A barra sobe à vista: é a vida voltando.
            alvo = self.luta.vida_depois_da_transformacao() / self.luta.integridade_maxima
            integridade += (alvo - integridade) * min(1.0, self.tempo_transformando / TEMPO_TRANSFORMANDO)
        desenhar_barra(tela, (178, 5, 134, 6), integridade, cor("vila.laranja_forte"))
        fonte.desenhar(tela, 104, 13, self.textos["estabilidade"], cores["texto"])
        cheia = self.luta.pode_restaurar and int(self.tempo * 6) % 2
        desenhar_barra(tela, (178, 17, 110, 6), self.luta.estabilidade / 100, cor("vila.creme" if cheia else "vila.sol"))
        fonte.desenhar(tela, 291, 13, f"{self.luta.estabilidade}%", cores["texto"])
        situacao = self.luta.texto_da_mecanica(self.textos)
        if situacao:
            fonte.desenhar(tela, 8, 13, situacao, cor("vila.sol"), cor("neutros.tinta"))

    def _cor_da_vida(self):
        fracao = self.luta.vida / self.luta.vida_maxima
        if fracao > 0.5:
            return cor("verde.limao")
        return cor("vila.sol") if fracao > 0.25 else cor("vermelho.vermelho")

    def _desenhar_status(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        fonte.desenhar(tela, 8, Y_STATUS, self.jogo.estado.nome, cores["nomes"]["ADA"])
        fonte.desenhar(tela, 66, Y_STATUS, self.textos["vida"], cores["texto"])
        desenhar_barra(tela, (92, Y_STATUS + 4, 44, 6), self.luta.vida / self.luta.vida_maxima, self._cor_da_vida())
        fonte.desenhar(tela, 139, Y_STATUS, f"{self.luta.vida}/{self.luta.vida_maxima}", cores["texto"])
        fonte.desenhar(tela, 174, Y_STATUS, self.textos["energia"], cores["texto"])
        desenhar_barra(tela, (219, Y_STATUS + 4, 56, 6), self.luta.energia / self.luta.energia_maxima, cor("vitrine.ciano"))
        fonte.desenhar(tela, 278, Y_STATUS, f"{self.luta.energia}/{self.luta.energia_maxima}", cores["texto"])

    def _lume_cursor(self, tela, x, y):
        quadro = self.lume[int(self.tempo * 10) % 2]
        balanco = int(math.sin(self.tempo * 4) * 1)
        tela.blit(quadro, (x, y + balanco))

    def _desenhar_botoes(self, tela):
        fonte = self.jogo.fonte
        selecionando = self.modo == "menu"
        for indice, nome in enumerate(BOTOES):
            x = 8 + indice * (LARGURA_BOTAO + INTERVALO_BOTOES)
            tela.blit(self.imagens_botoes[nome], (x, Y_BOTOES))
            escolhido = selecionando and indice == self.botao
            if escolhido and int(self.tempo * 4) % 2 == 0:
                pygame.draw.rect(tela, cor("neutros.branco"), (x, Y_BOTOES, LARGURA_BOTAO, ALTURA_BOTAO), 1)
            if escolhido:
                self._lume_cursor(tela, x, Y_BOTOES + 1)
            texto = self.textos[nome]
            fonte.desenhar(tela, x + 17, Y_BOTOES + 1, texto, cor(CORES_BOTOES[nome]), cor("neutros.grafite"))

    def _desenhar_caixa_de_texto(self, tela):
        cores = self.jogo.fonte.cores
        desenhar_caixa(tela, CAIXA_TEXTO, cores["borda_caixa"], cores["fundo_caixa"])

    def _desenhar_frase(self, tela):
        fonte = self.jogo.fonte
        for indice, linha in enumerate(quebrar_em_linhas(fonte, self.frase, LARGURA_TEXTO)[:MAX_LINHAS]):
            fonte.desenhar(tela, CAIXA_TEXTO.left + 8, CAIXA_TEXTO.top + 3 + indice * fonte.altura_linha, linha)

    def _desenhar_lista(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        x = CAIXA_TEXTO.left + 24
        if self.mensagem_da_lista:
            fonte.desenhar(tela, CAIXA_TEXTO.left + 8, CAIXA_TEXTO.top + 3, self.mensagem_da_lista)
        visiveis = self.lista[self.lista_topo : self.lista_topo + LINHAS_NA_LISTA]
        for deslocamento, opcao in enumerate(visiveis):
            indice = self.lista_topo + deslocamento
            y = CAIXA_TEXTO.top + 2 + deslocamento * ALTURA_LINHA_LISTA
            selecionada = indice == self.lista_indice
            cor_texto = cores["selecionado"] if selecionada else cores["texto"]
            if opcao.get("destaque"):
                cor_texto = cores["destaque"]
            if selecionada:
                self._lume_cursor(tela, CAIXA_TEXTO.left + 5, y + 1)
            fonte.desenhar(tela, x, y, opcao["texto"], cor_texto)
        if self.lista_topo > 0:
            x_seta = CAIXA_TEXTO.right - 10
            topo = CAIXA_TEXTO.top + 4
            pygame.draw.polygon(tela, cores["texto"], [(x_seta, topo + 3), (x_seta + 4, topo + 3), (x_seta + 2, topo)])
        if self.lista_topo + LINHAS_NA_LISTA < len(self.lista):
            fonte.desenhar(tela, CAIXA_TEXTO.right - 12, CAIXA_TEXTO.bottom - 15, "▼")

    def _desenhar_derrota(self, tela):
        fonte = self.jogo.fonte
        fonte.desenhar(tela, CAIXA_TEXTO.left + 8, CAIXA_TEXTO.top + 3, self.textos["derrota"])
        y = CAIXA_TEXTO.top + 3 + 2 * fonte.altura_linha
        self._lume_cursor(tela, CAIXA_TEXTO.left + 5, y + 1)
        fonte.desenhar(tela, CAIXA_TEXTO.left + 24, y, self.textos["tentar_de_novo"], fonte.cores["selecionado"])

    def desenhar(self, tela):
        if self.modo == "arena":
            self.arena.desenhar(tela)
            return
        self._desenhar_fundo(tela)
        if self.modo == "desvio" and self.caixa.tela_cheia:
            self.caixa.desenhar(tela)
            return
        self._desenhar_inimigo(tela)
        if self.modo == "transformando":
            self._desenhar_transformacao(tela)
        self._desenhar_barras_do_inimigo(tela)
        self._desenhar_status(tela)
        self._desenhar_botoes(tela)
        if self.modo == "desvio":
            self.caixa.desenhar(tela)
            return
        self._desenhar_caixa_de_texto(tela)
        if self.modo == "lista":
            self._desenhar_lista(tela)
        elif self.modo == "derrota":
            self._desenhar_derrota(tela)
        elif self.modo == "menu":
            self._desenhar_frase(tela)
