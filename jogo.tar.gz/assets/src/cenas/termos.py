"""Termos de Uso da Loja Tudo Smart (Fase 2, evidência 1): o consentimento escondido em 80 páginas.

A janela tem dois botões, como nos sites de verdade: "ACEITO", grande, colorido e piscando, e
"Ler", pequeno e cinza. Quem aceita sem ler ouve o Lume perguntar se leu. Quem escolhe "Ler" rola o
texto segurando baixo. Quase tudo é bobagem engraçada, mas a Cláusula 47 aparece em letra miúda,
quase impossível de ler. O jogador para a linha dela na marca do meio e aperta Espaço para marcar.

Os textos ficam em data/termos.json. A cena não sabe de flags nem de evidências: ela só avisa como
terminou ("aceito", "achou" ou "saiu"), e quem a abriu decide a fala seguinte (src/jogo.py).
"""

import pygame

from config import ALTURA_TELA, LARGURA_TELA
from src.cenas.cena import Cena
from src.sistemas.entrada import acao_do_evento, esta_pressionada
from src.sistemas.recursos import ler_json
from src.sistemas.textos import resolver
from src.ui.caixa_texto import desenhar_caixa, quebrar_em_linhas

JANELA = pygame.Rect(12, 4, LARGURA_TELA - 24, ALTURA_TELA - 8)
AREA = pygame.Rect(JANELA.left + 8, JANELA.top + 18, JANELA.width - 16, 104)
ALTURA_LINHA = 12
ALTURA_MIUDA = 6  # A letra miúda sai com metade do tamanho.
ESPACO_ENTRE_CLAUSULAS = 4
VELOCIDADE = 70  # pixels por segundo, segurando baixo
TEMPO_DO_AVISO = 1.5


class CenaTermos(Cena):
    def __init__(self, jogo, ao_terminar):
        super().__init__(jogo)
        self.dados = ler_json("data/termos.json")
        self.ao_terminar = ao_terminar
        self.modo = "botoes"
        self.botao = 0  # 0 = ACEITO, 1 = Ler
        self.rolagem = 0.0
        self.tempo = 0.0
        self.aviso = 0.0
        self.fechou = False
        self._montar_linhas()

    # ---------- Texto ----------
    def _montar_linhas(self):
        """Quebra cada cláusula em linhas. Cada linha guarda a posição, a altura e o número da cláusula."""
        fonte = self.jogo.fonte
        self.linhas = []
        y = 0
        for clausula in self.dados["clausulas"]:
            miuda = clausula["numero"] == self.dados["escondida"]
            texto = resolver(f"{clausula['numero']}. {clausula['texto']}", self.jogo.estado.nome)
            # A letra miúda cabe duas vezes mais texto por linha.
            largura = AREA.width * 2 - 8 if miuda else AREA.width - 8
            for linha in quebrar_em_linhas(fonte, texto, largura):
                altura = ALTURA_MIUDA if miuda else ALTURA_LINHA
                self.linhas.append({"texto": linha, "y": y, "altura": altura, "numero": clausula["numero"], "miuda": miuda})
                y += altura
            y += ESPACO_ENTRE_CLAUSULAS
        self.altura_total = y
        self.rolagem_maxima = max(0, self.altura_total - AREA.height // 2)

    @property
    def y_da_marca(self):
        """A linha que está na marca do meio é a que o Espaço marca."""
        return AREA.top + AREA.height // 2

    def linha_na_marca(self):
        alvo = self.y_da_marca - AREA.top + self.rolagem
        for linha in self.linhas:
            if linha["y"] - 2 <= alvo < linha["y"] + linha["altura"] + 2:
                return linha
        return None

    def pagina(self):
        if not self.rolagem_maxima:
            return 1
        return 1 + round(self.rolagem / self.rolagem_maxima * (self.dados["paginas"] - 1))

    # ---------- Teclas ----------
    def _fechar(self, resultado):
        if self.fechou:
            return
        self.fechou = True
        self.jogo.desempilhar()
        self.ao_terminar(resultado)

    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        if self.modo == "botoes":
            if acao in ("esquerda", "direita"):
                self.botao = 1 - self.botao
            elif acao == "confirmar":
                if self.botao == 0:
                    self._fechar("aceito")
                else:
                    self.modo = "leitura"
            elif acao == "cancelar":
                self._fechar("saiu")
            return
        if acao == "cancelar":
            self.modo = "botoes"
        elif acao == "confirmar":
            linha = self.linha_na_marca()
            if linha and linha["numero"] == self.dados["escondida"]:
                self._fechar("achou")
            else:
                self.aviso = TEMPO_DO_AVISO

    def atualizar(self, dt):
        self.tempo += dt
        self.aviso = max(0.0, self.aviso - dt)
        if self.modo == "leitura":
            if esta_pressionada("baixo"):
                self.rolar(VELOCIDADE * dt)
            if esta_pressionada("cima"):
                self.rolar(-VELOCIDADE * dt)

    def rolar(self, pixels):
        self.rolagem = max(0.0, min(self.rolagem_maxima, self.rolagem + pixels))

    # ---------- Desenho ----------
    def _linha_miuda(self, texto, cor_texto):
        fonte = self.jogo.fonte
        superficie = pygame.Surface((fonte.largura(texto) + 2, ALTURA_LINHA), pygame.SRCALPHA)
        fonte.desenhar(superficie, 0, 0, texto, cor_texto, cor_texto)
        largura, altura = superficie.get_size()
        return pygame.transform.scale(superficie, (max(1, largura // 2), max(1, altura // 2)))

    def desenhar(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        sombra = pygame.Surface((LARGURA_TELA, ALTURA_TELA), pygame.SRCALPHA)
        sombra.fill((0, 0, 0, 150))
        tela.blit(sombra, (0, 0))
        desenhar_caixa(tela, JANELA, cores["claro_texto"], cores["claro_fundo"])
        fonte.desenhar(tela, JANELA.left + 8, JANELA.top + 4, resolver(self.dados["titulo"], self.jogo.estado.nome), cores["claro_texto"], cores["claro_sombra"])

        # O texto, recortado na área de leitura.
        recorte_antigo = tela.get_clip()
        tela.set_clip(AREA)
        for linha in self.linhas:
            y = AREA.top + linha["y"] - int(self.rolagem)
            if y + linha["altura"] < AREA.top or y > AREA.bottom:
                continue
            if linha["miuda"]:
                tela.blit(self._linha_miuda(linha["texto"], cores["claro_sombra"]), (AREA.left + 4, y))
            else:
                fonte.desenhar(tela, AREA.left + 4, y, linha["texto"], cores["claro_texto"], cores["claro_fundo"])
        tela.set_clip(recorte_antigo)

        if self.modo == "leitura":
            # A marca do meio: o que estiver nela é o que o Espaço marca.
            marca = pygame.Rect(AREA.left, self.y_da_marca - 1, AREA.width, ALTURA_LINHA)
            pygame.draw.rect(tela, cores["alerta"], marca, 1)
            fonte.desenhar(tela, JANELA.right - 8 - fonte.largura(self._texto_pagina()), JANELA.top + 4, self._texto_pagina(), cores["claro_sombra"], cores["claro_fundo"])
        self._desenhar_rodape(tela)

    def _texto_pagina(self):
        return self.dados["pagina"].replace("{N}", str(self.pagina()))

    def _desenhar_rodape(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        y = AREA.bottom + 6
        if self.modo == "leitura":
            texto = self.dados["nada_aqui"] if self.aviso > 0 else self.dados["instrucao_leitura"]
            fonte.desenhar(tela, AREA.left, y + 14, texto, cores["claro_texto"], cores["claro_sombra"])
            return
        # ACEITO: grande, verde e piscando. Ler: pequeno e cinza, no canto. Como nos sites de verdade.
        piscando = int(self.tempo * 3) % 2 == 0
        aceito = fonte.grande(self.dados["aceito"], 2, cores["positivo"] if piscando else cores["destaque"], cores["claro_texto"])
        x_aceito = JANELA.left + (JANELA.width - aceito.get_width()) // 2 - 20
        tela.blit(aceito, (x_aceito, y))
        ler = self.dados["ler"]
        x_ler = JANELA.right - 12 - fonte.largura(ler)
        fonte.desenhar(tela, x_ler, y + 14, ler, cores["claro_sombra"], cores["claro_fundo"])
        if self.botao == 0:
            pygame.draw.rect(tela, cores["claro_texto"], (x_aceito - 3, y - 2, aceito.get_width() + 6, aceito.get_height() + 3), 1)
        else:
            pygame.draw.rect(tela, cores["claro_texto"], (x_ler - 3, y + 12, fonte.largura(ler) + 6, ALTURA_LINHA + 1), 1)
