"""Configurações (D51): velocidade do texto, flashes e volume. Abre no título e no menu de pausa.

As escolhas ficam em estado.configuracoes. A demo não salva, então elas valem até fechar o jogo.
"""

import pygame

from config import LARGURA_TELA
from src.cenas.cena import Cena
from src.sistemas.entrada import acao_do_evento
from src.sistemas.recursos import ler_json
from src.ui.caixa_texto import desenhar_caixa

VELOCIDADES = ("lenta", "normal", "rapida")
PASSO_DO_VOLUME = 10
CAIXA = pygame.Rect(40, 34, LARGURA_TELA - 80, 104)
ALTURA_LINHA = 16


def mudar_configuracao(configuracoes, chave, passo):
    """Muda uma configuração para o próximo valor. Não depende do Pygame, para ser testada."""
    if chave == "velocidade_texto":
        atual = VELOCIDADES.index(configuracoes[chave])
        configuracoes[chave] = VELOCIDADES[max(0, min(len(VELOCIDADES) - 1, atual + passo))]
    elif chave == "flashes":
        configuracoes[chave] = not configuracoes[chave]
    elif chave == "volume":
        configuracoes[chave] = max(0, min(100, configuracoes[chave] + passo * PASSO_DO_VOLUME))


class CenaConfiguracoes(Cena):
    CHAVES = ("velocidade_texto", "flashes", "volume")

    def __init__(self, jogo):
        super().__init__(jogo)
        self.textos = ler_json("data/interface.json")["configuracoes"]
        self.indice = 0

    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        configuracoes = self.jogo.estado.configuracoes
        chave = self.CHAVES[self.indice]
        if acao == "cima":
            self.indice = (self.indice - 1) % len(self.CHAVES)
        elif acao == "baixo":
            self.indice = (self.indice + 1) % len(self.CHAVES)
        elif acao == "esquerda":
            mudar_configuracao(configuracoes, chave, -1)
        elif acao == "direita":
            mudar_configuracao(configuracoes, chave, 1)
        elif acao == "confirmar" and chave == "flashes":
            mudar_configuracao(configuracoes, chave, 1)
        elif acao in ("cancelar", "menu"):
            self.jogo.desempilhar()

    def _valor(self, chave):
        valor = self.jogo.estado.configuracoes[chave]
        if chave == "velocidade_texto":
            return self.textos[valor]
        if chave == "flashes":
            return self.textos["ligados" if valor else "desligados"]
        return f"{valor}%"

    def desenhar(self, tela):
        fonte = self.jogo.fonte
        desenhar_caixa(tela, CAIXA, fonte.cores["borda_caixa"], fonte.cores["fundo_caixa"])
        fonte.desenhar_centralizado(tela, CAIXA.top + 6, self.textos["titulo"], fonte.cores["destaque"])
        for i, chave in enumerate(self.CHAVES):
            y = CAIXA.top + 26 + i * ALTURA_LINHA
            selecionada = i == self.indice
            cor = fonte.cores["selecionado"] if selecionada else fonte.cores["texto"]
            if selecionada:
                fonte.desenhar(tela, CAIXA.left + 8, y, "▶", cor)
            fonte.desenhar(tela, CAIXA.left + 18, y, self.textos[chave], cor)
            valor = self._valor(chave)
            x_valor = CAIXA.right - 18 - fonte.largura(valor)
            fonte.desenhar(tela, x_valor, y, valor, cor)
            if selecionada:
                # A fonte não tem "<" nem ">": as setinhas são desenhadas.
                meio = y + 6
                pygame.draw.polygon(tela, cor, [(x_valor - 4, meio - 3), (x_valor - 4, meio + 3), (x_valor - 7, meio)])
                direita = CAIXA.right - 14
                pygame.draw.polygon(tela, cor, [(direita, meio - 3), (direita, meio + 3), (direita + 3, meio)])
        # O volume já fica guardado para quando os sons entrarem.
        cinza, sombra = fonte.cores["desativado"], fonte.cores["sombra_desativado"]
        fonte.desenhar_centralizado(tela, CAIXA.top + 76, self.textos["sem_som"], cinza, sombra)
        fonte.desenhar_centralizado(tela, CAIXA.bottom - 15, self.textos["instrucao"], cinza, sombra)
