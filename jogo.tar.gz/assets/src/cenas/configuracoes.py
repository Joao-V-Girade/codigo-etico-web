"""Configurações (D51): velocidade do texto, flashes e volume. Abre no título e no menu de pausa.

As escolhas ficam em estado.configuracoes. A demo não salva, então elas valem até fechar o jogo.
No menu de pausa, também dá para trocar entre Normal e Modo História (D98). No título, não: ali ainda
não há partida, e a escolha é feita em Novo Jogo. A troca vale a partir da próxima luta.
"""

import pygame

from config import LARGURA_TELA
from src.cenas.cena import Cena
from src.sistemas.entrada import acao_do_evento
from src.sistemas.recursos import ler_json
from src.ui.caixa_texto import desenhar_caixa

VELOCIDADES = ("lenta", "normal", "rapida")
PASSO_DO_VOLUME = 10
CAIXA = pygame.Rect(40, 34, LARGURA_TELA - 80, 104)  # Com as 3 linhas de sempre.
ALTURA_LINHA = 16


def mudar_configuracao(configuracoes, chave, passo):
    """Muda uma configuração para o próximo valor. Não depende do Pygame, para ser testada."""
    if chave == "velocidade_texto":
        atual = VELOCIDADES.index(configuracoes[chave])
        configuracoes[chave] = VELOCIDADES[max(0, min(len(VELOCIDADES) - 1, atual + passo))]
    elif chave == "flashes":
        configuracoes[chave] = not configuracoes[chave]
    elif chave == "volume":
        configuracoes[chave] = max(0, min(100, configuracoes[chave] + passo * PASSO_DO_VOLUME))


class CenaConfiguracoes(Cena):
    CHAVES = ("velocidade_texto", "flashes", "volume")

    def __init__(self, jogo, com_dificuldade=False):
        super().__init__(jogo)
        self.textos = ler_json("data/interface.json")["configuracoes"]
        self.chaves = (("dificuldade",) if com_dificuldade else ()) + self.CHAVES
        self.caixa = CAIXA.inflate(0, ALTURA_LINHA * (len(self.chaves) - len(self.CHAVES)))
        self.indice = 0

    def _mudar(self, chave, passo):
        if chave == "dificuldade":
            self.jogo.estado.modo_historia = not self.jogo.estado.modo_historia
        else:
            mudar_configuracao(self.jogo.estado.configuracoes, chave, passo)

    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        chave = self.chaves[self.indice]
        if acao == "cima":
            self.indice = (self.indice - 1) % len(self.chaves)
        elif acao == "baixo":
            self.indice = (self.indice + 1) % len(self.chaves)
        elif acao == "esquerda":
            self._mudar(chave, -1)
        elif acao == "direita":
            self._mudar(chave, 1)
        elif acao == "confirmar" and chave in ("flashes", "dificuldade"):
            self._mudar(chave, 1)
        elif acao in ("cancelar", "menu"):
            self.jogo.desempilhar()

    def _valor(self, chave):
        if chave == "dificuldade":
            return self.textos["modo_historia" if self.jogo.estado.modo_historia else "modo_normal"]
        valor = self.jogo.estado.configuracoes[chave]
        if chave == "velocidade_texto":
            return self.textos[valor]
        if chave == "flashes":
            return self.textos["ligados" if valor else "desligados"]
        return f"{valor}%"

    def desenhar(self, tela):
        fonte = self.jogo.fonte
        caixa = self.caixa
        desenhar_caixa(tela, caixa, fonte.cores["borda_caixa"], fonte.cores["fundo_caixa"])
        fonte.desenhar_centralizado(tela, caixa.top + 6, self.textos["titulo"], fonte.cores["destaque"])
        for i, chave in enumerate(self.chaves):
            y = caixa.top + 26 + i * ALTURA_LINHA
            selecionada = i == self.indice
            cor = fonte.cores["selecionado"] if selecionada else fonte.cores["texto"]
            if selecionada:
                fonte.desenhar(tela, caixa.left + 8, y, "▶", cor)
            fonte.desenhar(tela, caixa.left + 18, y, self.textos[chave], cor)
            valor = self._valor(chave)
            x_valor = caixa.right - 18 - fonte.largura(valor)
            fonte.desenhar(tela, x_valor, y, valor, cor)
            if selecionada:
                # A fonte não tem "<" nem ">": as setinhas são desenhadas.
                meio = y + 6
                pygame.draw.polygon(tela, cor, [(x_valor - 4, meio - 3), (x_valor - 4, meio + 3), (x_valor - 7, meio)])
                direita = caixa.right - 14
                pygame.draw.polygon(tela, cor, [(direita, meio - 3), (direita, meio + 3), (direita + 3, meio)])
        # O volume já fica guardado para quando os sons entrarem.
        cinza, sombra = fonte.cores["desativado"], fonte.cores["sombra_desativado"]
        fonte.desenhar_centralizado(tela, caixa.bottom - 28, self.textos["sem_som"], cinza, sombra)
        fonte.desenhar_centralizado(tela, caixa.bottom - 15, self.textos["instrucao"], cinza, sombra)
