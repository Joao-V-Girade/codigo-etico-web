"""Classe base das telas do jogo. Cada tela (título, mapa, batalha...) é uma Cena."""


class Cena:
    def __init__(self, jogo):
        self.jogo = jogo

    def tratar_evento(self, evento):
        """Recebe teclas e cliques. Só a cena do topo da pilha recebe."""

    def atualizar(self, dt):
        """Atualiza a lógica. dt = segundos desde o último quadro."""

    def desenhar(self, tela):
        """Desenha a cena. Todas as cenas da pilha são desenhadas, de baixo para cima."""
