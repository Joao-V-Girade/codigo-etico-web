"""Linha do tempo do Canal 8 (Fase 3, evidência 1): achar o vídeo verdadeiro que virou o deepfake.

O técnico guarda tudo o que as câmeras públicas filmaram. O jogador passa pelos vídeos, um por hora,
e compara cada um com o vídeo falso. Só um tem os mesmos movimentos: a Ada consertando (ou
enfrentando) o ZIM na Vila Circuito. Os outros mostram que o "ataque" nunca aconteceu, como a
câmera do hospital, mas não são a prova. Os textos ficam em data/linha_do_tempo.json.
"""

import pygame

from src.cenas.cena import Cena
from src.sistemas.cores import cor
from src.sistemas.entrada import acao_do_evento
from src.sistemas.recursos import ler_json
from src.sistemas.textos import resolver
from src.ui.caixa_texto import desenhar_caixa, quebrar_em_linhas

JANELA = pygame.Rect(8, 8, 304, 164)
FAIXA_Y = 34
MINIATURA = (40, 28)
DETALHE = pygame.Rect(20, 92, 280, 44)
ALTURA_LINHA = 11
CORES_DAS_MINIATURAS = ("vila.sol", "balanca.bege", "verde.grama", "vitrine.ciano", "eco.violeta", "neutros.gelo")


class CenaLinhaDoTempo(Cena):
    def __init__(self, jogo, _nome, ao_terminar):
        super().__init__(jogo)
        self.dados = ler_json("data/linha_do_tempo.json")
        self.ao_terminar = ao_terminar
        self.escolhido = 0
        self.aviso = ""
        self.fechou = False

    @property
    def clipes(self):
        return self.dados["clipes"]

    def _texto(self, texto):
        return resolver(texto, self.jogo.estado.nome)

    def texto_do_clipe(self, clipe):
        if self.jogo.estado.flags.get("zim_resultado") == "destruido" and "texto_zim_destruido" in clipe:
            return self._texto(clipe["texto_zim_destruido"])
        return self._texto(clipe["texto"])

    def comparar(self):
        """Compara o vídeo escolhido com o falso. O certo fecha a tela; os outros mostram um aviso."""
        if self.clipes[self.escolhido].get("certo"):
            self._fechar("achou")
            return True
        self.aviso = self._texto(self.dados["nao_bate"])
        return False

    def _fechar(self, resultado):
        if self.fechou:
            return
        self.fechou = True
        self.jogo.desempilhar()
        self.ao_terminar(self.dados["depois"].get(resultado))

    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        if acao in ("esquerda", "direita"):
            self.escolhido = (self.escolhido + (1 if acao == "direita" else -1)) % len(self.clipes)
            self.aviso = ""
        elif acao == "confirmar":
            self.comparar()
        elif acao == "cancelar":
            self._fechar("saiu")

    def desenhar(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        sombra = pygame.Surface(tela.get_size(), pygame.SRCALPHA)
        sombra.fill((0, 0, 0, 160))
        tela.blit(sombra, (0, 0))
        desenhar_caixa(tela, JANELA, cores["borda_caixa"], cores["fundo_caixa"])
        fonte.desenhar(tela, JANELA.left + 6, JANELA.top + 4, self._texto(self.dados["titulo"]), cores["destaque"], cores["sombra"])

        # A faixa de vídeos, com a hora embaixo de cada miniatura.
        espaco = (JANELA.width - 16) // len(self.clipes)
        pygame.draw.line(tela, cores["desativado"], (JANELA.left + 8, FAIXA_Y + MINIATURA[1] + 3), (JANELA.right - 8, FAIXA_Y + MINIATURA[1] + 3))
        for i, clipe in enumerate(self.clipes):
            x = JANELA.left + 8 + i * espaco + (espaco - MINIATURA[0]) // 2
            caixa = pygame.Rect(x, FAIXA_Y, *MINIATURA)
            pygame.draw.rect(tela, cor("neutros.noite"), caixa)
            pygame.draw.rect(tela, cor(CORES_DAS_MINIATURAS[i % len(CORES_DAS_MINIATURAS)]), caixa.inflate(-6, -10))
            pygame.draw.rect(tela, cor("vermelho.vermelho"), (caixa.left + 2, caixa.top + 2, 2, 2))
            borda = cores["selecionado"] if i == self.escolhido else cores["desativado"]
            pygame.draw.rect(tela, borda, caixa.inflate(2, 2), 1)
            fonte.desenhar(tela, caixa.centerx - fonte.largura(clipe["hora"]) // 2, caixa.bottom + 6, clipe["hora"], borda, cores["sombra"])

        # O vídeo escolhido, por extenso.
        clipe = self.clipes[self.escolhido]
        desenhar_caixa(tela, DETALHE, cores["claro_texto"], cores["claro_fundo"], 1)
        y = DETALHE.top + 3
        fonte.desenhar(tela, DETALHE.left + 5, y, f"{clipe['hora']} - {self._texto(clipe['camera'])}", cores["claro_texto"], cores["claro_sombra"])
        for linha in quebrar_em_linhas(fonte, self.texto_do_clipe(clipe), DETALHE.width - 10)[:2]:
            y += ALTURA_LINHA + 1
            fonte.desenhar(tela, DETALHE.left + 5, y, linha, cores["claro_texto"], cores["claro_sombra"])

        rodape = self.aviso or self._texto(self.dados["instrucao"])
        y = DETALHE.bottom + 6
        for linha in quebrar_em_linhas(fonte, rodape, JANELA.width - 16)[:2]:
            fonte.desenhar(tela, JANELA.left + 8, y, linha, cores["alerta"] if self.aviso else cores["texto"], cores["sombra"])
            y += ALTURA_LINHA + 1
