"""Menu de pausa (tecla C, D51): Itens, Evidências, Status, Configurações e a dica do Lume.

A troca do Modo História entra na FP6. Arquivo do Lume e Rádio ficam fora da
demo: no lugar do Rádio, o Lume dá a dica (data/dicas.json), como diz a adaptação da demo.
"""

import pygame

from config import ALTURA_TELA, LARGURA_TELA
from src.cenas.cena import Cena
from src.cenas.configuracoes import CenaConfiguracoes
from src.cenas.dialogo import CenaDialogo
from src.sistemas.entrada import acao_do_evento
from src.sistemas.recursos import ler_json
from src.sistemas.textos import resolver
from src.ui.caixa_texto import desenhar_caixa, quebrar_em_linhas
from src.ui.menu import ALTURA_OPCAO, ListaDeOpcoes

OPCOES = ("itens", "evidencias", "status", "configuracoes", "dica", "voltar")
X_MENU = 8
Y_MENU = 8
PAINEL = pygame.Rect(112, 8, LARGURA_TELA - 120, ALTURA_TELA - 16)
LINHAS_NA_LISTA = 7
FASE_PADRAO = "fase0"


def dica_atual(dicas, estado):
    """A primeira dica da fase cuja condição vale. Sem nenhuma, devolve None."""
    for dica in dicas.get(estado.flags.get("fase", FASE_PADRAO), []):
        if estado.condicao_ok(dica.get("condicao")):
            return dica
    return None


class CenaPausa(Cena):
    def __init__(self, jogo):
        super().__init__(jogo)
        self.textos = ler_json("data/interface.json")["pausa"]
        self.catalogo = ler_json("data/itens.json")
        self.regras = ler_json("data/batalha.json")["ada"]
        self.dicas = ler_json("data/dicas.json")
        self.lista = ListaDeOpcoes([resolver(self.textos[chave]) for chave in OPCOES])
        self.modo = "menu"
        self.item = 0
        self.topo = 0
        self.mensagem = None

    # ---------- Itens ----------
    def _itens(self):
        """Em Evidências, só as provas. Em Itens, primeiro os que se usam, depois os itens-chave."""
        if self.modo == "evidencias":
            return [i for i in self.jogo.estado.itens if self.catalogo.get(i, {}).get("evidencia")]
        comuns = [i for i in self.jogo.estado.itens if i in self.catalogo and not self.catalogo[i].get("chave")]
        chave = [i for i in self.jogo.estado.itens if i in self.catalogo and self.catalogo[i].get("chave") and not self.catalogo[i].get("evidencia")]
        return comuns + chave

    def _mover_item(self, passo):
        itens = self._itens()
        if not itens:
            return
        self.item = (self.item + passo) % len(itens)
        if self.item < self.topo:
            self.topo = self.item
        elif self.item >= self.topo + LINHAS_NA_LISTA:
            self.topo = self.item - LINHAS_NA_LISTA + 1
        self.mensagem = None

    def _usar_item(self):
        itens = self._itens()
        if not itens:
            return
        dados = self.catalogo[itens[self.item]]
        # Fora da batalha a vida e a energia estão sempre cheias, então os lanches ficam para a luta.
        if dados.get("evidencia"):
            self.mensagem = self.textos["evidencia_na_batalha"]
        else:
            self.mensagem = self.textos["item_chave" if dados.get("chave") else "so_na_batalha"]

    # ---------- Eventos ----------
    def _escolher(self, indice):
        chave = OPCOES[indice]
        if chave in ("itens", "evidencias", "status"):
            self.modo = chave
            self.item = 0
            self.topo = 0
            self.mensagem = None
        elif chave == "configuracoes":
            self.jogo.empilhar(CenaConfiguracoes(self.jogo))
        elif chave == "dica":
            dica = dica_atual(self.dicas, self.jogo.estado)
            fala = {"quem": dica["quem"], "texto": dica["texto"]} if dica else {"quem": "{LUME}", "texto": self.textos["sem_dica"]}
            self.jogo.empilhar(CenaDialogo(self.jogo, {"dica": [fala]}, "dica"))
        else:
            self.jogo.desempilhar()

    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        if acao is None:
            return
        if self.modo == "menu":
            if acao in ("cancelar", "menu"):
                self.jogo.desempilhar()
                return
            escolhida = self.lista.tratar_acao(acao)
            if escolhida is not None:
                self._escolher(escolhida)
            return
        if acao in ("cancelar", "menu"):
            self.modo = "menu"
        elif self.modo in ("itens", "evidencias"):
            if acao == "cima":
                self._mover_item(-1)
            elif acao == "baixo":
                self._mover_item(1)
            elif acao == "confirmar":
                self._usar_item()

    # ---------- Desenho ----------
    def desenhar(self, tela):
        fonte = self.jogo.fonte
        escuro = pygame.Surface(tela.get_size(), pygame.SRCALPHA)
        escuro.fill((0, 0, 0, 120))
        tela.blit(escuro, (0, 0))
        self.lista.desenhar(tela, fonte, X_MENU, Y_MENU)
        if self.modo in ("itens", "evidencias"):
            self._desenhar_itens(tela)
        elif self.modo == "status":
            self._desenhar_status(tela)

    def _painel(self, tela):
        fonte = self.jogo.fonte
        desenhar_caixa(tela, PAINEL, fonte.cores["borda_caixa"], fonte.cores["fundo_caixa"])

    def _desenhar_itens(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        self._painel(tela)
        itens = self._itens()
        if not itens:
            vazio = self.textos["sem_evidencias" if self.modo == "evidencias" else "mochila_vazia"]
            fonte.desenhar(tela, PAINEL.left + 8, PAINEL.top + 6, vazio)
            return
        for posicao, id_item in enumerate(itens[self.topo : self.topo + LINHAS_NA_LISTA]):
            indice = self.topo + posicao
            y = PAINEL.top + 5 + posicao * ALTURA_OPCAO
            dados = self.catalogo[id_item]
            escolhido = indice == self.item
            apagado = dados.get("chave") and not dados.get("evidencia")
            cor = cores["selecionado"] if escolhido else (cores["desativado"] if apagado else cores["texto"])
            if escolhido:
                fonte.desenhar(tela, PAINEL.left + 6, y, "▶", cor)
            fonte.desenhar(tela, PAINEL.left + 14, y, resolver(dados["nome"]), cor)
            quantidade = self.jogo.estado.itens[id_item]
            if not dados.get("chave"):
                texto = f"x{quantidade}"
                fonte.desenhar(tela, PAINEL.right - 8 - fonte.largura(texto), y, texto, cor)
        # Descrição do item escolhido, ou a resposta ao tentar usar.
        texto = self.mensagem or resolver(self.catalogo[itens[self.item]]["descricao"], self.jogo.estado.nome)
        linhas = quebrar_em_linhas(fonte, texto, PAINEL.width - 16)[:3]
        y_texto = PAINEL.bottom - 6 - len(linhas) * fonte.altura_linha
        pygame.draw.line(tela, cores["desativado"], (PAINEL.left + 6, y_texto - 3), (PAINEL.right - 7, y_texto - 3))
        for i, linha in enumerate(linhas):
            fonte.desenhar(tela, PAINEL.left + 8, y_texto + i * fonte.altura_linha, linha, cores["selecionado"] if self.mensagem else cores["texto"])

    def _desenhar_status(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        estado = self.jogo.estado
        self._painel(tela)
        x = PAINEL.left + 8
        y = PAINEL.top + 6
        fonte.desenhar(tela, x, y, estado.nome, cores["nomes"]["ADA"])
        y += 16
        vida, energia = self.regras["vida"], self.regras["energia"]
        fonte.desenhar(tela, x, y, f"{self.textos['vida']}: {vida}/{vida}")
        y += 12
        fonte.desenhar(tela, x, y, f"{self.textos['energia']}: {energia}/{energia}")
        y += 12
        modo = self.textos["historia" if estado.modo_historia else "normal"]
        fonte.desenhar(tela, x, y, f"{self.textos['modo']}: {modo}")
        y += 18
        fonte.desenhar(tela, x, y, self.textos["itens_chave"], cores["destaque"])
        y += 13
        chaves = [resolver(self.catalogo[i]["nome"]) for i in estado.itens
                  if self.catalogo.get(i, {}).get("chave") and not self.catalogo[i].get("evidencia")]
        for nome in chaves or [self.textos["nenhum"]]:
            if y > PAINEL.bottom - 14:
                break
            fonte.desenhar(tela, x + 4, y, nome, cores["texto"] if chaves else cores["desativado"])
            y += 12
