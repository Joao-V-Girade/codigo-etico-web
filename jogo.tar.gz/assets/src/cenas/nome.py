"""Novo Jogo (cena 0.1): o jogador digita o nome e escolhe como prefere jogar.

Três formas de escrever funcionam juntas (D32):
- Digitando no teclado do computador, com os acentos do jeito normal (no ABNT2, ´ + a = á).
- Com as setas no teclado da tela: Espaço escreve a letra. Segurar Espaço abre um balão com os acentos.
- Com o mouse no teclado da tela: clicar escreve. Segurar o clique abre o balão.
"""

import pygame

from config import LARGURA_TELA
from src.cenas.cena import Cena
from src.sistemas.entrada import acao_do_evento
from src.sistemas.nome_jogador import acrescentar, letras_permitidas, validar_nome
from src.sistemas.recursos import ler_json
from src.ui.caixa_texto import desenhar_caixa
from src.ui.menu import ListaDeOpcoes

TEMPO_PARA_SEGURAR = 0.5  # Segurar a letra por este tempo abre o balão de acentos.
LARGURA_TECLA = 16
ALTURA_TECLA = 14
LARGURA_VARIACAO = 14
Y_PERGUNTA = 10
CAMPO = pygame.Rect(110, 26, 100, 16)
Y_TECLADO = 64
Y_BOTOES = 100
LARGURA_BOTAO = 62
INTERVALO_BOTOES = 8
Y_MENSAGEM = 124
BOTOES = ("maiusculas", "apagar", "pronto")
# Neste teclado, W, A, S, D, X e C viram letras: só as setas andam e só o Espaço aperta a tecla.
SETAS = {pygame.K_UP: "cima", pygame.K_DOWN: "baixo", pygame.K_LEFT: "esquerda", pygame.K_RIGHT: "direita"}


class CenaNome(Cena):
    def __init__(self, jogo):
        super().__init__(jogo)
        self.textos = ler_json("data/interface.json")["nome"]
        self.teclas = self.textos["teclas"]
        self.acentos = self.textos["acentos"]
        self.permitidas = letras_permitidas(self.teclas, self.acentos)
        self.maximo = self.textos["maximo_letras"]
        self.nome = ""
        self.maiusculas = True
        self.linha = 0
        self.coluna = 0
        self.erro = None
        self.tempo = 0.0
        # Quem está segurando uma letra: "espaco" ou "mouse", e há quanto tempo.
        self.segurando = None
        self.tempo_segurando = 0.0
        # O balão de acentos aberto: a lista de variações e qual está escolhida.
        self.balao = None
        self.balao_indice = 0
        pygame.key.start_text_input()
        pygame.key.set_repeat(0)  # Senão segurar Espaço repetiria a letra (D32).

    # ---------- Teclado da tela ----------
    @property
    def nos_botoes(self):
        return self.linha == len(self.teclas)

    def _x_teclado(self, linha):
        return (LARGURA_TELA - len(self.teclas[linha]) * LARGURA_TECLA) // 2

    def _retangulo_tecla(self, linha, coluna):
        return pygame.Rect(self._x_teclado(linha) + coluna * LARGURA_TECLA, Y_TECLADO + linha * ALTURA_TECLA, LARGURA_TECLA, ALTURA_TECLA)

    def _retangulo_botao(self, indice):
        largura_total = len(BOTOES) * LARGURA_BOTAO + (len(BOTOES) - 1) * INTERVALO_BOTOES
        x = (LARGURA_TELA - largura_total) // 2 + indice * (LARGURA_BOTAO + INTERVALO_BOTOES)
        return pygame.Rect(x, Y_BOTOES, LARGURA_BOTAO, ALTURA_TECLA + 2)

    def _caixa(self, letra):
        return letra if self.maiusculas else letra.lower()

    def _letra(self, linha, coluna):
        return self._caixa(self.teclas[linha][coluna])

    def _mover(self, direcao):
        if self.balao:
            if direcao in ("esquerda", "direita"):
                self.balao_indice = (self.balao_indice + (1 if direcao == "direita" else -1)) % len(self.balao)
            return
        total_linhas = len(self.teclas) + 1
        if direcao in ("cima", "baixo"):
            antes = self.linha
            self.linha = (self.linha + (1 if direcao == "baixo" else -1)) % total_linhas
            # Ao passar das letras para os botões (ou o contrário), a coluna acompanha a posição na tela.
            if self.nos_botoes:
                self.coluna = min(len(BOTOES) - 1, self.coluna * len(BOTOES) // len(self.teclas[antes]))
            elif antes == len(self.teclas):
                self.coluna = min(len(self.teclas[self.linha]) - 1, self.coluna * len(self.teclas[self.linha]) // len(BOTOES) + 2)
            else:
                self.coluna = min(self.coluna, len(self.teclas[self.linha]) - 1)
        else:
            tamanho = len(BOTOES) if self.nos_botoes else len(self.teclas[self.linha])
            self.coluna = (self.coluna + (1 if direcao == "direita" else -1)) % tamanho

    def _escrever(self, letra):
        antes = self.nome
        self.nome = acrescentar(self.nome, letra, self.permitidas, self.maximo)
        if self.nome != antes:
            self.erro = None

    def _apertar_botao(self):
        botao = BOTOES[self.coluna]
        if botao == "maiusculas":
            self.maiusculas = not self.maiusculas
        elif botao == "apagar":
            self.nome = self.nome[:-1]
        else:
            self._pronto()

    def _abrir_balao(self):
        """Abre as variações da letra escolhida. Letras sem acento não têm balão."""
        variacoes = self.acentos.get(self.teclas[self.linha][self.coluna])
        if variacoes:
            self.balao = [self._caixa(letra) for letra in variacoes]
            self.balao_indice = 0

    def _soltar(self):
        """Soltou o Espaço ou o clique antes de abrir o balão: escreve a letra simples."""
        if self.segurando and not self.balao:
            self._escrever(self._letra(self.linha, self.coluna))
        self.segurando = None

    def _pronto(self):
        nome, erro = validar_nome(self.nome, self.textos["padrao"])
        if erro:
            self.erro = erro
            self.nome = ""
            return
        self._sair()
        self.jogo.empilhar(CenaDificuldade(self.jogo, nome))

    def _sair(self):
        pygame.key.stop_text_input()
        self.jogo.desempilhar()

    # ---------- Balão ----------
    def _retangulo_balao(self):
        tecla = self._retangulo_tecla(self.linha, self.coluna)
        largura = len(self.balao) * LARGURA_VARIACAO + 4
        caixa = pygame.Rect(0, 0, largura, ALTURA_TECLA + 4)
        caixa.midbottom = (tecla.centerx, tecla.top - 1)
        caixa.left = max(2, min(caixa.left, LARGURA_TELA - 2 - largura))
        return caixa

    def _variacao_no_ponto(self, ponto):
        caixa = self._retangulo_balao()
        for indice in range(len(self.balao)):
            if pygame.Rect(caixa.left + 2 + indice * LARGURA_VARIACAO, caixa.top, LARGURA_VARIACAO, caixa.height).collidepoint(ponto):
                return indice
        return None

    def _escolher_no_balao(self, indice):
        self._escrever(self.balao[indice])
        self.balao = None
        self.segurando = None

    # ---------- Eventos ----------
    def _tecla_no_ponto(self, ponto):
        for linha in range(len(self.teclas)):
            for coluna in range(len(self.teclas[linha])):
                if self._retangulo_tecla(linha, coluna).collidepoint(ponto):
                    return linha, coluna
        return None

    def _clique(self, ponto):
        if self.balao:
            indice = self._variacao_no_ponto(ponto)
            if indice is None:
                self.balao = None  # Clicar fora cancela.
            else:
                self._escolher_no_balao(indice)
            return
        tecla = self._tecla_no_ponto(ponto)
        if tecla:
            self.linha, self.coluna = tecla
            self.segurando = "mouse"
            self.tempo_segurando = 0.0
            return
        for indice in range(len(BOTOES)):
            if self._retangulo_botao(indice).collidepoint(ponto):
                self.linha, self.coluna = len(self.teclas), indice
                self._apertar_botao()
                return

    def tratar_evento(self, evento):
        if evento.type == pygame.TEXTINPUT:
            if not self.balao:
                self._escrever(evento.text)
        elif evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
            self._clique(evento.pos)
        elif evento.type == pygame.MOUSEBUTTONUP and evento.button == 1 and self.segurando == "mouse":
            self._soltar()
        elif evento.type == pygame.KEYUP and evento.key == pygame.K_SPACE and self.segurando == "espaco":
            self._soltar()
        elif evento.type == pygame.KEYDOWN:
            self._tecla(evento.key)

    def _tecla(self, tecla):
        if tecla in SETAS:
            self._mover(SETAS[tecla])
        elif tecla == pygame.K_SPACE:
            if self.balao:
                self._escolher_no_balao(self.balao_indice)
            elif self.nos_botoes:
                self._apertar_botao()
            else:
                self.segurando = "espaco"
                self.tempo_segurando = 0.0
        elif tecla in (pygame.K_RETURN, pygame.K_KP_ENTER):
            if self.balao:
                self._escolher_no_balao(self.balao_indice)
            else:
                self._pronto()
        elif tecla == pygame.K_BACKSPACE:
            self.nome = self.nome[:-1]
        elif tecla == pygame.K_ESCAPE:
            if self.balao:
                self.balao = None
            else:
                self._sair()

    def atualizar(self, dt):
        self.tempo += dt
        if self.segurando and not self.balao:
            self.tempo_segurando += dt
            if self.tempo_segurando >= TEMPO_PARA_SEGURAR:
                self._abrir_balao()

    # ---------- Desenho ----------
    def desenhar(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        tela.fill(cores["fundo_caixa"])
        fonte.desenhar_centralizado(tela, Y_PERGUNTA, self.textos["pergunta"], cores["destaque"])

        desenhar_caixa(tela, CAMPO, cores["borda_caixa"], cores["fundo_caixa"], 1)
        if self.nome:
            cursor = "_" if int(self.tempo * 2) % 2 == 0 and len(self.nome) < self.maximo else ""
            fonte.desenhar(tela, CAMPO.left + 6, CAMPO.top + 2, self.nome + cursor, cores["texto"])
        else:
            fonte.desenhar(tela, CAMPO.left + 6, CAMPO.top + 2, self.textos["padrao"], cores["desativado"], cores["sombra_desativado"])

        for linha in range(len(self.teclas)):
            for coluna in range(len(self.teclas[linha])):
                retangulo = self._retangulo_tecla(linha, coluna)
                escolhida = not self.nos_botoes and (linha, coluna) == (self.linha, self.coluna)
                if escolhida:
                    desenhar_caixa(tela, retangulo, cores["selecionado"], cores["fundo_caixa"], 1)
                letra = self._letra(linha, coluna)
                # Um pontinho no canto avisa quais letras têm acento.
                if self.teclas[linha][coluna] in self.acentos:
                    tela.set_at((retangulo.right - 2, retangulo.top + 1), pygame.Color(cores["desativado"]))
                cor = cores["selecionado"] if escolhida else cores["texto"]
                fonte.desenhar(tela, retangulo.centerx - fonte.largura(letra) // 2, retangulo.top + 1, letra, cor)

        for indice, botao in enumerate(BOTOES):
            retangulo = self._retangulo_botao(indice)
            escolhido = self.nos_botoes and indice == self.coluna
            borda = cores["selecionado"] if escolhido else cores["desativado"]
            desenhar_caixa(tela, retangulo, borda, cores["fundo_caixa"], 1)
            texto = self.textos[botao]
            ativo = botao != "maiusculas" or self.maiusculas
            cor = cores["selecionado"] if escolhido else (cores["texto"] if ativo else cores["desativado"])
            fonte.desenhar(tela, retangulo.centerx - fonte.largura(texto) // 2, retangulo.top + 3, texto, cor)

        if self.erro:
            fonte.desenhar_centralizado(tela, Y_MENSAGEM, self.textos[self.erro], cores["alerta"])
        else:
            fonte.desenhar_centralizado(tela, Y_MENSAGEM, self.textos["dica"], cores["desativado"], cores["sombra_desativado"])

        if self.balao:
            self._desenhar_balao(tela)

    def _desenhar_balao(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        caixa = self._retangulo_balao()
        desenhar_caixa(tela, caixa, cores["selecionado"], cores["fundo_caixa"], 1)
        for indice, letra in enumerate(self.balao):
            x = caixa.left + 2 + indice * LARGURA_VARIACAO + (LARGURA_VARIACAO - fonte.largura(letra)) // 2
            cor = cores["selecionado"] if indice == self.balao_indice else cores["texto"]
            if indice == self.balao_indice:
                pygame.draw.line(tela, cor, (x - 1, caixa.bottom - 3), (x + fonte.largura(letra), caixa.bottom - 3))
            fonte.desenhar(tela, x, caixa.top + 2, letra, cor)


class CenaDificuldade(Cena):
    """"Como você prefere jogar?" O Modo História guarda a escolha. O efeito no dano entra na FP6."""

    def __init__(self, jogo, nome):
        super().__init__(jogo)
        self.textos = ler_json("data/interface.json")["dificuldade"]
        self.nome = nome
        self.lista = ListaDeOpcoes([self.textos["normal"], self.textos["historia"]])

    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        if acao == "cancelar":
            self.jogo.desempilhar()
            self.jogo.empilhar(CenaNome(self.jogo))
            return
        escolhida = self.lista.tratar_acao(acao)
        if escolhida is not None:
            self.jogo.novo_jogo(self.nome, modo_historia=escolhida == 1)

    def desenhar(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        tela.fill(cores["fundo_caixa"])
        fonte.desenhar_centralizado(tela, 30, self.textos["pergunta"], cores["destaque"])
        x = (LARGURA_TELA - self.lista.largura(fonte)) // 2
        self.lista.desenhar(tela, fonte, x, 56)
        dica = self.textos["historia_dica" if self.lista.indice == 1 else "normal_dica"]
        fonte.desenhar_centralizado(tela, 104, dica, cores["desativado"], cores["sombra_desativado"])
