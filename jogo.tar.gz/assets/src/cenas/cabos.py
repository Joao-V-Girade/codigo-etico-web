"""Puzzle dos cabos (Fase 3, Sala de Servidores): religar três cabos para acordar o terminal do registro.

À esquerda ficam os cabos soltos; à direita, as portas, cada uma com a etiqueta de uma cor, em outra
ordem. O jogador pega um cabo e escolhe a porta. Na porta da mesma cor, o cabo fica ligado; em outra,
sai uma faísca e o cabo volta para a mão. Com os três ligados, a tela fecha e o terminal acorda.
Os textos e as cores ficam em data/cabos.json.
"""

import pygame

from src.cenas.cena import Cena
from src.sistemas.cores import cor
from src.sistemas.entrada import acao_do_evento
from src.sistemas.recursos import ler_json
from src.sistemas.textos import resolver
from src.ui.caixa_texto import desenhar_caixa, quebrar_em_linhas

JANELA = pygame.Rect(40, 16, 240, 148)
X_CABOS, X_PORTAS = JANELA.left + 30, JANELA.right - 60
Y_PRIMEIRO, ESPACO = JANELA.top + 30, 28
TEMPO_ATE_FECHAR = 0.8
ALTURA_LINHA = 11


class CenaCabos(Cena):
    def __init__(self, jogo, _nome, ao_terminar):
        super().__init__(jogo)
        self.dados = ler_json("data/cabos.json")
        self.ao_terminar = ao_terminar
        self.modo = "cabo"
        self.cabo = 0
        self.porta = 0
        self.ligados = {}  # cabo -> porta
        self.aviso = ""
        self.espera = None
        self.fechou = False

    @property
    def cabos(self):
        return self.dados["cabos"]

    @property
    def portas(self):
        return self.dados["portas"]

    def _texto(self, texto):
        return resolver(texto, self.jogo.estado.nome)

    def pegar(self, cabo):
        """Pega um cabo que ainda está solto."""
        if cabo in self.ligados:
            return False
        self.cabo = cabo
        self.modo = "porta"
        self.aviso = ""
        return True

    def ligar(self, porta):
        """Liga o cabo na mão na porta. Só a porta da mesma cor aceita."""
        if self.cabos[self.cabo]["nome"] != self.portas[porta] or porta in self.ligados.values():
            self.aviso = self._texto(self.dados["faisca"])
            self.modo = "cabo"
            return False
        self.ligados[self.cabo] = porta
        self.aviso = self._texto(self.dados["ligado"])
        self.modo = "cabo"
        soltos = [i for i in range(len(self.cabos)) if i not in self.ligados]
        if soltos:
            self.cabo = soltos[0]
        else:
            self.espera = TEMPO_ATE_FECHAR
            self.modo = "pronto"
        return True

    def _fechar(self, resultado):
        if self.fechou:
            return
        self.fechou = True
        self.jogo.desempilhar()
        self.ao_terminar(self.dados["depois"].get(resultado))

    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        if self.modo == "pronto" or not acao:
            return
        lista = len(self.cabos)
        if acao in ("cima", "baixo"):
            passo = 1 if acao == "baixo" else -1
            if self.modo == "cabo":
                self.cabo = (self.cabo + passo) % lista
            else:
                self.porta = (self.porta + passo) % lista
        elif acao == "confirmar":
            if self.modo == "cabo":
                self.pegar(self.cabo)
            else:
                self.ligar(self.porta)
        elif acao == "cancelar":
            if self.modo == "porta":
                self.modo = "cabo"
            else:
                self._fechar("saiu")

    def atualizar(self, dt):
        if self.espera is not None:
            self.espera -= dt
            if self.espera <= 0:
                self._fechar("achou")

    def desenhar(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        sombra = pygame.Surface(tela.get_size(), pygame.SRCALPHA)
        sombra.fill((0, 0, 0, 160))
        tela.blit(sombra, (0, 0))
        desenhar_caixa(tela, JANELA, cores["borda_caixa"], cor("neutros.grafite"))
        fonte.desenhar(tela, JANELA.left + 8, JANELA.top + 5, self._texto(self.dados["titulo"]), cores["destaque"], cores["sombra"])
        cor_das_portas = {cabo["nome"]: cabo["cor"] for cabo in self.cabos}
        for i, cabo in enumerate(self.cabos):
            y = Y_PRIMEIRO + i * ESPACO
            # O cabo: uma ponta colorida à esquerda.
            escolhido = self.modo in ("cabo", "porta") and i == self.cabo
            pygame.draw.rect(tela, cor(cabo["cor"]), (X_CABOS - 12, y + 2, 12, 5))
            if escolhido:
                pygame.draw.rect(tela, cores["selecionado"], (X_CABOS - 15, y - 1, 18, 11), 1)
            # A porta: um buraco com a etiqueta da cor.
            nome = self.portas[i]
            pygame.draw.rect(tela, cor("neutros.noite"), (X_PORTAS, y, 10, 9))
            pygame.draw.rect(tela, cor(cor_das_portas[nome]), (X_PORTAS + 14, y + 1, 6, 7))
            fonte.desenhar(tela, X_PORTAS + 24, y - 1, nome, cores["texto"], cores["sombra"])
            if self.modo == "porta" and i == self.porta:
                pygame.draw.rect(tela, cores["selecionado"], (X_PORTAS - 3, y - 3, 13, 15), 1)
        # Os cabos ligados atravessam o painel; o que está na mão segue até a porta escolhida.
        for cabo, porta in self.ligados.items():
            self._linha(tela, cabo, porta, cor(self.cabos[cabo]["cor"]))
        if self.modo == "porta":
            self._linha(tela, self.cabo, self.porta, cor(self.cabos[self.cabo]["cor"]), 1)

        texto = self.aviso + " " if self.aviso else ""
        texto += self._texto(self.dados["instrucao_porta" if self.modo == "porta" else "instrucao_cabo"])
        y = Y_PRIMEIRO + len(self.cabos) * ESPACO + 2
        for linha in quebrar_em_linhas(fonte, texto, JANELA.width - 16)[:3]:
            fonte.desenhar(tela, JANELA.left + 8, y, linha, cores["texto"], cores["sombra"])
            y += ALTURA_LINHA + 1

    def _linha(self, tela, cabo, porta, cor_da_linha, espessura=3):
        inicio = (X_CABOS, Y_PRIMEIRO + cabo * ESPACO + 4)
        fim = (X_PORTAS, Y_PRIMEIRO + porta * ESPACO + 4)
        pygame.draw.line(tela, cor_da_linha, inicio, fim, espessura)
