"""Cenas com roteiro (cutscenes): a Ada e os NPCs andam sozinhos, o mapa troca e as falas aparecem.

Os roteiros ficam em data/cenas.json, como uma lista de passos. Cada passo faz uma coisa:

- {"andar": [x, y]}           anda até o tile, achando o caminho sozinho (sistemas/caminho.py).
- {"andar_ate": "zim"}        anda até ficar ao lado de alguém e vira para ele.
  Os dois aceitam "quem" (o id de um NPC, ou "ada", que é o padrão), "velocidade" (2 = correndo)
  e "junto": true, que deixa o próximo passo começar sem esperar a chegada.
- {"aguardar": true}          espera todo mundo que está andando chegar.
- {"colocar": [x, y], "quem"} põe alguém num tile na hora, como um NPC entrando pela borda do mapa.
- {"olhar": "cima"}           vira a Ada (ou "quem") para um lado.
- {"falar": "id"}             abre uma fala e espera ela fechar. Aceita "arquivo" (outro arquivo de
                              falas) e também uma lista de opções com condição, como nos mapas.
- {"mapa": "rua_principal", "x", "y", "direcao"}  escurece, troca o mapa e clareia.
- {"definir": {...}}          muda flags, como em "efeitos". Serve para NPCs aparecerem ou sumirem.
- {"esperar": 0.5}            espera alguns segundos.
- {"efeito": "glitch"}        efeito de tela.
- {"cartaz": ["Mais tarde..."]}  tela preta com texto, que fecha sozinha.
- {"fase": "fase1"}           começa outra fase.
"""

import pygame

from src.cenas.cartaz import CenaCartaz
from src.cenas.cena import Cena
from src.cenas.dialogo import CenaDialogo
from src.sistemas.caminho import achar_caminho, direcao_entre
from src.sistemas.cores import cor
from src.sistemas.recursos import ler_json

TEMPO_DE_ESCURECER = 0.35
VIZINHOS = ((0, 1), (-1, 0), (1, 0), (0, -1))


class Caminhada:
    """Alguém seguindo uma lista de tiles, um de cada vez."""

    def __init__(self, quem, tiles, tamanho, velocidade, bloqueia, olhar_para=None):
        self.quem = quem
        self.tiles = list(tiles)
        self.tamanho = tamanho
        self.velocidade = velocidade
        self.bloqueia = bloqueia
        self.olhar_para = olhar_para

    @property
    def terminou(self):
        return not self.tiles

    def atualizar(self, dt):
        if not self.tiles:
            return
        alvo = self.quem.alvo_do_tile(*self.tiles[0], self.tamanho)
        if self.quem.andar_para(alvo, dt, self.velocidade):
            self.tiles.pop(0)
            if not self.tiles:
                self.quem.parar()
                if self.olhar_para and hasattr(self.quem, "direcao"):
                    self.quem.direcao = self.olhar_para


class CenaRoteiro(Cena):
    def __init__(self, jogo, passos):
        """passos pode ser o nome de um roteiro de data/cenas.json ou a própria lista de passos."""
        super().__init__(jogo)
        self.passos = ler_json("data/cenas.json")[passos] if isinstance(passos, str) else list(passos)
        self.indice = 0
        self.caminhadas = []
        self.espera = 0.0
        self.escuro = 0.0  # 0 = tela normal, 1 = preta.
        self.troca_de_mapa = None
        self.fase_da_troca = None
        self.terminou = False

    @property
    def mundo(self):
        return self.jogo.mundo

    # ---------- Quem anda ----------
    def _personagem(self, nome):
        if nome in (None, "ada"):
            return self.mundo.jogador
        for npc in self.mundo.npcs:
            if npc.id == nome:
                return npc
        return None

    def _livre(self, quem):
        """Um tile é livre se não for parede e não tiver outra pessoa em cima."""
        mapa = self.mundo.mapa
        t = mapa.tamanho
        ocupados = {npc.tile(t) for npc in self.mundo.npcs if npc is not quem}
        if quem is not self.mundo.jogador:
            ocupados.add(self.mundo.jogador.tile(t))
        return lambda coluna, linha: not mapa.tile_solido(coluna, linha) and (coluna, linha) not in ocupados

    def _andar(self, passo):
        quem = self._personagem(passo.get("quem"))
        if quem is None:
            return
        t = self.mundo.mapa.tamanho
        inicio = quem.tile(t)
        livre = self._livre(quem)
        olhar = passo.get("olhar")
        if "andar_ate" in passo:
            alvo = self._personagem(passo["andar_ate"])
            if alvo is None:
                return
            tile_alvo = alvo.tile(t)
            destinos = [(tile_alvo[0] + dx, tile_alvo[1] + dy) for dx, dy in VIZINHOS]
            destinos = [d for d in destinos if livre(*d) or d == inicio]
            caminho = achar_caminho(livre, inicio, destinos) if destinos else None
            fim = caminho[-1] if caminho else inicio
            olhar = olhar or direcao_entre(fim, tile_alvo)
        else:
            destino = tuple(passo["andar"])
            caminho = achar_caminho(livre, inicio, destino)
            if caminho is None:
                caminho = [destino]  # Sem caminho livre, vai direto, para a cena nunca travar.
        self.caminhadas.append(Caminhada(quem, caminho or [], t, passo.get("velocidade", 1.0), not passo.get("junto"), olhar))

    # ---------- Passos ----------
    def _executar(self, passo):
        """Faz um passo. Devolve True se for preciso esperar antes do próximo."""
        estado = self.jogo.estado
        if "andar" in passo or "andar_ate" in passo:
            self._andar(passo)
            return not passo.get("junto")
        if "aguardar" in passo:
            return any(not c.terminou for c in self.caminhadas)
        if "colocar" in passo:
            quem = self._personagem(passo.get("quem"))
            if quem is self.mundo.jogador:
                quem.colocar_em(*passo["colocar"], self.mundo.mapa.tamanho, passo.get("direcao"))
            elif quem:
                quem.colocar_em(*passo["colocar"])
            return False
        if "olhar" in passo:
            quem = self._personagem(passo.get("quem"))
            if quem is not None and hasattr(quem, "direcao"):
                quem.direcao = passo["olhar"]
            return False
        if "definir" in passo:
            estado.aplicar_efeitos({"definir": passo["definir"]})
            return False
        if "esperar" in passo:
            self.espera = passo["esperar"]
            return True
        if "efeito" in passo:
            self.jogo.efeitos.iniciar(passo["efeito"])
            return False
        if "falar" in passo:
            return self._falar(passo)
        if "mapa" in passo:
            self.troca_de_mapa = passo
            self.fase_da_troca = "escurecendo"
            return True
        if "cartaz" in passo:
            self.jogo.empilhar(CenaCartaz(self.jogo, passo["cartaz"], lambda: None, tempo_sozinho=passo.get("tempo", 2.2)))
            return True
        if "fase" in passo:
            self.indice = len(self.passos)
            self._terminar()
            self.jogo.ir_para_fase(passo["fase"])
            return True
        return False

    def _falar(self, passo):
        dialogos = ler_json(f"data/dialogos/{passo['arquivo']}.json") if "arquivo" in passo else self.mundo.dialogos
        alvo = passo["falar"]
        if isinstance(alvo, list):
            opcao = self.jogo.estado.primeira_opcao(alvo)
            if not opcao:
                return False
            alvo = opcao["id"]
        self.jogo.empilhar(CenaDialogo(self.jogo, dialogos, alvo))
        return True

    def _terminar(self):
        if self.terminou:
            return
        self.terminou = True
        for caminhada in self.caminhadas:
            caminhada.quem.parar()
        mundo = self.mundo
        # Quem termina a cena em cima de uma porta ou área não deve disparar ela sem querer.
        mundo.portal_ativo = mundo._portal_nos_pes()
        mundo.gatilho_ativo = mundo._gatilho_nos_pes()
        if self.jogo.cenas and self.jogo.cenas[-1] is self:
            self.jogo.desempilhar()

    # ---------- Atualização ----------
    def _atualizar_troca(self, dt):
        if self.fase_da_troca == "escurecendo":
            self.escuro = min(1.0, self.escuro + dt / TEMPO_DE_ESCURECER)
            if self.escuro >= 1.0:
                passo = self.troca_de_mapa
                self.caminhadas = []
                self.mundo.carregar_mapa(passo["mapa"], passo["x"], passo["y"], passo.get("direcao", "baixo"))
                self.fase_da_troca = "clareando"
        elif self.fase_da_troca == "clareando":
            self.escuro = max(0.0, self.escuro - dt / TEMPO_DE_ESCURECER)
            if self.escuro <= 0.0:
                self.fase_da_troca = None
                self.troca_de_mapa = None

    def atualizar(self, dt):
        if self.terminou:
            return
        for caminhada in self.caminhadas:
            caminhada.atualizar(dt)
        self.caminhadas = [c for c in self.caminhadas if not c.terminou]
        if self.mundo.lume:
            self.mundo.lume.seguir(dt, self.mundo.jogador)
        if self.fase_da_troca:
            self._atualizar_troca(dt)
            return
        if self.espera > 0:
            self.espera = max(0.0, self.espera - dt)
            return
        if any(c.bloqueia for c in self.caminhadas):
            return
        if self.indice > 0 and "aguardar" in self.passos[self.indice - 1] and self.caminhadas:
            return
        while self.indice < len(self.passos):
            passo = self.passos[self.indice]
            self.indice += 1
            if self._executar(passo):
                return
        self._terminar()

    def desenhar(self, tela):
        if self.escuro > 0:
            escuro = pygame.Surface(tela.get_size(), pygame.SRCALPHA)
            tinta = pygame.Color(cor("neutros.tinta"))
            escuro.fill((tinta.r, tinta.g, tinta.b, int(255 * self.escuro)))
            tela.blit(escuro, (0, 0))
