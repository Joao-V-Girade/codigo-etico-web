"""A exploração: mapa, câmera, Ada, NPCs, portas e interação com a tecla de confirmar.

Além de NPCs, objetos e portas, cada mapa pode ter, em data/mapas/:
- "automaticos": falas que começam sozinhas quando a condição vale, como a CASA acordando a Ada.
  A própria fala precisa mudar uma flag, senão ela repetiria para sempre.
- "gatilhos": áreas que começam uma fala quando a Ada entra nelas, como a cena do ZIM na praça.
  Com "voltar", a Ada é devolvida para fora da área, como nas portas com barreira.
- "variantes": tiles que mudam conforme a história (ver sistemas/mapa.py).

Em qualquer lista de "dialogos", uma opção pode ter "cena" no lugar de "id": aí começa uma cena com
roteiro de data/cenas.json (ver cenas/roteiro.py), em que os personagens andam sozinhos.
"""

import pygame

from config import ALTURA_TELA, LARGURA_TELA
from src.cenas.batalha import CenaBatalha
from src.cenas.cena import Cena
from src.cenas.dialogo import CenaDialogo
from src.cenas.pausa import CenaPausa
from src.cenas.roteiro import CenaRoteiro
from src.entidades.jogador import Jogador
from src.entidades.lume import Lume
from src.entidades.npc import Npc
from src.sistemas.entrada import acao_do_evento
from src.sistemas.mapa import Mapa
from src.sistemas.recursos import ler_json


class CenaMundo(Cena):
    def __init__(self, jogo, nome_mapa="oficina", coluna=6, linha=6):
        super().__init__(jogo)
        self.lume = None
        self.jogador = None
        self.carregar_mapa(nome_mapa, coluna, linha, "baixo")

    def carregar_mapa(self, nome, coluna, linha, direcao):
        self.mapa = Mapa(nome)
        self._atualizar_variantes()
        self.todos_os_npcs = [Npc(dados, self.mapa.tamanho) for dados in self.mapa.dados.get("npcs", [])]
        self.interacoes = self.mapa.dados.get("interacoes", [])
        self.portais = self.mapa.dados.get("portais", [])
        self.gatilhos = self.mapa.dados.get("gatilhos", [])
        self.automaticos = self.mapa.dados.get("automaticos", [])
        self.dialogos = ler_json(f"data/dialogos/{self.mapa.dados['dialogos']}.json")
        if self.jogador is None:
            self.jogador = Jogador(coluna, linha, self.mapa.tamanho)
        else:
            self.jogador.colocar_em(coluna, linha, self.mapa.tamanho, direcao)
        if self.lume:
            self.lume.x, self.lume.y = self.jogador.x - 18, self.jogador.y - 30
        self.portal_ativo = self._portal_nos_pes()
        self.gatilho_ativo = self._gatilho_nos_pes()

    @property
    def npcs(self):
        """Só quem está no mapa agora: o ZIM, por exemplo, some depois da batalha."""
        return [npc for npc in self.todos_os_npcs if self.jogo.estado.condicao_ok(npc.condicao)]

    def _atualizar_variantes(self):
        """Redesenha o mapa quando a história liga ou desliga alguma variante."""
        ativas = tuple(self.jogo.estado.condicao_ok(v.get("condicao")) for v in self.mapa.variantes)
        if ativas != self.mapa.ativas:
            self.mapa.montar(ativas)

    # ---------- Interação ----------
    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        if acao == "confirmar":
            self.interagir()
        elif acao == "menu":
            self.jogo.empilhar(CenaPausa(self.jogo))

    def _falar(self, opcoes):
        """Abre a primeira opção que vale: uma fala ("id") ou uma cena com roteiro ("cena")."""
        opcao = self.jogo.estado.primeira_opcao(opcoes)
        if not opcao:
            return False
        if "cena" in opcao:
            self.jogo.empilhar(CenaRoteiro(self.jogo, opcao["cena"]))
        else:
            self.jogo.empilhar(CenaDialogo(self.jogo, self.dialogos, opcao["id"]))
        return True

    def interagir(self):
        ponto = self.jogador.ponto_a_frente()
        for npc in self.npcs:
            if npc.corpo.inflate(4, 4).collidepoint(ponto):
                self._falar(npc.dialogos)
                return
        t = self.mapa.tamanho
        coluna, linha = int(ponto[0] // t), int(ponto[1] // t)
        for item in self.interacoes:
            if item["x"] == coluna and item["y"] == linha and self.jogo.estado.condicao_ok(item.get("condicao")):
                self._falar(item["dialogos"])
                return

    # ---------- Movimento ----------
    def bloqueado(self, retangulo):
        if self.mapa.bate_em_parede(retangulo):
            return True
        return any(retangulo.colliderect(npc.corpo) for npc in self.npcs)

    def _tile_dos_pes(self):
        t = self.mapa.tamanho
        centro = self.jogador.pes.center
        return centro[0] // t, centro[1] // t

    def _portal_nos_pes(self):
        coluna, linha = self._tile_dos_pes()
        for portal in self.portais:
            if portal["x"] == coluna and portal["y"] == linha:
                return portal
        return None

    def _gatilho_nos_pes(self):
        coluna, linha = self._tile_dos_pes()
        for gatilho in self.gatilhos:
            if (gatilho["x"] <= coluna < gatilho["x"] + gatilho.get("largura", 1)
                    and gatilho["y"] <= linha < gatilho["y"] + gatilho.get("altura", 1)
                    and self.jogo.estado.condicao_ok(gatilho.get("condicao"))):
                return gatilho
        return None

    def _barrar(self, barreira):
        """A Ada volta andando para antes da porta (ou da área), e a fala explica o que falta fazer."""
        self.jogador.parar()
        self.portal_ativo = None
        self.gatilho_ativo = None
        self.jogo.empilhar(CenaRoteiro(self.jogo, [
            {"andar": [barreira["x"], barreira["y"]]},
            {"olhar": barreira["direcao"]},
            {"falar": barreira["dialogos"]},
        ]))

    def _atender_pedidos(self):
        """Falas podem pedir batalha, cena ou outra fase. Isso começa aqui, depois que a caixa de diálogo fecha."""
        estado = self.jogo.estado
        if estado.pedido_de_batalha:
            pedido, estado.pedido_de_batalha = estado.pedido_de_batalha, None
            self.jogo.empilhar(CenaBatalha(self.jogo, pedido, self.dialogos))
            return True
        if estado.pedido_de_cena:
            cena, estado.pedido_de_cena = estado.pedido_de_cena, None
            self.jogo.empilhar(CenaRoteiro(self.jogo, cena))
            return True
        if estado.pedido_de_tela:
            tela, estado.pedido_de_tela = estado.pedido_de_tela, None
            self.jogo.mostrar_tela(tela)
            return True
        if estado.pedido_de_fase:
            fase, estado.pedido_de_fase = estado.pedido_de_fase, None
            self.jogo.ir_para_fase(fase)
            return True
        return False

    def _fala_automatica(self):
        for automatico in self.automaticos:
            if self.jogo.estado.condicao_ok(automatico.get("condicao")):
                return self._falar([automatico])
        return False

    def atualizar(self, dt):
        self._atualizar_variantes()
        if self._atender_pedidos() or self._fala_automatica():
            return
        self.jogador.mover(dt, self.bloqueado)
        if self.jogo.estado.flags.get("tem_lume") and self.lume is None:
            self.lume = Lume(self.jogador.x - 18, self.jogador.y - 30)
        if self.lume:
            self.lume.seguir(dt, self.jogador)

        # Só usa a porta ao entrar nela: quem acabou de chegar em cima de uma não volta na hora.
        portal = self._portal_nos_pes()
        if portal and portal is not self.portal_ativo:
            if self.jogo.estado.condicao_ok(portal.get("condicao")):
                self.carregar_mapa(portal["destino"], portal["dest_x"], portal["dest_y"], portal["direcao"])
            else:
                self._barrar(portal["barreira"])
            return
        self.portal_ativo = portal

        # O mesmo vale para as áreas com fala: só disparam ao entrar.
        gatilho = self._gatilho_nos_pes()
        if gatilho and gatilho is not self.gatilho_ativo:
            if "voltar" in gatilho:
                self._barrar({**gatilho["voltar"], "dialogos": gatilho["dialogos"]})
            else:
                self.gatilho_ativo = gatilho
                self._falar(gatilho["dialogos"])
            return
        self.gatilho_ativo = gatilho

    # ---------- Desenho ----------
    def camera(self):
        """Segue a Ada e para nas bordas. Em mapas menores que a tela, centraliza o mapa."""
        centro_x, centro_y = self.jogador.pes.center
        if self.mapa.largura <= LARGURA_TELA:
            x = (self.mapa.largura - LARGURA_TELA) // 2
        else:
            x = max(0, min(centro_x - LARGURA_TELA // 2, self.mapa.largura - LARGURA_TELA))
        if self.mapa.altura <= ALTURA_TELA:
            y = (self.mapa.altura - ALTURA_TELA) // 2
        else:
            y = max(0, min(centro_y - ALTURA_TELA // 2, self.mapa.altura - ALTURA_TELA))
        return x, y

    def desenhar(self, tela):
        camera = self.camera()
        tela.fill(pygame.Color(self.jogo.fonte.cores["fundo_caixa"]))
        tela.blit(self.mapa.superficie_chao, (-camera[0], -camera[1]))

        # Quem está mais para baixo na tela é desenhado por último, para ficar na frente.
        pessoas = [(npc.base, npc) for npc in self.npcs] + [(self.jogador.pes.bottom, self.jogador)]
        for _, pessoa in sorted(pessoas, key=lambda par: par[0]):
            pessoa.desenhar(tela, camera)

        tela.blit(self.mapa.superficie_frente, (-camera[0], -camera[1]))
        if self.lume:
            self.lume.desenhar(tela, camera)
