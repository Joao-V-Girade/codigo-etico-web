"""Lupa da Rafa (Fase 3, cena 3.3): checar um conteúdo antes de acreditar nele.

A tela mostra o conteúdo à esquerda e quatro abas à direita: FONTE, DATA, CONTEXTO e IMAGEM, as
quatro perguntas da Rafa. O jogador checa cada aba e lê o que ela descobre. No vídeo falso, a aba
IMAGEM pede mais: o jogador move a Lupa sobre o vídeo e marca os três sinais de manipulação (seis
dedos, sombra do lado errado e boca fora do tempo da voz). Com tudo checado, ele decide se o conteúdo
é VERDADEIRO, FALSO ou ENGANOSO, e a Rafa comenta. Errar não tem castigo: dá para tentar de novo.

A mesma tela serve para o Vô Arlindo ("lupa_vo"), só com as abas FONTE e DATA e sem veredito.
Os textos ficam em data/lupa.json. Como os Termos de Uso, a cena não mexe em flags: ela só avisa
como terminou ("terminou" ou "saiu"), e a fala seguinte vem do campo "depois" da sessão.
"""

import pygame

from src.cenas.cena import Cena
from src.sistemas.cores import cor
from src.sistemas.entrada import acao_do_evento, esta_pressionada
from src.sistemas.recursos import ler_json
from src.sistemas.textos import resolver
from src.ui.caixa_texto import desenhar_caixa, quebrar_em_linhas

JANELA = pygame.Rect(8, 4, 304, 172)
PAINEL = pygame.Rect(14, 18, 158, 110)  # O conteúdo, em papel claro.
IMAGEM = pygame.Rect(PAINEL.left + 5, PAINEL.bottom - 52, 148, 48)
ABAS_X, ABAS_Y, ABA_ALTURA = 178, 18, 15
ACHADO = pygame.Rect(178, 82, 128, 46)
RODAPE = pygame.Rect(14, 132, 292, 40)
ALTURA_LINHA = 11
VELOCIDADE_DA_LUPA = 55  # em pontos (0 a 100) por segundo
RAIO_DA_LUPA = 5


class CenaChecagem(Cena):
    def __init__(self, jogo, sessao, ao_terminar):
        super().__init__(jogo)
        self.dados = ler_json("data/lupa.json")
        self.sessao = self.dados["sessoes"][sessao]
        self.ao_terminar = ao_terminar
        self.indice = 0
        self.fechou = False
        self._comecar_conteudo()

    # ---------- Estado ----------
    def _comecar_conteudo(self):
        self.modo = "abas"
        self.aba = 0
        self.checadas = set()
        self.achados = set()  # índices dos sinais já marcados na imagem
        self.cursor = [50.0, 50.0]
        self.opcao = 0
        self.aviso = ""
        self.comentario = ""
        self.acertou = False

    @property
    def conteudo(self):
        return self.dados["conteudos"][self.sessao["conteudos"][self.indice]]

    @property
    def abas(self):
        return self.sessao["abas"]

    @property
    def vereditos(self):
        return list(self.dados["vereditos"])

    def _texto(self, texto):
        return resolver(texto, self.jogo.estado.nome)

    def _precisa_apontar(self, aba):
        return aba == "imagem" and self.conteudo.get("sinais")

    # ---------- Ações (os testes também usam) ----------
    def checar(self):
        """Checa a aba escolhida. Na IMAGEM do vídeo falso, abre a Lupa para apontar os sinais."""
        aba = self.abas[self.aba]
        if self._precisa_apontar(aba) and len(self.achados) < len(self.conteudo["sinais"]):
            self.modo = "apontar"
            self.aviso = ""
            return
        self.checadas.add(aba)
        self._conferir_se_acabou()

    def _conferir_se_acabou(self):
        if len(self.checadas) < len(self.abas):
            return
        if self.sessao["veredito"]:
            self.modo = "veredito"
        else:
            self.modo = "pronto"

    def marcar(self):
        """Marca o ponto embaixo da Lupa. Acertar um sinal novo conta; errar mostra um aviso."""
        x, y = self.cursor
        for indice, sinal in enumerate(self.conteudo["sinais"]):
            if sinal["x"] <= x <= sinal["x"] + sinal["largura"] and sinal["y"] <= y <= sinal["y"] + sinal["altura"]:
                if indice not in self.achados:
                    self.achados.add(indice)
                    self.aviso = self._texto(sinal["nome"])
                    if len(self.achados) == len(self.conteudo["sinais"]):
                        self.checadas.add("imagem")
                        self.modo = "abas"
                        self._conferir_se_acabou()
                return True
        self.aviso = self._texto(self.dados["nada_aqui"])
        return False

    def responder(self, chave):
        """Dá o veredito. A Rafa comenta, e só a resposta certa passa para o próximo conteúdo."""
        self.acertou = chave == self.conteudo["certo"]
        if self.acertou:
            self.comentario = self.conteudo["ao_acertar"]
        else:
            self.comentario = self.conteudo["ao_errar"].get(chave, self.conteudo["ao_errar"].get("falso", ""))
        self.modo = "comentario"

    def _proximo(self):
        self.indice += 1
        if self.indice >= len(self.sessao["conteudos"]):
            self._fechar("terminou")
        else:
            self._comecar_conteudo()

    def _fechar(self, resultado):
        if self.fechou:
            return
        self.fechou = True
        self.jogo.desempilhar()
        self.ao_terminar(self.sessao["depois"].get(resultado))

    # ---------- Teclas ----------
    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        if not acao:
            return
        if self.modo == "abas":
            if acao in ("cima", "baixo"):
                self.aba = (self.aba + (1 if acao == "baixo" else -1)) % len(self.abas)
            elif acao == "confirmar":
                self.checar()
            elif acao == "cancelar":
                self._fechar("saiu")
        elif self.modo == "apontar":
            if acao == "confirmar":
                self.marcar()
            elif acao == "cancelar":
                self.modo = "abas"
                self.aviso = ""
        elif self.modo == "veredito":
            if acao in ("esquerda", "direita"):
                self.opcao = (self.opcao + (1 if acao == "direita" else -1)) % len(self.vereditos)
            elif acao == "confirmar":
                self.responder(self.vereditos[self.opcao])
            elif acao == "cancelar":
                self.modo = "abas"
        elif self.modo == "comentario":
            if acao == "confirmar":
                if self.acertou:
                    self._proximo()
                else:
                    self.modo = "veredito"
        elif self.modo == "pronto" and acao == "confirmar":
            self._proximo()

    def atualizar(self, dt):
        if self.modo != "apontar":
            return
        passo = VELOCIDADE_DA_LUPA * dt
        for acao, eixo, sinal in (("esquerda", 0, -1), ("direita", 0, 1), ("cima", 1, -1), ("baixo", 1, 1)):
            if esta_pressionada(acao):
                self.cursor[eixo] = max(0.0, min(100.0, self.cursor[eixo] + sinal * passo))

    # ---------- Desenho ----------
    def desenhar(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        sombra = pygame.Surface(tela.get_size(), pygame.SRCALPHA)
        sombra.fill((0, 0, 0, 160))
        tela.blit(sombra, (0, 0))
        desenhar_caixa(tela, JANELA, cores["borda_caixa"], cores["fundo_caixa"])
        titulo = self._texto(self.dados["titulo"])
        contagem = f"{self.indice + 1}/{len(self.sessao['conteudos'])}"
        fonte.desenhar(tela, JANELA.left + 6, JANELA.top + 3, titulo, cores["destaque"], cores["sombra"])
        fonte.desenhar(tela, JANELA.right - 6 - fonte.largura(contagem), JANELA.top + 3, contagem, cores["texto"], cores["sombra"])
        self._desenhar_conteudo(tela)
        self._desenhar_abas(tela)
        self._desenhar_rodape(tela)

    def _desenhar_conteudo(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        desenhar_caixa(tela, PAINEL, cores["claro_texto"], cores["claro_fundo"], 1)
        recorte = tela.get_clip()
        tela.set_clip(PAINEL.inflate(-2, -2))
        y = PAINEL.top + 3
        for paragrafo in self.conteudo["linhas"]:
            for linha in quebrar_em_linhas(fonte, self._texto(paragrafo), PAINEL.width - 8):
                if y + ALTURA_LINHA > IMAGEM.top:
                    break
                fonte.desenhar(tela, PAINEL.left + 4, y, linha, cores["claro_texto"], cores["claro_sombra"])
                y += ALTURA_LINHA
        tela.set_clip(recorte)
        desenhar = {"rio": self._imagem_rio, "nota": self._imagem_nota, "video": self._imagem_video}[self.conteudo["imagem"]]
        desenhar(tela)
        for indice in self.achados:
            sinal = self.conteudo["sinais"][indice]
            pygame.draw.rect(tela, cores["positivo"], self._na_imagem(sinal["x"], sinal["y"], sinal["largura"], sinal["altura"]), 1)
        if self.modo == "apontar":
            x, y = self._ponto(*self.cursor)
            pygame.draw.circle(tela, cores["destaque"], (x, y), RAIO_DA_LUPA, 1)
            tela.set_at((x, y), cores["destaque"])

    def _ponto(self, x, y):
        """De 0 a 100 dentro do desenho para pixels da tela."""
        return int(IMAGEM.left + x * IMAGEM.width / 100), int(IMAGEM.top + y * IMAGEM.height / 100)

    def _na_imagem(self, x, y, largura, altura):
        esquerda, topo = self._ponto(x, y)
        direita, baixo = self._ponto(x + largura, y + altura)
        return pygame.Rect(esquerda, topo, direita - esquerda, baixo - topo)

    def _imagem_rio(self, tela):
        """A foto do rio marrom: real, mas de outra cidade e de 3 anos atrás."""
        pygame.draw.rect(tela, cor("ceu.ceu"), IMAGEM)
        pygame.draw.rect(tela, cor("verde.floresta"), (IMAGEM.left, IMAGEM.top + 18, IMAGEM.width, 8))
        pygame.draw.rect(tela, cor("vila.marrom"), (IMAGEM.left, IMAGEM.top + 26, IMAGEM.width, IMAGEM.height - 26))
        for x in range(IMAGEM.left + 6, IMAGEM.right - 10, 22):
            pygame.draw.line(tela, cor("vila.terracota"), (x, IMAGEM.top + 34), (x + 10, IMAGEM.top + 32))

    def _imagem_nota(self, tela):
        """Nota da rádio: só texto, sem imagem."""
        pygame.draw.rect(tela, cor("neutros.gelo"), IMAGEM)
        for i in range(4):
            pygame.draw.line(tela, cor("neutros.cinza"), (IMAGEM.left + 8, IMAGEM.top + 8 + i * 9), (IMAGEM.right - 8 - (i % 2) * 30, IMAGEM.top + 8 + i * 9))

    def _imagem_video(self, tela):
        """O deepfake: a Ada na frente do hospital, com os três sinais escondidos no desenho."""
        pygame.draw.rect(tela, cor("neutros.gelo"), IMAGEM)
        pygame.draw.rect(tela, cor("vermelho.vermelho"), (IMAGEM.right - 30, IMAGEM.top + 6, 4, 12))  # a cruz do hospital
        pygame.draw.rect(tela, cor("vermelho.vermelho"), (IMAGEM.right - 34, IMAGEM.top + 10, 12, 4))
        pygame.draw.circle(tela, cor("eco.alerta"), (IMAGEM.left + 8, IMAGEM.top + 8), 5)  # a luz vem da esquerda...
        pygame.draw.ellipse(tela, cor("neutros.cinza"), self._na_imagem(4, 76, 30, 16))  # ...e a sombra também cai para a esquerda
        cabeca = self._ponto(42, 20)
        pygame.draw.rect(tela, cor("eco.violeta"), (cabeca[0] - 6, cabeca[1] + 6, 12, 18))  # corpo
        pygame.draw.circle(tela, cor("pele.p2"), cabeca, 6)
        pygame.draw.rect(tela, cor("cabelo.castanho"), (cabeca[0] - 6, cabeca[1] - 6, 12, 4))
        boca = self._ponto(42, 30)
        pygame.draw.line(tela, cor("vermelho.vermelho"), (boca[0] - 3, boca[1]), (boca[0] + 1, boca[1] + 1))  # boca torta
        mao = self._ponto(62, 48)
        pygame.draw.line(tela, cor("eco.violeta"), (cabeca[0] + 6, cabeca[1] + 10), mao, 2)  # o braço com o Pulsor
        for dedo in range(6):  # seis dedos
            pygame.draw.line(tela, cor("pele.p2"), mao, (mao[0] + 3, mao[1] - 4 + dedo * 2))
        pygame.draw.rect(tela, cor("vermelho.vermelho"), (IMAGEM.left + 2, IMAGEM.top + 2, 3, 3))  # gravando

    def _desenhar_abas(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        for i, aba in enumerate(self.abas):
            caixa = pygame.Rect(ABAS_X, ABAS_Y + i * ABA_ALTURA, ACHADO.width, ABA_ALTURA - 2)
            escolhida = i == self.aba and self.modo in ("abas", "apontar")
            borda = cores["selecionado"] if escolhida else cores["desativado"]
            desenhar_caixa(tela, caixa, borda, cores["fundo_caixa"], 1)
            nome = self._texto(self.dados["abas"][aba])
            cor_nome = cores["positivo"] if aba in self.checadas else cores["texto"]
            fonte.desenhar(tela, caixa.left + 5, caixa.top + 1, nome, cor_nome, cores["sombra"])
            if aba in self.checadas:
                fonte.desenhar(tela, caixa.right - 5 - fonte.largura("OK"), caixa.top + 1, "OK", cores["positivo"], cores["sombra"])
        # O que a aba escolhida descobriu (só depois de checada).
        desenhar_caixa(tela, ACHADO, cores["claro_texto"], cores["claro_fundo"], 1)
        aba = self.abas[self.aba]
        if aba in self.checadas:
            texto = self.conteudo["achados"][aba]
        elif self._precisa_apontar(aba) and self.modo == "apontar":
            texto = self.dados["sinais_achados"].replace("{N}", str(len(self.achados))).replace("{T}", str(len(self.conteudo["sinais"])))
        else:
            texto = "?"
        y = ACHADO.top + 3
        for linha in quebrar_em_linhas(fonte, self._texto(texto), ACHADO.width - 8)[:3]:
            fonte.desenhar(tela, ACHADO.left + 4, y, linha, cores["claro_texto"], cores["claro_sombra"])
            y += ALTURA_LINHA + 1

    def _desenhar_rodape(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        desenhar_caixa(tela, RODAPE, cores["borda_caixa"], cores["fundo_caixa"], 1)
        x, y = RODAPE.left + 5, RODAPE.top + 3
        if self.modo == "veredito":
            fonte.desenhar(tela, x, y, self._texto(self.dados["instrucao_veredito"]), cores["texto"], cores["sombra"])
            posicao = x
            for i, chave in enumerate(self.vereditos):
                nome = self.dados["vereditos"][chave]
                escolhida = i == self.opcao
                if escolhida:
                    pygame.draw.rect(tela, cores["selecionado"], (posicao - 3, y + 15, fonte.largura(nome) + 6, ALTURA_LINHA + 3), 1)
                fonte.desenhar(tela, posicao, y + 17, nome, cores["selecionado"] if escolhida else cores["texto"], cores["sombra"])
                posicao += fonte.largura(nome) + 18
            return
        if self.modo == "comentario":
            texto = f"{self._texto(self.dados['quem_comenta'])}: {self._texto(self.comentario)}"
            cor_texto = cores["positivo"] if self.acertou else cores["alerta"]
        elif self.modo == "pronto":
            texto = self._texto(self.sessao.get("ao_terminar_texto", "")) + " " + self._texto(self.dados["instrucao_pronto"])
            cor_texto = cores["positivo"]
        elif self.modo == "apontar":
            texto = (self.aviso + " " if self.aviso else "") + self._texto(self.dados["instrucao_apontar"])
            cor_texto = cores["texto"]
        else:
            texto = self._texto(self.dados["instrucao_abas"])
            cor_texto = cores["texto"]
        for linha in quebrar_em_linhas(fonte, texto, RODAPE.width - 10)[:3]:
            fonte.desenhar(tela, x, y, linha, cor_texto, cores["sombra"])
            y += ALTURA_LINHA + 1
