"""Tela de título (cena 0.1): o nome do jogo sobre a vila ao amanhecer e o menu principal.

O fundo reaproveita as camadas da arena da Vila, que se movem devagar (D60: sem desenho novo na FP3).
"""

import pygame

from config import ALTURA_TELA, LARGURA_TELA
from src.cenas.cartaz import CenaCartaz
from src.cenas.cena import Cena
from src.cenas.configuracoes import CenaConfiguracoes
from src.cenas.nome import CenaNome
from src.sistemas.entrada import acao_do_evento
from src.sistemas.recursos import carregar_imagem, ler_json
from src.sistemas.textos import resolver
from src.ui.caixa_texto import desenhar_caixa
from src.ui.menu import ListaDeOpcoes

# Camada e velocidade em pixels por segundo: quanto mais perto, mais rápido.
CAMADAS = (("vila_ceu", 0), ("vila_nuvens", 3), ("vila_distante", 2), ("vila_telhados", 5))
Y_LOGO = 26
Y_MENU = 104
TEMPO_DO_AVISO = 2.0
OPCOES = ("novo_jogo", "continuar", "configuracoes", "creditos")


class CenaTitulo(Cena):
    def __init__(self, jogo):
        super().__init__(jogo)
        interface = ler_json("data/interface.json")
        self.textos = interface["titulo"]
        self.creditos = interface["creditos"]
        # A demo não salva (09, seção 1), então "Continuar" aparece apagado.
        self.lista = ListaDeOpcoes([self.textos[chave] for chave in OPCOES], desativadas={1})
        self.camadas = [(carregar_imagem(f"assets/fundos/{nome}.png"), velocidade) for nome, velocidade in CAMADAS]
        self.chao = carregar_imagem("assets/fundos/vila_chao.png")
        self.tempo = 0.0
        self.aviso = 0.0

    def _x_menu(self):
        return (LARGURA_TELA - self.lista.largura(self.jogo.fonte)) // 2

    def _escolher(self, indice):
        chave = OPCOES[indice]
        if chave == "novo_jogo":
            self.jogo.empilhar(CenaNome(self.jogo))
        elif chave == "continuar":
            self.aviso = TEMPO_DO_AVISO
        elif chave == "configuracoes":
            self.jogo.empilhar(CenaConfiguracoes(self.jogo))
        elif chave == "creditos":
            self.jogo.empilhar(CenaCartaz(self.jogo, self.creditos["linhas"], lambda: None,
                                          titulo=self.creditos["titulo"], instrucao=self.creditos["instrucao"]))

    def tratar_evento(self, evento):
        if evento.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN):
            x = self._x_menu()
            indice = self.lista.opcao_no_ponto(evento.pos, x, Y_MENU + 4, self.lista.largura(self.jogo.fonte))
            if indice is not None:
                self.lista.indice = indice
                if evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                    self._escolher(indice)
            return
        escolhida = self.lista.tratar_acao(acao_do_evento(evento))
        if escolhida is not None:
            self._escolher(escolhida)

    def atualizar(self, dt):
        self.tempo += dt
        self.aviso = max(0.0, self.aviso - dt)

    def desenhar(self, tela):
        fonte = self.jogo.fonte
        for imagem, velocidade in self.camadas:
            largura = imagem.get_width()
            deslocamento = int(self.tempo * velocidade) % largura if velocidade else 0
            tela.blit(imagem, (-deslocamento, 0))
            if velocidade:
                tela.blit(imagem, (largura - deslocamento, 0))
        tela.blit(self.chao, (0, ALTURA_TELA - self.chao.get_height()))

        logo = fonte.grande(resolver("{JOGO}"), 3, fonte.cores["texto"], fonte.cores["fundo_caixa"])
        tela.blit(logo, ((LARGURA_TELA - logo.get_width()) // 2, Y_LOGO))
        subtitulo = self.textos["subtitulo"]
        fundo = pygame.Rect(0, 0, fonte.largura(subtitulo) + 12, 14)
        fundo.midtop = (LARGURA_TELA // 2, Y_LOGO + logo.get_height() + 4)
        desenhar_caixa(tela, fundo, fonte.cores["fundo_caixa"], fonte.cores["fundo_caixa"], 1)
        fonte.desenhar(tela, fundo.left + 6, fundo.top + 1, subtitulo, fonte.cores["destaque"])

        self.lista.desenhar(tela, fonte, self._x_menu(), Y_MENU)
        if self.aviso > 0:
            fonte.desenhar_centralizado(tela, ALTURA_TELA - 14, self.textos["sem_save"], fonte.cores["selecionado"])
