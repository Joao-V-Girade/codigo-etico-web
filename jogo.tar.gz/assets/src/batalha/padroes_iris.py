"""Os 10 primeiros ataques da ÍRIS (D63). Os outros 10 ficam em padroes_iris2.py (D69). Nenhum é cópia de outro chefe.

Ela nunca sai do lugar: o que parte dela sai sempre do mesmo ponto, o olho, no alto e no meio da caixa.
Tema: o que acontece quando um sistema só persegue eficiência e ninguém revisa as decisões dele.

1. Raios em Leque: raios saem do olho, e é preciso ficar na brecha.
2. Corredor de Dados: uma meta única, com um só caminho certo.
3. Ponto de Foco: a mira segue a mini Ada, trava e o raio dispara na linha travada.
4. Grade de Decisão: colunas pares e ímpares se alternam, e uma linha alta pune quem pula.
5. Triagem: três andares, e só o de prioridade ALTA é poupado.
6. Reflexo: um laser ricocheteia, com o trajeto desenhado antes.
7. Erro Repetido: sem revisão, cada erro volta a acontecer no mesmo lugar, e surgem novos.
8. Piso Ativo: o chão dá pulsos, e é preciso estar numa plataforma ou no ar.
9. Redução de Custos: o chão é vendido pedaço por pedaço, e o que foi cortado passa a machucar.
10. Protocolo Desligado: a caixa escurece, mas todo perigo continua brilhando.

Do 1 ao 5, o ataque existe nas duas formas. Na segunda, "forma2" (em data/batalha.json) muda o jeito dele (D69).
Do 6 ao 10, o ataque só existe na segunda forma.
"""

import math

import pygame

from src.batalha.padroes import Padrao
from src.batalha.padroes_chefes import ComItens, _desenhar_texto
from src.sistemas.cores import cor

LADO_DO_RAIO = 6
PASSO_DO_RAIO = 8
ALCANCE_DO_RAIO = 260


def _olho(caixa):
    """O ponto fixo de onde a ÍRIS atira: acima do meio da caixa, onde ela está de verdade."""
    return caixa.centerx, caixa.top - 8


def _pontos_da_linha(origem, angulo, caixa):
    for distancia in range(10, ALCANCE_DO_RAIO, PASSO_DO_RAIO):
        x = origem[0] + math.cos(angulo) * distancia
        y = origem[1] + math.sin(angulo) * distancia
        if caixa.top - 2 <= y <= caixa.bottom and caixa.left - 2 <= x <= caixa.right:
            yield int(x), int(y)


def _raio(origem, angulo, caixa, lado=LADO_DO_RAIO):
    metade = lado // 2
    return [pygame.Rect(x - metade, y - metade, lado, lado) for x, y in _pontos_da_linha(origem, angulo, caixa)]


class EmOndas(Padrao):
    """Base dos ataques em ondas: cada onda avisa, machuca e dá uma pequena pausa."""

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.total = self.dados["ondas"]
        self.onda = 0
        self.fase = "aviso"
        self.tempo_fase = 0.0
        self._nova_onda()

    def _nova_onda(self):
        pass

    def _areas(self):
        return []

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        if self.fase == "aviso" and self.tempo_fase >= self.dados["aviso"]:
            self.fase, self.tempo_fase = "ativo", 0.0
        elif self.fase == "ativo" and self.tempo_fase >= self.dados["ativo"]:
            self.fase, self.tempo_fase = "pausa", 0.0
        elif self.fase == "pausa" and self.tempo_fase >= self.dados.get("pausa", 0.1):
            self.onda += 1
            self.tempo_fase = 0.0
            if self.onda < self.total:
                self.fase = "aviso"
                self._nova_onda()
            else:
                self.fase = "fim"

    def terminou(self):
        return self.fase == "fim"

    def perigos(self):
        return self._areas() if self.fase == "ativo" else []

    def _piscando(self):
        return self.fase == "aviso" and int(self.tempo_fase * 12) % 2 == 0

    def desenhar(self, tela):
        if self._piscando():
            for area in self._areas():
                pygame.draw.rect(tela, cor("vitrine.rosa"), area, 1)
        elif self.fase == "ativo":
            for area in self._areas():
                pygame.draw.rect(tela, cor("vitrine.vidro"), area)


# 1
class RaiosEmLeque(EmOndas):
    """Raios saem do olho em leque. As brechas mudam de lugar a cada onda. Na segunda forma, o leque também gira."""

    def _nova_onda(self):
        quantos = self.dados["raios"] + (self.onda % 2)
        giro = self.dados.get("giro", 0.0) * (1 if self.onda % 2 else -1)
        self.angulos = [math.pi / 2 + giro + (indice - (quantos - 1) / 2) * self.dados["abertura"] for indice in range(quantos)]

    def _areas(self):
        origem = _olho(self.caixa)
        lado = self.dados.get("largura_do_raio", LADO_DO_RAIO)
        return [area for angulo in self.angulos for area in _raio(origem, angulo, self.caixa, lado)]

    def desenhar(self, tela):
        origem = _olho(self.caixa)
        if self._piscando():
            for angulo in self.angulos:
                fim = (origem[0] + math.cos(angulo) * ALCANCE_DO_RAIO, origem[1] + math.sin(angulo) * ALCANCE_DO_RAIO)
                pygame.draw.line(tela, cor("vitrine.rosa"), origem, fim)
        elif self.fase == "ativo":
            for area in self._areas():
                pygame.draw.rect(tela, cor("vitrine.vidro"), area)


# 2
class CorredorDeDados(Padrao):
    """Meta única: um caminho certo, que serpenteia. Na segunda forma, abre um segundo caminho, que vai fechando.

    O vão da primeira fileira fica longe da mini Ada, perto do limite do que ela alcança naquela velocidade: é difícil, mas dá.
    """

    depende_do_jogador = True

    ALTURA = 6
    LARGURA_MINIMA_DO_SEGUNDO = 16
    ALTURA_DA_MINI_ADA = 14
    METADE_DA_MINI_ADA = 4

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.fileiras = []
        self.proxima = self.dados["aviso"]
        self.restantes = self.dados["fileiras"]
        self.fase_da_onda = self.sorte.random() * math.tau
        self.primeiro_centro = None

    def _amplitude(self):
        return (self.caixa.width - self.dados["vao"]) / 2 - 4

    def _ritmo(self):
        """O caminho nunca anda de lado mais rápido que a mini Ada corre, em nenhuma velocidade de turno."""
        return min(self.dados["ritmo"], self.dados["lateral_maxima"] / (self._amplitude() * self.fator))

    def _centro(self):
        return self.caixa.centerx + math.sin(self.tempo * self._ritmo() + self.fase_da_onda) * self._amplitude()

    def antecedencia(self):
        # O chão mostra o primeiro vão desde o começo: dá para ver até a primeira fileira chegar.
        return self.dados["aviso"] + (self.caixa.height - self.ALTURA_DA_MINI_ADA) / self.dados["velocidade"]

    def _alcance_ate_a_primeira_fileira(self):
        """Quantos pixels dá para correr, depois de reagir, até a primeira fileira chegar à altura da mini Ada."""
        dados = self.dados
        tempo = self.antecedencia() / self.fator
        return max(0.0, tempo - dados["reacao_no_primeiro"]) * dados["corrida_no_primeiro"]

    def _escolher_primeiro_vao(self):
        """Põe o primeiro vão no limite do alcance, para o lado onde há mais espaço, e faz o caminho continuar dali."""
        x = self.jogador[0]
        c = self.caixa
        lado = (1 if x < c.centerx else -1) if x != c.centerx else self.sorte.choice((-1, 1))
        # Basta a área de dano da mini Ada caber no vão: não é preciso chegar ao meio dele.
        distancia = self._alcance_ate_a_primeira_fileira() + self.dados["vao"] / 2 - self.METADE_DA_MINI_ADA
        amplitude = self._amplitude()
        self.primeiro_centro = max(c.centerx - amplitude, min(x + lado * distancia, c.centerx + amplitude))
        # Calcula a onda que passa por este ponto na hora da primeira fileira, voltando para o meio da caixa.
        seno = max(-1.0, min(1.0, (self.primeiro_centro - c.centerx) / amplitude))
        angulo = math.pi - math.asin(seno) if self.primeiro_centro > c.centerx else math.asin(seno)
        self.fase_da_onda = angulo - self.dados["aviso"] * self._ritmo()

    def atualizar(self, dt):
        if self.primeiro_centro is None and self.jogador:
            self._escolher_primeiro_vao()
        super().atualizar(dt)
        self.proxima -= dt
        if self.proxima <= 0 and self.restantes > 0:
            numero = self.dados["fileiras"] - self.restantes
            self.restantes -= 1
            self.proxima += self.dados["intervalo"]
            self.fileiras.append({"y": float(self.caixa.top - self.ALTURA), "vaos": self._vaos(numero)})
        for fileira in self.fileiras:
            fileira["y"] += self.dados["velocidade"] * dt
        self.fileiras = [f for f in self.fileiras if f["y"] < self.caixa.bottom]

    def terminou(self):
        return self.restantes <= 0 and not self.fileiras

    def _vaos(self, numero):
        """Os trechos livres de uma fileira: (centro, largura). O segundo caminho nasce e vai fechando."""
        centro = self.primeiro_centro if numero == 0 and self.primeiro_centro is not None else self._centro()
        vao = self.dados["vao"]
        vaos = [(centro, vao)]
        total = self.dados["fileiras"]
        inicio, fim = total // 4, total * 3 // 4
        if self.dados.get("bifurca") and inicio <= numero < fim:
            maior = self.dados["vao_secundario"]
            largura = int(maior * (1 - (numero - inicio) / (fim - inicio)))
            if largura >= self.LARGURA_MINIMA_DO_SEGUNDO:
                lado = -1 if centro > self.caixa.centerx else 1
                vaos.append((centro + lado * (vao / 2 + self.dados["parede_entre_caminhos"] + largura / 2), largura))
        return vaos

    def _trechos(self, vaos, y, altura):
        """O que fica entre os trechos livres: é isso que machuca."""
        lista = []
        x = self.caixa.left
        for centro, largura in sorted(vaos):
            esquerda = int(centro - largura / 2)
            if esquerda > x:
                lista.append(pygame.Rect(x, y, esquerda - x, altura))
            x = max(x, esquerda + int(largura))
        if x < self.caixa.right:
            lista.append(pygame.Rect(x, y, self.caixa.right - x, altura))
        return lista

    def perigos(self):
        return [r for f in self.fileiras for r in self._trechos(f["vaos"], int(f["y"]), self.ALTURA)]

    def desenhar(self, tela):
        centro_livre = self.primeiro_centro if self.primeiro_centro is not None else self._centro()
        vaos = self.fileiras[0]["vaos"] if self.fileiras else [(centro_livre, self.dados["vao"])]
        # O chão marca só onde a próxima fileira vai bater: o caminho é o trecho sem marca.
        for r in self._trechos(vaos, self.caixa.bottom - 3, 3):
            pygame.draw.rect(tela, cor("vitrine.rosa"), r)
        for r in self.perigos():
            pygame.draw.rect(tela, cor("ceu.azul"), r)
            pygame.draw.line(tela, cor("vitrine.vidro"), r.topleft, r.topright)


# 3
class PontoDeFoco(Padrao):
    """A mira segue a mini Ada e trava. Na segunda forma, a linha disparada fica um tempo: a decisão dela não volta atrás."""

    depende_do_jogador = True

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["focos"]
        self.fase = "mira"
        self.tempo_fase = 0.0
        self.mira = alvo or caixa.center
        self.linhas = []

    def _angulo(self):
        origem = _olho(self.caixa)
        return math.atan2(self.mira[1] - origem[1], self.mira[0] - origem[0])

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        for linha in self.linhas:
            linha["t"] -= dt
        self.linhas = [linha for linha in self.linhas if linha["t"] > 0]
        if self.fase == "mira":
            if self.jogador and not self.alvo:
                self.mira = self.jogador
            if self.tempo_fase >= self.dados["seguir"]:
                self.alvo = None  # A memória só escolhe o primeiro foco.
                self.fase, self.tempo_fase = "travada", 0.0
        elif self.fase == "travada" and self.tempo_fase >= self.dados["aviso"]:
            self.fase, self.tempo_fase = "ativo", 0.0
        elif self.fase == "ativo" and self.tempo_fase >= self.dados["ativo"]:
            self.restantes -= 1
            self.tempo_fase = 0.0
            if self.dados.get("fica"):
                self.linhas.append({"angulo": self._angulo(), "t": self.dados["fica"]})
            self.fase = "mira" if self.restantes > 0 else "fim"

    def terminou(self):
        return self.fase == "fim"

    def perigos(self):
        if self.fase == "fim":
            return []
        origem = _olho(self.caixa)
        lista = [area for linha in self.linhas for area in _raio(origem, linha["angulo"], self.caixa)]
        return lista + _raio(origem, self._angulo(), self.caixa) if self.fase == "ativo" else lista

    def desenhar(self, tela):
        origem = _olho(self.caixa)
        for linha in self.linhas:
            for area in _raio(origem, linha["angulo"], self.caixa):
                pygame.draw.rect(tela, cor("vitrine.rosa"), area)
        if self.fase == "mira":
            pygame.draw.circle(tela, cor("neutros.gelo"), self.mira, 7, 1)
        elif self.fase == "travada":
            angulo = self._angulo()
            fim = (origem[0] + math.cos(angulo) * ALCANCE_DO_RAIO, origem[1] + math.sin(angulo) * ALCANCE_DO_RAIO)
            if int(self.tempo_fase * 14) % 2 == 0:
                pygame.draw.line(tela, cor("vitrine.rosa"), origem, fim)
            pygame.draw.circle(tela, cor("vitrine.rosa"), self.mira, 7, 1)
        elif self.fase == "ativo":
            for area in _raio(origem, self._angulo(), self.caixa):
                pygame.draw.rect(tela, cor("vitrine.vidro"), area)


# 4
class GradeDeDecisao(EmOndas):
    """Colunas pares e ímpares se alternam. A linha alta impede de resolver tudo pulando.

    O aviso mostra quadrados ocos, só com a borda verde, onde está livre, e eles piscam logo antes do ataque. É a única exceção à regra de
    que nada mostra o caminho, a pedido do usuário (D69).
    Na segunda forma, a ordem deixa de ser par e ímpar, mas as duas ondas seguintes aparecem antes, no teto.
    """

    COLUNAS = 8
    PISCADAS_POR_SEGUNDO = 16

    def iniciar(self, caixa, alvo=None):
        self.livres = []
        anteriores = None
        for _ in range(self.dados["ondas"]):
            anteriores = self._sortear_livres(anteriores)
            self.livres.append(anteriores)
        super().iniciar(caixa, alvo)

    def _sortear_livres(self, anteriores):
        """Toda coluna livre tem outra livre logo ao lado na onda seguinte: sempre dá tempo de chegar."""
        quantas = max(2, self.COLUNAS - self.dados["fechadas"])
        mascara = self.dados.get("mascara")
        if anteriores is None:
            if mascara:
                passo = self.COLUNAS // quantas
                inicio = self.sorte.randrange(passo)
                return [inicio + numero * passo for numero in range(quantas)]
            return sorted(self.sorte.sample([c for c in range(self.COLUNAS) if c % 2], quantas))
        escolha = set()
        for coluna in anteriores:
            vizinhas = [v for v in (coluna - 1, coluna + 1) if 0 <= v < self.COLUNAS and v not in anteriores]
            if vizinhas:
                escolha.add(self.sorte.choice(vizinhas))
        sobra = [c for c in range(self.COLUNAS) if c not in anteriores and c not in escolha]
        self.sorte.shuffle(sobra)
        return sorted(escolha | set(sobra[: max(0, quantas - len(escolha))]))

    def _coluna(self, indice):
        largura = self.caixa.width // self.COLUNAS
        return pygame.Rect(self.caixa.left + indice * largura, self.caixa.top, largura, self.caixa.height)

    def _linha_alta(self):
        return pygame.Rect(self.caixa.left, self.caixa.bottom - self.dados["altura_da_linha"], self.caixa.width, 5)

    def _livres_agora(self):
        return self.livres[min(self.onda, len(self.livres) - 1)]

    def _areas(self):
        lista = [self._coluna(c) for c in range(self.COLUNAS) if c not in self._livres_agora()]
        lista.append(self._linha_alta())
        return lista

    def _quadrado_livre(self, coluna):
        """O pedaço da coluna embaixo da linha alta: é só ali que a mini Ada fica a salvo."""
        area = self._coluna(coluna)
        topo = self._linha_alta().bottom
        return pygame.Rect(area.left, topo, area.width, self.caixa.bottom - topo)

    def _quadrados_acesos(self):
        """Ficam acesos durante o aviso e piscam no fim dele. O tempo é real, em qualquer velocidade de turno."""
        falta = (self.dados["aviso"] - self.tempo_fase) / self.fator
        return falta > self.dados["piscar_antes"] or int(falta * self.PISCADAS_POR_SEGUNDO) % 2 == 0

    def desenhar(self, tela):
        if self.fase == "aviso":
            if self._quadrados_acesos():
                for coluna in self._livres_agora():
                    pygame.draw.rect(tela, cor("verde.limao"), self._quadrado_livre(coluna), 1)
            # A linha alta passa também pelas colunas livres, então continua avisando em rosa.
            if self._piscando():
                pygame.draw.rect(tela, cor("vitrine.rosa"), self._linha_alta(), 1)
        elif self.fase == "ativo":
            for area in self._areas():
                pygame.draw.rect(tela, cor("vitrine.vidro"), area)
        if not self.dados.get("mascara") or self.fase == "fim":
            return
        # As próximas ondas ficam marcadas no teto: dá para planejar o caminho.
        for distancia in (1, 2):
            if self.onda + distancia < len(self.livres):
                for c in self.livres[self.onda + distancia]:
                    r = self._coluna(c)
                    pygame.draw.rect(tela, cor("verde.limao"), (r.left + 2, self.caixa.top + 1 + 4 * (distancia - 1), r.width - 4, 3 - distancia + 1))


# 5
class Triagem(EmOndas):
    """A ÍRIS decide quem vem primeiro: três andares com placas, e só o de prioridade ALTA é poupado.

    Na segunda forma, a placa troca uma vez durante o aviso: ela muda de ideia, e sempre sobra tempo de reagir.
    """

    ANDARES = 3
    ESPESSURA = 4

    def iniciar(self, caixa, alvo=None):
        self.poupado = 0
        c = caixa
        altura = self.ALTURA_DO_ANDAR = c.height // self.ANDARES
        largura = self.dados["largura_do_piso"]
        self.pisos = [
            pygame.Rect(c.left + 18, c.bottom - altura, largura, self.ESPESSURA),
            pygame.Rect(c.right - 18 - largura, c.bottom - altura, largura, self.ESPESSURA),
            pygame.Rect(c.centerx - (largura + 10) // 2, c.bottom - 2 * altura, largura + 10, self.ESPESSURA),
        ]
        super().iniciar(caixa, alvo)

    def plataformas(self):
        return self.pisos

    def _andar_vizinho(self):
        # Só muda para um andar vizinho: sempre dá tempo de chegar.
        return self.sorte.choice([a for a in (self.poupado - 1, self.poupado + 1) if 0 <= a < self.ANDARES])

    def _nova_onda(self):
        self.trocou = False
        if self.onda:
            self.poupado = self._andar_vizinho()
        else:
            # Na segunda forma, começa no chão: assim, a troca da placa nunca pede dois andares de uma vez.
            self.poupado = 0 if self.dados.get("troca") else 1

    def atualizar(self, dt):
        super().atualizar(dt)
        troca = self.dados.get("troca")
        if troca and self.fase == "aviso" and not self.trocou and self.tempo_fase >= troca:
            self.trocou = True
            self.poupado = self._andar_vizinho()

    def _faixa(self, andar):
        topo = self.caixa.bottom - (andar + 1) * self.ALTURA_DO_ANDAR
        if andar == self.ANDARES - 1:
            topo = self.caixa.top
        base = self.caixa.bottom - andar * self.ALTURA_DO_ANDAR
        return pygame.Rect(self.caixa.left, topo, self.caixa.width, base - topo - (self.ESPESSURA if andar else 0))

    def _areas(self):
        return [self._faixa(andar).inflate(0, -2) for andar in range(self.ANDARES) if andar != self.poupado]

    def desenhar(self, tela):
        for piso in self.pisos:
            pygame.draw.rect(tela, cor("vitrine.ciano"), piso)
        super().desenhar(tela)
        if self.fase == "fim":
            return
        for andar in range(self.ANDARES):
            faixa = self._faixa(andar)
            poupado = andar == self.poupado
            distancia = (andar - self.poupado) % self.ANDARES
            placa = "ALTA" if poupado else ("BAIXA" if distancia == 1 else "MÉDIA")
            _desenhar_texto(self, tela, placa, self.caixa.right - 36, faixa.top, "neutros.gelo")


# 6
class Reflexo(EmOndas):
    """Um laser ricocheteia nas paredes, com o trajeto desenhado antes. Um espelho que muda de lugar decide por onde ele sai."""

    def _nova_onda(self):
        self.espelho = self.caixa.width * self.sorte.uniform(0.25, 0.75)
        self.lado = 1 if self.onda % 2 == 0 else -1
        self.linhas = [self.lado] if self.onda == 0 else [self.lado, -self.lado]
        self.passo = self.sorte.randint(self.dados["passo_minimo"], self.dados["passo_maximo"])

    def _pontos(self, sentido):
        c = self.caixa
        for andado in range(0, c.width + self.passo, PASSO_DO_RAIO):
            # A altura vai e volta entre o teto e o chão; o lado vai e volta entre as paredes.
            fracao_y = abs((andado / self.passo) % 2 - 1)
            y = c.bottom - fracao_y * c.height
            largura = c.width
            posicao = (self.espelho + sentido * andado) % (2 * largura)
            x = c.left + (posicao if posicao < largura else 2 * largura - posicao)
            yield int(x), int(y)

    def _areas(self):
        metade = LADO_DO_RAIO // 2
        return [
            pygame.Rect(x - metade, y - metade, LADO_DO_RAIO, LADO_DO_RAIO)
            for sentido in self.linhas
            for x, y in self._pontos(sentido)
        ]

    def desenhar(self, tela):
        if self.fase != "fim":
            pygame.draw.rect(tela, cor("neutros.gelo"), (self.caixa.left + int(self.espelho) - 6, self.caixa.bottom - 3, 12, 3))
        if self._piscando():
            for sentido in self.linhas:
                for x, y in self._pontos(sentido):
                    pygame.draw.rect(tela, cor("vitrine.rosa"), (x - 1, y - 1, 2, 2))
        elif self.fase == "ativo":
            for area in self._areas():
                pygame.draw.rect(tela, cor("vitrine.vidro"), area)


# 7
class ErroRepetido(EmOndas):
    """Sem ninguém para corrigir, o erro se repete: cada coluna volta a disparar no mesmo lugar, cada vez mais larga."""

    COLUNAS = 8
    VEZES_QUE_CRESCE = 3

    def iniciar(self, caixa, alvo=None):
        self.erros = []
        self.nascimento = {}
        super().iniciar(caixa, alvo)

    def _nova_onda(self):
        if len(self.erros) >= self.dados["maximo_de_erros"]:
            return
        livres = [c for c in range(self.COLUNAS) if c not in self.erros]
        isoladas = [c for c in livres if c - 1 not in self.erros and c + 1 not in self.erros]
        novo = self.sorte.choice(isoladas or livres)
        self.erros.append(novo)
        self.nascimento[novo] = self.onda

    def _coluna(self, indice):
        largura = self.caixa.width // self.COLUNAS
        vezes = min(self.VEZES_QUE_CRESCE, self.onda - self.nascimento[indice])
        area = pygame.Rect(self.caixa.left + indice * largura, self.caixa.top, largura, self.caixa.height)
        return area.inflate(2 * vezes * self.dados["crescimento"], 0).clip(self.caixa)

    def _areas(self):
        return [self._coluna(indice) for indice in self.erros]

# 8
class PisoAtivo(EmOndas):
    """O chão inteiro dá pulsos. Só está seguro quem está numa plataforma ou no ar, e a plataforma some pouco depois de pisada."""

    depende_do_jogador = True
    ALTURA_DA_PLATAFORMA = 24

    def iniciar(self, caixa, alvo=None):
        largura = self.dados["largura_plataforma"]
        y = caixa.bottom - self.ALTURA_DA_PLATAFORMA
        self.todas = [pygame.Rect(caixa.left + int(caixa.width * f) - largura // 2, y, largura, 4) for f in (0.2, 0.5, 0.8)]
        super().iniciar(caixa, alvo)

    def _nova_onda(self):
        self.apagada = self.onda % len(self.todas)
        self.pisadas = {}

    def plataformas(self):
        return [p for indice, p in enumerate(self.todas) if indice != self.apagada and self.pisadas.get(indice, 1) > 0]

    def atualizar(self, dt):
        super().atualizar(dt)
        for indice in list(self.pisadas):
            self.pisadas[indice] -= dt
        if not self.jogador:
            return
        for indice, plataforma in enumerate(self.todas):
            em_cima = plataforma.left <= self.jogador[0] <= plataforma.right and 0 <= plataforma.top - self.jogador[1] <= 10
            if em_cima and indice != self.apagada and indice not in self.pisadas:
                self.pisadas[indice] = self.dados["tempo_depois_de_pisar"]

    def _areas(self):
        c = self.caixa
        altura = self.dados["altura_do_pulso"]
        return [pygame.Rect(c.left, c.bottom - altura, c.width, altura)]

    def desenhar(self, tela):
        for indice, plataforma in enumerate(self.todas):
            if plataforma in self.plataformas():
                # Pisca depois de pisada: ninguém cai sem aviso.
                if indice not in self.pisadas or int(self.pisadas[indice] * 14) % 2:
                    pygame.draw.rect(tela, cor("vitrine.ciano"), plataforma)
        super().desenhar(tela)


# 9
class ReducaoDeCustos(EmOndas):
    """O chão é vendido pedaço por pedaço, começando pelo que a mini Ada mais usa. O que foi cortado machuca: pule os buracos."""

    depende_do_jogador = True
    PEDACOS = 8
    ALTURA_DO_BURACO = 6

    def iniciar(self, caixa, alvo=None):
        self.cortados = []
        self.proximos = []
        self.uso = {}
        super().iniciar(caixa, alvo)

    def atualizar(self, dt):
        super().atualizar(dt)
        if self.jogador:
            pedaco = (self.jogador[0] - self.caixa.left) * self.PEDACOS // self.caixa.width
            self.uso[pedaco] = self.uso.get(pedaco, 0.0) + dt

    def _nova_onda(self):
        self.cortados += self.proximos
        livres = [p for p in range(self.PEDACOS) if p not in self.cortados]
        # Nunca corta dois vizinhos de um pedaço que já é buraco: sempre dá para pular para o outro lado.
        seguros = [p for p in livres if p - 1 not in self.cortados and p + 1 not in self.cortados]
        opcoes = list(seguros or livres)
        self.sorte.shuffle(opcoes)
        opcoes.sort(key=lambda p: -self.uso.get(p, 0.0))  # O que mais serve é o primeiro a ser vendido.
        quantos = min(self.dados["cortes_por_onda"], max(0, len(livres) - self.dados["pedacos_minimos"]), len(opcoes))
        self.proximos = opcoes[:quantos]

    def _pedaco(self, indice):
        largura = self.caixa.width // self.PEDACOS
        return pygame.Rect(self.caixa.left + indice * largura, self.caixa.bottom - self.ALTURA_DO_BURACO, largura, self.ALTURA_DO_BURACO)

    def perigos(self):
        if self.fase == "fim":
            return []
        lista = [self._pedaco(p) for p in self.cortados]
        if self.fase in ("ativo", "pausa"):
            lista += [self._pedaco(p) for p in self.proximos]
        return lista

    def desenhar(self, tela):
        if self.fase == "fim":
            return
        for r in self.perigos():
            pygame.draw.rect(tela, cor("vitrine.rosa"), r)
        if self.fase == "aviso" and int(self.tempo_fase * 12) % 2 == 0:
            for p in self.proximos:
                r = self._pedaco(p)
                pygame.draw.rect(tela, cor("vitrine.rosa"), (r.left, r.top - 8, r.width, 14), 1)
                _desenhar_texto(self, tela, self.dados["texto"], r.left + 2, r.top - 12, "vitrine.rosa")


# 10
class ProtocoloDesligado(ComItens):
    """Sem o Protocolo Guardião, a caixa escurece. Os erros continuam brilhando e vêm em pares, um alto e um baixo."""

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.proximo = 0.3
        self.lado = 1

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proximo -= dt
        if self.proximo <= 0 and self.tempo < self.dados["duracao"]:
            self.proximo += self.dados["intervalo"]
            self.lado = -self.lado
            tamanho = self.dados["tamanho"]
            alto_deste_lado = self.sorte.random() < 0.5
            for lado, alto in ((self.lado, alto_deste_lado), (-self.lado, not alto_deste_lado)):
                y = self.caixa.bottom - 34 if alto else self.caixa.bottom - tamanho - 1
                x = self.caixa.right if lado < 0 else self.caixa.left - tamanho
                self._agendar(x=float(x), y=y, l=tamanho, a=tamanho, vx=lado * self.dados["velocidade"])
        self._mover_itens(dt)

    def terminou(self):
        return self.tempo >= self.dados["duracao"] and not self.itens

    def desenhar(self, tela):
        escuro = pygame.Surface(self.caixa.size, pygame.SRCALPHA)
        escuro.fill((13, 11, 20, 235))
        tela.blit(escuro, self.caixa.topleft)
        for item in self.itens:
            r = self._retangulo(item)
            pygame.draw.rect(tela, cor("vitrine.rosa"), r.inflate(2, 2), 1)
            pygame.draw.rect(tela, cor("neutros.branco"), r.inflate(-4, -4))


# Os outros 10 ataques usam as classes daqui, por isso entram no fim.
from src.batalha.padroes_iris2 import ATAQUES_NOVOS_DA_IRIS  # noqa: E402

ATAQUES_DA_IRIS = {
    **ATAQUES_NOVOS_DA_IRIS,
    "raios_em_leque": RaiosEmLeque,
    "corredor_de_dados": CorredorDeDados,
    "ponto_de_foco": PontoDeFoco,
    "grade_de_decisao": GradeDeDecisao,
    "triagem": Triagem,
    "reflexo": Reflexo,
    "erro_repetido": ErroRepetido,
    "piso_ativo": PisoAtivo,
    "reducao_de_custos": ReducaoDeCustos,
    "protocolo_desligado": ProtocoloDesligado,
}
