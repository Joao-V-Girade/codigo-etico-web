"""Os ataques exclusivos de cada chefe (D58, D63). Cada um mostra na prática o tema do chefe.

Regras de justiça, que valem para todos (05, seção 5): o aviso dura pelo menos 0,75 s (0,5 s na velocidade
máxima), tudo que vem de fora é anunciado na borda antes de entrar, o escuro nunca esconde um perigo, e
rosa é sempre perigo. Nada mostra para onde ir: o jogador lê onde é perigoso e deduz a saída (D66).

CRIVO (vieses): Peneira, Carimbo Negado, Rótulos, Balança Pendente, Ciclo.
VIGIA (privacidade): Varredura, Pop-ups, Previsão, Vazamento, Rede de Cabos.
ECO (desinformação): Bolha de Filtro, Corrente, Comentários, Ao Vivo, Deepfake.
ÍRIS (responsabilidade): os 20 ataques ficam em padroes_iris.py e padroes_iris2.py.
Exo-Desligador (Dante): Pulso de Desligamento, Garras, Corte Geral, Vento do Heliponto, Alicate.
Os ataques supremos ficam em padroes_supremos.py.

Os números ficam em "padroes", em data/batalha.json. A lista "depende_do_jogador" diz se o ataque
reage à posição da mini Ada: os testes conferem esses ataques de outro jeito.
"""

import math

import pygame

from src.batalha.padroes import Padrao
from src.sistemas.cores import cor
from src.sistemas.recursos import carregar_imagem
from src.sistemas.textos import resolver


AVISO_DE_ENTRADA = 0.75


def _desenhar_texto(padrao, tela, texto, x, y, nome_cor="vila.sol"):
    """Os padrões só escrevem na tela durante o jogo: nos testes, não há fonte."""
    if padrao.fonte:
        padrao.fonte.desenhar(tela, x, y, resolver(texto), cor(nome_cor), cor("neutros.tinta"))


def _aviso_no_chao(tela, caixa, x, largura, tempo, nome_cor="vitrine.rosa"):
    if int(tempo * 10) % 2 == 0:
        pygame.draw.rect(tela, cor(nome_cor), (x, caixa.bottom - 3, largura, 3))


class ComItens(Padrao):
    """Base dos ataques com vários objetos: cada um tem posição, velocidade e tamanho."""

    FOLGA = 1  # A área que machuca é um pouco menor que o desenho.

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.itens = []

    def _agendar(self, **item):
        """Cria um objeto que espera fora da caixa, com um aviso na borda, antes de entrar."""
        item["aviso"] = self.dados.get("aviso_de_entrada", AVISO_DE_ENTRADA)
        self.itens.append(item)

    def _mover_itens(self, dt):
        for item in self.itens:
            if item.get("aviso", 0) > 0:
                item["aviso"] -= dt
                continue
            item["x"] += item.get("vx", 0) * dt
            item["y"] += item.get("vy", 0) * dt
        area = self.caixa.inflate(80, 80)
        self.itens = [i for i in self.itens if area.colliderect((i["x"], i["y"], i["l"], i["a"]))]

    def _retangulo(self, item):
        return pygame.Rect(int(item["x"]), int(item["y"]), item["l"], item["a"])

    def perigos(self):
        return [
            self._retangulo(i).inflate(-2 * self.FOLGA, -2 * self.FOLGA)
            for i in self.itens
            if i.get("machuca", True) and i.get("aviso", 0) <= 0
        ]

    def desenhar_avisos(self, tela):
        rosa = cor("vitrine.rosa")
        for item in self.itens:
            if item.get("aviso", 0) <= 0 or int(item["aviso"] * 12) % 2:
                continue
            r = self._retangulo(item)
            if item.get("vx", 0) > 0:
                pygame.draw.rect(tela, rosa, (self.caixa.left, r.top, 5, r.height))
            elif item.get("vx", 0) < 0:
                pygame.draw.rect(tela, rosa, (self.caixa.right - 5, r.top, 5, r.height))
            else:
                pygame.draw.rect(tela, rosa, (r.left, self.caixa.bottom - 3, r.width, 3))


# ---------- CRIVO: vieses ----------
class Peneira(Padrao):
    """Nunca usa memória. A divisória separa os lados: as regras são iguais, mas os buracos não são."""

    ALTURA = 8

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["grades"]
        self.buraco_x = caixa.left + caixa.width // 4
        self._nova_grade(primeira=True)

    def limites(self, interior):
        # A mini Ada fica presa no lado da Vila Baixa: ela não pode atravessar a divisória.
        return pygame.Rect(interior.left, interior.top, interior.width // 2 - 2, interior.height)

    def _nova_grade(self, primeira=False):
        metade = self.caixa.width // 2
        if not primeira:
            self.buraco_x += self.sorte.choice((-1, 1)) * self.sorte.randint(20, self.dados["distancia_maxima"])
        margem = self.dados["buraco_estreito"] // 2 + 2
        self.buraco_x = max(self.caixa.left + margem, min(self.buraco_x, self.caixa.left + metade - margem - 3))
        self.buraco_largo_x = self.caixa.centerx + self.sorte.randint(30, metade - 30)
        self.fase = "aviso"
        self.tempo_fase = 0.0
        self.y = float(self.caixa.top - self.ALTURA)

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        if self.fase == "aviso" and self.tempo_fase >= self.dados["aviso"]:
            self.fase = "caindo"
        elif self.fase == "caindo":
            self.y += self.dados["velocidade"] * dt
            if self.y >= self.caixa.bottom:
                self.restantes -= 1
                if self.restantes > 0:
                    self._nova_grade()
                else:
                    self.fase = "fim"

    def terminou(self):
        return self.fase == "fim"

    def _pedacos(self):
        y = int(self.y)
        c = self.caixa
        estreito = self.dados["buraco_estreito"] // 2
        largo = self.dados["buraco_largo"] // 2
        meio = c.centerx
        return [
            pygame.Rect(c.left, y, self.buraco_x - estreito - c.left, self.ALTURA),
            pygame.Rect(self.buraco_x + estreito, y, meio - self.buraco_x - estreito, self.ALTURA),
            pygame.Rect(meio, y, self.buraco_largo_x - largo - meio, self.ALTURA),
            pygame.Rect(self.buraco_largo_x + largo, y, c.right - self.buraco_largo_x - largo, self.ALTURA),
        ]

    def perigos(self):
        return self._pedacos() if self.fase == "caindo" else []

    def desenhar(self, tela):
        c = self.caixa
        pygame.draw.rect(tela, cor("neutros.gelo"), (c.centerx - 1, c.top, 2, c.height))
        _desenhar_texto(self, tela, self.dados["texto_esquerda"], c.left + 4, c.top, "balanca.bege")
        _desenhar_texto(self, tela, self.dados["texto_direita"], c.centerx + 5, c.top, "vila.sol")
        if self.fase == "fim":
            return
        estreito = self.dados["buraco_estreito"]
        largo = self.dados["buraco_largo"]
        # O aviso mostra só onde as grades vão bater: os buracos são os trechos sem marca.
        for pedaco in self._pedacos():
            pygame.draw.rect(tela, cor("vitrine.rosa"), (pedaco.left, c.bottom - 3, pedaco.width, 3))
        if self.fase == "caindo":
            for pedaco in self._pedacos():
                pygame.draw.rect(tela, cor("balanca.bege"), pedaco)
                pygame.draw.line(tela, cor("balanca.sepia"), pedaco.bottomleft, pedaco.bottomright)


class CarimboNegado(Padrao):
    """Um carimbo persegue a mini Ada, e a marca de NEGADO fica no chão por um tempo: é preciso pular."""

    depende_do_jogador = True
    LARGURA = 20

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["carimbos"]
        self.proximo = 0.1
        self.carimbos = []

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proximo -= dt
        if self.proximo <= 0 and self.restantes > 0:
            self.restantes -= 1
            self.proximo += self.dados["intervalo"]
            x = (self.alvo or self.jogador or self.caixa.center)[0]
            self.carimbos.append({"x": x, "fase": "aviso", "t": 0.0, "y": float(self.caixa.top - 14)})
        for carimbo in self.carimbos:
            carimbo["t"] += dt
            if carimbo["fase"] == "aviso" and carimbo["t"] >= self.dados["aviso"]:
                carimbo["fase"], carimbo["t"] = "caindo", 0.0
            elif carimbo["fase"] == "caindo":
                carimbo["y"] += self.dados["velocidade"] * dt
                if carimbo["y"] + 14 >= self.caixa.bottom:
                    carimbo["fase"], carimbo["t"] = "marca", 0.0
        self.carimbos = [c for c in self.carimbos if not (c["fase"] == "marca" and c["t"] >= self.dados["marca"])]

    def terminou(self):
        return self.restantes <= 0 and not self.carimbos

    def perigos(self):
        lista = []
        for c in self.carimbos:
            if c["fase"] == "caindo":
                lista.append(pygame.Rect(c["x"] - self.LARGURA // 2, int(c["y"]), self.LARGURA, 14))
            elif c["fase"] == "marca":
                lista.append(pygame.Rect(c["x"] - self.LARGURA // 2, self.caixa.bottom - 4, self.LARGURA, 4))
        return lista

    def desenhar(self, tela):
        for c in self.carimbos:
            esquerda = c["x"] - self.LARGURA // 2
            if c["fase"] == "aviso":
                _aviso_no_chao(tela, self.caixa, esquerda, self.LARGURA, c["t"])
            elif c["fase"] == "caindo":
                pygame.draw.rect(tela, cor("balanca.carimbo"), (esquerda, int(c["y"]) + 6, self.LARGURA, 8))
                pygame.draw.rect(tela, cor("vila.marrom"), (c["x"] - 4, int(c["y"]), 8, 6))
            else:
                pygame.draw.rect(tela, cor("balanca.carimbo"), (esquerda, self.caixa.bottom - 4, self.LARGURA, 4))


class Rotulos(ComItens):
    """Etiquetas voam pela caixa. A que pega cola um rótulo RISCO, que continua pesando pelo resto da luta (D63)."""

    cola_rotulo = True

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["rotulos"]
        self.proximo = 0.1
        self.lado = 1

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proximo -= dt
        if self.proximo <= 0 and self.restantes > 0:
            self.restantes -= 1
            self.proximo += self.dados["intervalo"]
            self.lado = -self.lado
            largura = 36
            alturas = (self.caixa.bottom - 9, self.caixa.bottom - 34)
            y = self.alvo[1] - 4 if self.alvo else self.sorte.choice(alturas)
            x = self.caixa.right if self.lado < 0 else self.caixa.left - largura
            self._agendar(x=float(x), y=y, l=largura, a=9, vx=self.lado * self.dados["velocidade"])
        self._mover_itens(dt)

    def terminou(self):
        return self.restantes <= 0 and not self.itens

    def desenhar(self, tela):
        for item in self.itens:
            r = self._retangulo(item)
            pygame.draw.rect(tela, cor("balanca.areia"), r)
            pygame.draw.rect(tela, cor("balanca.carimbo"), r, 1)
            _desenhar_texto(self, tela, self.dados["texto"], r.left + 2, r.top - 3, "balanca.carimbo")


class BalancaPendente(ComItens):
    """O chão pende para um lado e empurra a mini Ada para lá, onde caem os pesos. É preciso subir."""

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.lado_baixo = 1
        self.troca = self.dados["tempo_de_cada_lado"]
        self.proximo = 0.2

    def empurrao(self):
        return self.lado_baixo * self.dados["empurrao"]

    def atualizar(self, dt):
        super().atualizar(dt)
        self.troca -= dt
        if self.troca <= 0:
            self.troca += self.dados["tempo_de_cada_lado"]
            self.lado_baixo = -self.lado_baixo
        self.proximo -= dt
        if self.proximo <= 0 and self.tempo < self.dados["duracao"]:
            self.proximo += self.dados["intervalo"]
            zona = self.dados["zona_dos_pesos"]
            if self.lado_baixo > 0:
                x = self.caixa.right - self.sorte.randint(14, zona)
            else:
                x = self.caixa.left + self.sorte.randint(2, zona - 12)
            self._agendar(x=float(x), y=float(self.caixa.top - 12), l=12, a=12, vy=self.dados["velocidade"])
        self._mover_itens(dt)
        self.itens = [i for i in self.itens if i["y"] < self.caixa.bottom]

    def terminou(self):
        return self.tempo >= self.dados["duracao"] and not self.itens

    def desenhar(self, tela):
        c = self.caixa
        alto, baixo = (c.bottom - 8, c.bottom - 1) if self.lado_baixo > 0 else (c.bottom - 1, c.bottom - 8)
        pygame.draw.line(tela, cor("balanca.dourado"), (c.left, alto), (c.right, baixo), 2)
        for item in self.itens:
            r = self._retangulo(item)
            pygame.draw.rect(tela, cor("neutros.chumbo"), r)
            pygame.draw.rect(tela, cor("balanca.dourado"), (r.left + 3, r.top, 6, 3))


class Ciclo(Padrao):
    """Drones giram em círculos que aumentam: quanto mais drones, mais registros, mais drones."""

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.centro = (alvo[0], caixa.centery) if alvo else caixa.center
        self.raio_final = math.hypot(caixa.width, caixa.height) / 2 + 14

    def _posicoes(self):
        raio = 8 + self.tempo * self.dados["crescimento"]
        braços = self.dados["bracos"]
        for braco in range(braços):
            for camada in range(self.dados["camadas"]):
                r = raio - camada * self.dados["distancia_das_camadas"]
                if r > 4:
                    angulo = self.tempo * self.dados["rotacao"] + braco * math.tau / braços
                    yield int(self.centro[0] + math.cos(angulo) * r), int(self.centro[1] + math.sin(angulo) * r)

    def terminou(self):
        raio_ultimo = 8 + self.tempo * self.dados["crescimento"] - (self.dados["camadas"] - 1) * self.dados["distancia_das_camadas"]
        return raio_ultimo > self.raio_final

    def perigos(self):
        return [pygame.Rect(x - 3, y - 3, 6, 6) for x, y in self._posicoes()]

    def desenhar(self, tela):
        imagem = carregar_imagem("assets/sprites/ataques/drone.png")
        for x, y in self._posicoes():
            tela.blit(imagem, (x - 4, y - 4))


# ---------- VIGIA: privacidade ----------
class Varredura(Padrao):
    """Um laser desce pela caixa. Só a sombra embaixo dos pilares é segura."""

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["passadas"]
        self.pilar_y = caixa.top + 10
        self.pilar = None
        self._nova_passada()

    def _nova_passada(self):
        largura = self.dados["largura_do_pilar"]
        c = self.caixa
        anterior = self.pilar.centerx if self.pilar else c.centerx
        distancia = self.dados["distancia_maxima"]
        if self.alvo:
            centro = anterior + (distancia if self.alvo[0] < c.centerx else -distancia)
        else:
            centro = anterior + self.sorte.choice((-1, 1)) * self.sorte.randint(distancia // 2, distancia)
        centro = max(c.left + 24, min(centro, c.right - 24))
        self.pilar = pygame.Rect(centro - largura // 2, self.pilar_y, largura, 6)
        self.fase = "aviso"
        self.tempo_fase = 0.0
        self.y = float(self.pilar.bottom)

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        if self.fase == "aviso" and self.tempo_fase >= self.dados["aviso"]:
            self.fase = "descendo"
        elif self.fase == "descendo":
            self.y += self.dados["velocidade"] * dt
            if self.y >= self.caixa.bottom:
                self.restantes -= 1
                if self.restantes > 0:
                    self._nova_passada()
                else:
                    self.fase = "fim"

    def terminou(self):
        return self.fase == "fim"

    def perigos(self):
        if self.fase != "descendo":
            return []
        y = int(self.y)
        c = self.caixa
        return [
            pygame.Rect(c.left, y, self.pilar.left - c.left, 3),
            pygame.Rect(self.pilar.right, y, c.right - self.pilar.right, 3),
        ]

    def desenhar(self, tela):
        if self.fase == "fim":
            return
        pygame.draw.rect(tela, cor("neutros.gelo"), self.pilar)
        c = self.caixa
        if self.fase == "aviso":
            _aviso_no_chao(tela, c, c.left, self.pilar.left - c.left, self.tempo_fase)
            _aviso_no_chao(tela, c, self.pilar.right, c.right - self.pilar.right, self.tempo_fase)
        else:
            for retangulo in self.perigos():
                pygame.draw.rect(tela, cor("vitrine.ciano"), retangulo)


class PopUps(ComItens):
    """Janelas "ACEITAR?" aparecem e, quem passa por elas, fica lento: design que atrapalha quem quer sair.

    Os tiros passam na frente das janelas: atrapalhar é o papel delas, esconder um perigo não é justo.
    """

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.janelas = []
        self.proximo_tiro = 0.2
        self.proxima_janela = 0.4

    def atualizar(self, dt):
        super().atualizar(dt)
        ativo = self.tempo < self.dados["duracao"]
        self.proximo_tiro -= dt
        if self.proximo_tiro <= 0 and ativo:
            self.proximo_tiro += self.dados["intervalo_dos_tiros"]
            lado = self.sorte.choice((-1, 1))
            x = self.caixa.right if lado < 0 else self.caixa.left - 8
            y = self.sorte.choice((self.caixa.bottom - 9, self.caixa.bottom - 32))
            self._agendar(x=float(x), y=y, l=8, a=8, vx=lado * self.dados["velocidade"])
        self.proxima_janela -= dt
        if self.proxima_janela <= 0 and ativo:
            self.proxima_janela += self.dados["intervalo_das_janelas"]
            self.janelas.append({
                "x": self.sorte.randint(self.caixa.left, self.caixa.right - 62),
                "y": self.sorte.randint(self.caixa.top, self.caixa.bottom - 26),
                "t": self.dados["tempo_da_janela"],
            })
        for janela in self.janelas:
            janela["t"] -= dt
        self.janelas = [j for j in self.janelas if j["t"] > 0]
        self._mover_itens(dt)

    def lentidao(self):
        if self.jogador and any(pygame.Rect(j["x"], j["y"], 62, 26).collidepoint(self.jogador) for j in self.janelas):
            return self.dados["lentidao"]
        return 1.0

    def terminou(self):
        return self.tempo >= self.dados["duracao"] and not self.itens

    def desenhar(self, tela):
        for janela in self.janelas:
            r = pygame.Rect(janela["x"], janela["y"], 62, 26)
            pygame.draw.rect(tela, cor("neutros.chumbo"), r)
            pygame.draw.rect(tela, cor("neutros.gelo"), r, 1)
            pygame.draw.rect(tela, cor("neutros.gelo"), (r.left, r.top, r.width, 5))
            _desenhar_texto(self, tela, self.dados["texto"], r.left + 3, r.top + 8, "neutros.gelo")
        imagem = carregar_imagem("assets/sprites/ataques/tiro_inimigo.png")
        for item in self.itens:
            tela.blit(imagem, (int(item["x"]), item["y"]))


class Previsao(Padrao):
    """A VIGIA guarda onde a mini Ada mais fica, anuncia e ataca ali. Só mudar o hábito funciona."""

    depende_do_jogador = True

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["ataques"]
        self.contagem = [0.0, 0.0, 0.0]
        if alvo:
            self.contagem[self._terco_de(alvo[0])] += 4.0
        self._preparar()

    def _terco_de(self, x):
        return min(2, max(0, int((x - self.caixa.left) / self.caixa.width * 3)))

    def _preparar(self):
        self.terco = self.contagem.index(max(self.contagem))
        self.fase = "aviso"
        self.tempo_fase = 0.0

    def atualizar(self, dt):
        super().atualizar(dt)
        if self.jogador:
            self.contagem[self._terco_de(self.jogador[0])] += dt
        self.tempo_fase += dt
        if self.fase == "aviso" and self.tempo_fase >= self.dados["aviso"]:
            self.fase, self.tempo_fase = "ativo", 0.0
        elif self.fase == "ativo" and self.tempo_fase >= self.dados["ativo"]:
            self.restantes -= 1
            if self.restantes > 0:
                self._preparar()
            else:
                self.fase = "fim"

    def terminou(self):
        return self.fase == "fim"

    def _coluna(self):
        largura = self.caixa.width // 3
        return pygame.Rect(self.caixa.left + self.terco * largura, self.caixa.top, largura, self.caixa.height)

    def perigos(self):
        return [self._coluna()] if self.fase == "ativo" else []

    def desenhar(self, tela):
        if self.fase == "fim":
            return
        coluna = self._coluna()
        if self.fase == "aviso":
            if int(self.tempo_fase * 10) % 2 == 0:
                pygame.draw.rect(tela, cor("vitrine.rosa"), coluna, 1)
            _desenhar_texto(self, tela, self.dados["textos"][self.terco], self.caixa.left + 6, self.caixa.top, "vitrine.rosa")
        else:
            pygame.draw.rect(tela, cor("vitrine.rosa"), coluna)
            pygame.draw.rect(tela, cor("neutros.branco"), coluna.inflate(-8, -2))


class Vazamento(ComItens):
    """Fichas de dados vazam do teto em colunas, e o vazamento muda de lugar."""

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.proxima_coluna = 0.0
        self.colunas = []

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proxima_coluna -= dt
        if self.proxima_coluna <= 0 and self.tempo < self.dados["duracao"]:
            self.proxima_coluna += self.dados["intervalo_das_colunas"]
            largura = self.dados["largura_da_coluna"]
            x = self.sorte.randrange(self.caixa.left, self.caixa.right - largura, largura)
            self.colunas.append({"x": x, "aviso": self.dados["aviso"], "gotas": self.dados["gotas"], "espera": 0.0})
        for coluna in self.colunas:
            if coluna["aviso"] > 0:
                coluna["aviso"] -= dt
                continue
            coluna["espera"] -= dt
            if coluna["espera"] <= 0 and coluna["gotas"] > 0:
                coluna["gotas"] -= 1
                coluna["espera"] = self.dados["intervalo_das_gotas"]
                self.itens.append({"x": float(coluna["x"] + 3), "y": float(self.caixa.top - 8), "l": 8, "a": 8, "vy": self.dados["velocidade"]})
        self.colunas = [c for c in self.colunas if c["gotas"] > 0]
        self._mover_itens(dt)
        self.itens = [i for i in self.itens if i["y"] < self.caixa.bottom]

    def terminou(self):
        return self.tempo >= self.dados["duracao"] and not self.itens and not self.colunas

    def desenhar(self, tela):
        for coluna in self.colunas:
            if coluna["aviso"] > 0:
                _aviso_no_chao(tela, self.caixa, coluna["x"], self.dados["largura_da_coluna"], coluna["aviso"])
        for item in self.itens:
            r = self._retangulo(item)
            pygame.draw.rect(tela, cor("vitrine.ciano"), r)
            pygame.draw.rect(tela, cor("vitrine.petroleo"), r, 1)


class RedeDeCabos(ComItens):
    """Cabos saem do chão, com faísca antes. Os baixos dá para pular. Dos altos, só saindo de perto."""

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["cabos"]
        self.proximo = 0.1
        self.cabos = []

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proximo -= dt
        if self.proximo <= 0 and self.restantes > 0:
            alto = self.restantes % 2 == 0
            self.restantes -= 1
            self.proximo += self.dados["intervalo"]
            x = (self.alvo[0] - 4) if self.alvo else self.sorte.randint(self.caixa.left + 2, self.caixa.right - 12)
            self.cabos.append({"x": x, "altura": 0.0, "max": self.caixa.height if alto else self.dados["altura_baixa"], "t": 0.0, "fase": "aviso"})
        for cabo in self.cabos:
            cabo["t"] += dt
            if cabo["fase"] == "aviso" and cabo["t"] >= self.dados["aviso"]:
                cabo["fase"], cabo["t"] = "sobe", 0.0
            elif cabo["fase"] == "sobe":
                cabo["altura"] = min(cabo["max"], cabo["altura"] + self.dados["velocidade"] * dt)
                if cabo["t"] >= self.dados["tempo_de_cabo"]:
                    cabo["fase"] = "fim"
        self.cabos = [c for c in self.cabos if c["fase"] != "fim"]

    def terminou(self):
        return self.restantes <= 0 and not self.cabos

    def perigos(self):
        return [
            pygame.Rect(c["x"], self.caixa.bottom - int(c["altura"]), 8, int(c["altura"]))
            for c in self.cabos if c["fase"] == "sobe" and c["altura"] >= 1
        ]

    def desenhar(self, tela):
        for cabo in self.cabos:
            if cabo["fase"] == "aviso":
                _aviso_no_chao(tela, self.caixa, cabo["x"], 8, cabo["t"], "vila.sol")
        for r in self.perigos():
            pygame.draw.rect(tela, cor("neutros.grafite"), r)
            pygame.draw.rect(tela, cor("vitrine.rosa"), (r.left + 3, r.top, 2, r.height))


# ---------- ECO: desinformação ----------
class BolhaDeFiltro(ComItens):
    """Uma bolha cresce onde a mini Ada está e estoura em pedaços. Quem fica na bolha só recebe mais do mesmo."""

    depende_do_jogador = True

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["bolhas"]
        self.proxima = 0.1
        self.bolhas = []
        self.estouros = []

    def receber_luta(self, luta):
        super().receber_luta(luta)
        self.restantes += self.intensidade

    def _criar_bolha(self):
        x, y = self.alvo or self.jogador or self.caixa.center
        raio = self.dados["raio"]
        x = max(self.caixa.left + raio, min(x, self.caixa.right - raio))
        y = max(self.caixa.top + raio, min(y, self.caixa.bottom - raio))
        self.bolhas.append({"x": x, "y": y, "t": 0.0})

    def _estourar(self, bolha):
        raio = self.dados["raio"]
        self.estouros.append({"area": pygame.Rect(bolha["x"] - raio, bolha["y"] - raio, 2 * raio, 2 * raio), "t": self.dados["tempo_do_estouro"]})
        quantos = self.dados["pedacos"]
        for numero in range(quantos):
            angulo = numero * math.tau / quantos + self.sorte.random()
            velocidade = self.dados["velocidade_dos_pedacos"]
            self.itens.append({"x": float(bolha["x"]), "y": float(bolha["y"]), "l": 6, "a": 6, "vx": math.cos(angulo) * velocidade, "vy": math.sin(angulo) * velocidade})

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proxima -= dt
        if self.proxima <= 0 and self.restantes > 0:
            self.restantes -= 1
            self.proxima += self.dados["intervalo"]
            self._criar_bolha()
        for bolha in list(self.bolhas):
            bolha["t"] += dt
            if bolha["t"] >= self.dados["aviso"]:
                self.bolhas.remove(bolha)
                self._estourar(bolha)
        for estouro in self.estouros:
            estouro["t"] -= dt
        self.estouros = [e for e in self.estouros if e["t"] > 0]
        self._mover_itens(dt)
        self.itens = [i for i in self.itens if self.caixa.colliderect(self._retangulo(i))]

    def terminou(self):
        return self.restantes <= 0 and not self.bolhas and not self.itens and not self.estouros

    def perigos(self):
        return super().perigos() + [e["area"] for e in self.estouros]

    def desenhar(self, tela):
        for bolha in self.bolhas:
            raio = max(2, int(self.dados["raio"] * bolha["t"] / self.dados["aviso"]))
            pygame.draw.circle(tela, cor("vitrine.rosa"), (bolha["x"], bolha["y"]), raio, 1)
            pygame.draw.circle(tela, cor("vitrine.rosa"), (bolha["x"], bolha["y"]), self.dados["raio"], 1) if int(bolha["t"] * 12) % 2 == 0 else None
        for estouro in self.estouros:
            pygame.draw.rect(tela, cor("vitrine.rosa"), estouro["area"])
        for item in self.itens:
            pygame.draw.rect(tela, cor("eco.magenta"), self._retangulo(item))


class Corrente(Padrao):
    """Uma corrente de mensagens atravessa a caixa, sempre pelo mesmo caminho, que aparece antes. É só ler onde ela passa baixo."""

    LADO = 8

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["passes"]
        self.sentido = 1
        self.elos = self.dados["elos"]
        self._preparar()

    def receber_luta(self, luta):
        super().receber_luta(luta)
        self.elos = self.dados["elos"] + self.intensidade

    def _preparar(self):
        self.fase = "aviso"
        self.tempo_fase = 0.0
        self.onda = self.sorte.random() * math.tau
        self.cabeca = float(self.caixa.left if self.sentido > 0 else self.caixa.right)

    def _y(self, x):
        fracao = (x - self.caixa.left) / self.caixa.width
        return self.caixa.bottom - self.dados["altura_base"] - math.sin(fracao * math.tau + self.onda) * self.dados["amplitude"]

    def _posicoes(self):
        for numero in range(self.elos):
            x = self.cabeca - self.sentido * numero * self.dados["espaco"]
            if self.caixa.left - self.LADO <= x <= self.caixa.right:
                yield x, self._y(x)

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        if self.fase == "aviso":
            if self.tempo_fase >= self.dados["aviso"]:
                self.fase = "passando"
            return
        if self.fase == "fim":
            return
        self.cabeca += self.sentido * self.dados["velocidade"] * dt
        cauda = self.cabeca - self.sentido * self.elos * self.dados["espaco"]
        if (self.sentido > 0 and cauda > self.caixa.right) or (self.sentido < 0 and cauda < self.caixa.left):
            self.restantes -= 1
            self.sentido = -self.sentido
            if self.restantes > 0:
                self._preparar()
            else:
                self.fase = "fim"

    def terminou(self):
        return self.fase == "fim"

    def perigos(self):
        if self.fase != "passando":
            return []
        return [pygame.Rect(int(x) - self.LADO // 2, int(y) - self.LADO // 2, self.LADO, self.LADO) for x, y in self._posicoes()]

    def desenhar(self, tela):
        if self.fase == "aviso" and int(self.tempo_fase * 10) % 2 == 0:
            for x in range(self.caixa.left, self.caixa.right, 7):
                pygame.draw.rect(tela, cor("vitrine.rosa"), (x, int(self._y(x)) - 1, 3, 2))
        for r in self.perigos():
            pygame.draw.rect(tela, cor("eco.magenta"), r)
            pygame.draw.rect(tela, cor("neutros.branco"), r.inflate(-4, -4))


class Comentarios(ComItens):
    """Balões de comentário caem balançando e quicam uma vez no chão, como uma resposta atravessada."""

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.proximo = 0.1

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proximo -= dt
        intervalo = self.dados["intervalo"] * (1 - self.intensidade * self.dados["reducao_por_nivel"])
        if self.proximo <= 0 and self.tempo < self.dados["duracao"]:
            self.proximo += intervalo
            x = self.alvo[0] if self.alvo else self.sorte.randint(self.caixa.left + 8, self.caixa.right - 20)
            self._agendar(x=float(x), base_x=float(x), y=float(self.caixa.top - 10), l=12, a=9,
                          vy=self.dados["velocidade"], t=self.sorte.random() * 6, quicou=False)
        for item in self.itens:
            if item["aviso"] > 0:
                item["aviso"] -= dt
                continue
            item["t"] += dt
            item["x"] = max(self.caixa.left, min(item["base_x"] + math.sin(item["t"] * 3) * 7, self.caixa.right - 12))
            item["y"] += item["vy"] * dt
            if item["y"] + 9 >= self.caixa.bottom and not item["quicou"]:
                item["quicou"] = True
                item["vy"] = -item["vy"] * 0.45
            elif item["quicou"]:
                item["vy"] += 170 * dt
        self.itens = [i for i in self.itens if not (i["quicou"] and i["y"] > self.caixa.bottom)]

    def terminou(self):
        return self.tempo >= self.dados["duracao"] and not self.itens

    def desenhar(self, tela):
        for item in self.itens:
            r = self._retangulo(item)
            pygame.draw.rect(tela, cor("neutros.gelo"), r, border_radius=2)
            pygame.draw.rect(tela, cor("eco.roxo"), (r.left + 2, r.top + 3, 8, 1))
            pygame.draw.rect(tela, cor("neutros.gelo"), (r.left + 2, r.bottom, 3, 2))


class AoVivo(Padrao):
    """Um holofote persegue a mini Ada e o outro patrulha. Dá para fugir ou pular por cima da luz no chão."""

    depende_do_jogador = True

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.perseguidor = float(caixa.left + 18)
        self.patrulha = float(caixa.right - 18)

    def atualizar(self, dt):
        super().atualizar(dt)
        destino = (self.alvo or self.jogador or self.caixa.center)[0]
        passo = self.dados["velocidade"] * dt
        self.perseguidor += max(-passo, min(destino - self.perseguidor, passo))
        amplitude = self.caixa.width / 2 - 12
        self.patrulha = self.caixa.centerx + math.cos(self.tempo * self.dados["ritmo_da_patrulha"]) * amplitude

    def perigos(self):
        # Antes de começar a machucar, os holofotes só se posicionam.
        if self.tempo < self.dados["aquecimento"]:
            return []
        altura = self.dados["altura_da_luz"]
        return [pygame.Rect(int(x) - 7, self.caixa.bottom - altura, 14, altura) for x in (self.perseguidor, self.patrulha)]

    def desenhar(self, tela):
        camada = pygame.Surface(self.caixa.size, pygame.SRCALPHA)
        altura = self.dados["altura_da_luz"]
        aceso = self.tempo >= self.dados["aquecimento"]
        for x in (self.perseguidor, self.patrulha):
            esquerda = int(x) - 7 - self.caixa.left
            pygame.draw.rect(camada, (247, 210, 122, 45), (esquerda, 0, 14, self.caixa.height))
            if aceso:
                pygame.draw.rect(camada, (247, 210, 122, 170), (esquerda, self.caixa.height - altura, 14, altura))
        tela.blit(camada, self.caixa.topleft)


class Deepfake(Padrao):
    """Cópias falsas refazem o caminho da mini Ada, com atraso e até os pulos: quem para é pega (D63).

    Começa com 1 clone. Repetir o ataque soma clones (D66), e cada um vem mais atrás. Ao chegar à parede, é preciso
    voltar e pular por cima deles. Um deepfake é feito com os seus próprios dados.
    """

    depende_do_jogador = True

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.historico = []
        self.indices = [0] * self.dados["copias"]

    def atualizar(self, dt):
        super().atualizar(dt)
        if self.jogador:
            self.historico.append((self.tempo, self.jogador))

    def _posicao(self, numero, atraso):
        """Onde a mini Ada estava há "atraso" segundos."""
        alvo = self.tempo - atraso
        if alvo < 0 or not self.historico:
            return None
        indice = self.indices[numero]
        while indice + 1 < len(self.historico) and self.historico[indice + 1][0] <= alvo:
            indice += 1
        self.indices[numero] = indice
        return self.historico[indice][1]

    def _copias(self):
        """Os clones em cena: (posição, se já machuca). Cada um pisca antes de começar a machucar."""
        lista = []
        for numero in range(self.dados["copias"]):
            atraso = self.dados["atraso"] * (numero + 1)
            entrada = self.dados["entrada"] * numero
            if self.tempo < entrada:
                continue
            posicao = self._posicao(numero, atraso)
            if posicao:
                lista.append((posicao, self.tempo >= entrada + self.dados["aquecimento"]))
        return lista

    def terminou(self):
        return self.tempo >= self.dados["duracao"]

    def perigos(self):
        return [pygame.Rect(x - 4, y - 6, 8, 12) for (x, y), machuca in self._copias() if machuca]

    def desenhar(self, tela):
        imagem = carregar_imagem("assets/sprites/ada/mini_ada_parada.png").copy()
        imagem.fill((255, 90, 170, 255), special_flags=pygame.BLEND_RGBA_MULT)
        for (x, y), machuca in self._copias():
            if machuca or int(self.tempo * 12) % 2:
                tela.blit(imagem, (x - 5, y - 8))


# ---------- Exo-Desligador: Dante ----------
class PulsoDeDesligamento(ComItens):
    """Ondas de choque saem do meio pelo chão, para os dois lados. Algumas são mais altas."""

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["pulsos"]
        self.proximo = self.dados["aviso"]
        self.aviso = self.dados["aviso"]

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proximo -= dt
        self.aviso = self.proximo
        if self.proximo <= 0 and self.restantes > 0:
            altura = self.dados["altura_alta"] if self.restantes % 2 == 0 else self.dados["altura_baixa"]
            self.restantes -= 1
            self.proximo += self.dados["intervalo"]
            for sentido in (-1, 1):
                self.itens.append({"x": float(self.caixa.centerx - 5), "y": self.caixa.bottom - altura, "l": 10, "a": altura,
                                   "vx": sentido * self.dados["velocidade"]})
        self._mover_itens(dt)

    def terminou(self):
        return self.restantes <= 0 and not self.itens

    def desenhar(self, tela):
        if self.restantes > 0 and self.proximo < self.dados["aviso"]:
            _aviso_no_chao(tela, self.caixa, self.caixa.centerx - 8, 16, self.proximo, "vila.sol")
        for item in self.itens:
            r = self._retangulo(item)
            pygame.draw.rect(tela, cor("vila.laranja_forte"), r)
            pygame.draw.rect(tela, cor("vila.sol"), r.inflate(-4, 0))


class Garras(ComItens):
    """Os braços do exo caem em sequência, cada um com a sombra avisando. Depois ficam um instante no chão."""

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["garras"]
        self.proximo = 0.1
        self.garras = []
        self.lado = 1
        self.x_atual = caixa.left + 8

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proximo -= dt
        largura = self.dados["largura"]
        if self.proximo <= 0 and self.restantes > 0:
            self.restantes -= 1
            self.proximo += self.dados["intervalo"]
            x = self.x_atual if not self.alvo else self.alvo[0] - largura // 2
            x = max(self.caixa.left, min(x, self.caixa.right - largura))
            self.garras.append({"x": x, "y": float(self.caixa.top - 30), "t": 0.0, "fase": "aviso"})
            self.x_atual += self.lado * self.dados["passo"]
            if self.x_atual + largura > self.caixa.right or self.x_atual < self.caixa.left:
                self.lado = -self.lado
                self.x_atual += 2 * self.lado * self.dados["passo"]
        for garra in self.garras:
            garra["t"] += dt
            if garra["fase"] == "aviso" and garra["t"] >= self.dados["aviso"]:
                garra["fase"], garra["t"] = "caindo", 0.0
            elif garra["fase"] == "caindo":
                garra["y"] += self.dados["velocidade"] * dt
                if garra["y"] + 30 >= self.caixa.bottom:
                    garra["y"] = float(self.caixa.bottom - 30)
                    garra["fase"], garra["t"] = "no_chao", 0.0
            elif garra["fase"] == "no_chao" and garra["t"] >= self.dados["tempo_no_chao"]:
                garra["fase"] = "fim"
        self.garras = [g for g in self.garras if g["fase"] != "fim"]

    def terminou(self):
        return self.restantes <= 0 and not self.garras

    def perigos(self):
        return [pygame.Rect(g["x"], int(g["y"]), self.dados["largura"], 30) for g in self.garras if g["fase"] != "aviso"]

    def desenhar(self, tela):
        largura = self.dados["largura"]
        for garra in self.garras:
            if garra["fase"] == "aviso":
                _aviso_no_chao(tela, self.caixa, garra["x"], largura, garra["t"])
            else:
                x, y = garra["x"], int(garra["y"])
                pygame.draw.rect(tela, cor("neutros.chumbo"), (x, y, largura, 18))
                for dente in range(0, largura, 8):
                    pygame.draw.rect(tela, cor("vila.laranja"), (x + dente, y + 18, 5, 12))


class CorteGeral(ComItens):
    """A luz apaga, mas o projétil grande brilha: alto ou baixo, o aviso mostra a faixa inteira."""

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["cortes"]
        self._preparar()

    def _preparar(self):
        self.baixo = self.sorte.random() < 0.5
        self.fase = "aviso"
        self.tempo_fase = 0.0

    def _faixa(self):
        if self.baixo:
            return self.caixa.bottom - self.dados["altura_baixa"], self.dados["altura_baixa"]
        return self.caixa.bottom - 17 - self.dados["altura_alta"], self.dados["altura_alta"]

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        if self.fase == "aviso" and self.tempo_fase >= self.dados["aviso"]:
            self.fase = "escuro"
            self.tempo_fase = 0.0
            y, altura = self._faixa()
            self.itens.append({"x": float(self.caixa.left - 40), "y": y, "l": 40, "a": altura, "vx": self.dados["velocidade"]})
        elif self.fase == "escuro" and not self.itens:
            self.restantes -= 1
            if self.restantes > 0:
                self._preparar()
            else:
                self.fase = "fim"
        self._mover_itens(dt)

    def terminou(self):
        return self.fase == "fim"

    def desenhar(self, tela):
        if self.fase == "escuro" and self.tempo_fase < self.dados["tempo_de_escuro"]:
            escuro = pygame.Surface(self.caixa.size, pygame.SRCALPHA)
            escuro.fill((13, 11, 20, 200))
            tela.blit(escuro, self.caixa.topleft)
        if self.fase == "aviso" and int(self.tempo_fase * 10) % 2 == 0:
            y, altura = self._faixa()
            pygame.draw.rect(tela, cor("vitrine.rosa"), (self.caixa.left, y, self.caixa.width, altura), 1)
        for item in self.itens:
            r = self._retangulo(item)
            pygame.draw.rect(tela, cor("vila.laranja_forte"), r, border_radius=4)
            pygame.draw.rect(tela, cor("vila.sol"), r.inflate(-10, -4), border_radius=3)


class VentoDoHeliponto(ComItens):
    """O vento empurra para as bordas, que machucam, e traz destroços. É preciso andar contra ele."""

    BORDA = 8

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.proximo = 0.3

    def empurrao(self):
        return math.sin(self.tempo * self.dados["ritmo"]) * self.dados["forca"]

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proximo -= dt
        if self.proximo <= 0 and self.tempo < self.dados["duracao"]:
            self.proximo += self.dados["intervalo"]
            sentido = 1 if self.empurrao() >= 0 else -1
            x = self.caixa.left - 8 if sentido > 0 else self.caixa.right
            y = self.sorte.choice((self.caixa.bottom - 40, self.caixa.bottom - 9))
            self._agendar(x=float(x), y=y, l=8, a=7, vx=sentido * self.dados["velocidade"])
        self._mover_itens(dt)

    def terminou(self):
        return self.tempo >= self.dados["duracao"] and not self.itens

    def perigos(self):
        lista = super().perigos()
        lista.append(pygame.Rect(self.caixa.left, self.caixa.top, self.BORDA, self.caixa.height))
        lista.append(pygame.Rect(self.caixa.right - self.BORDA, self.caixa.top, self.BORDA, self.caixa.height))
        return lista

    def desenhar(self, tela):
        c = self.caixa
        pygame.draw.rect(tela, cor("vermelho.vermelho"), (c.left, c.top, self.BORDA, c.height))
        pygame.draw.rect(tela, cor("vermelho.vermelho"), (c.right - self.BORDA, c.top, self.BORDA, c.height))
        sentido = 1 if self.empurrao() >= 0 else -1
        for y in range(c.top + 8, c.bottom - 8, 16):
            x = c.centerx + int((self.tempo * 90 * sentido + y * 3) % 90) - 45
            pygame.draw.line(tela, cor("ceu.nuvem"), (x, y), (x + 10 * sentido, y))
        for item in self.itens:
            pygame.draw.rect(tela, cor("neutros.cinza_claro"), self._retangulo(item))


class Alicate(Padrao):
    """As pontas de um alicate gigante fecham numa faixa da caixa. É preciso sair daquela altura."""

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.ordem = list(self.dados["faixas"])
        self.fase = "aviso"
        self.tempo_fase = 0.0

    def _faixa(self):
        c = self.caixa
        if self.ordem[0] == "baixa":
            return c.bottom - 12, 12
        return c.bottom - 42, 22

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        if self.fase == "aviso" and self.tempo_fase >= self.dados["aviso"]:
            self.fase, self.tempo_fase = "fechando", 0.0
        elif self.fase == "fechando" and self.tempo_fase >= self.dados["fechar"]:
            self.fase, self.tempo_fase = "abrindo", 0.0
        elif self.fase == "abrindo" and self.tempo_fase >= self.dados["fechar"] / 2:
            self.ordem.pop(0)
            self.tempo_fase = 0.0
            self.fase = "aviso" if self.ordem else "fim"

    def terminou(self):
        return self.fase == "fim"

    def _lamina(self):
        if self.fase == "fechando":
            return min(1.0, self.tempo_fase / self.dados["fechar"])
        if self.fase == "abrindo":
            return max(0.0, 1 - self.tempo_fase / (self.dados["fechar"] / 2))
        return 0.0

    def perigos(self):
        if self.fase not in ("fechando", "abrindo"):
            return []
        y, altura = self._faixa()
        alcance = int(self._lamina() * self.caixa.width / 2)
        if alcance <= 0:
            return []
        return [pygame.Rect(self.caixa.left, y, alcance, altura), pygame.Rect(self.caixa.right - alcance, y, alcance, altura)]

    def desenhar(self, tela):
        if self.fase == "fim":
            return
        if self.fase == "aviso" and int(self.tempo_fase * 10) % 2 == 0:
            y, altura = self._faixa()
            pygame.draw.rect(tela, cor("vitrine.rosa"), (self.caixa.left, y, 10, altura), 1)
            pygame.draw.rect(tela, cor("vitrine.rosa"), (self.caixa.right - 10, y, 10, altura), 1)
        for r in self.perigos():
            pygame.draw.rect(tela, cor("neutros.cinza"), r)
            pygame.draw.line(tela, cor("neutros.gelo"), r.topleft, r.topright)


PADROES_DOS_CHEFES = {
    "peneira": Peneira,
    "carimbo_negado": CarimboNegado,
    "rotulos": Rotulos,
    "balanca_pendente": BalancaPendente,
    "ciclo": Ciclo,
    "varredura": Varredura,
    "pop_ups": PopUps,
    "previsao": Previsao,
    "vazamento": Vazamento,
    "rede_de_cabos": RedeDeCabos,
    "bolha_de_filtro": BolhaDeFiltro,
    "corrente": Corrente,
    "comentarios": Comentarios,
    "ao_vivo": AoVivo,
    "deepfake": Deepfake,
    "pulso_de_desligamento": PulsoDeDesligamento,
    "garras": Garras,
    "corte_geral": CorteGeral,
    "vento_do_heliponto": VentoDoHeliponto,
    "alicate": Alicate,
}

# A ÍRIS e os ataques supremos ficam em arquivos próprios. Eles usam as classes daqui, por isso entram no fim.
from src.batalha.padroes_iris import ATAQUES_DA_IRIS  # noqa: E402
from src.batalha.padroes_iris2 import ATAQUES_COMBINADOS_DA_IRIS  # noqa: E402
from src.batalha.padroes_supremos import ATAQUES_SUPREMOS  # noqa: E402

PADROES_DOS_CHEFES.update(ATAQUES_DA_IRIS)
PADROES_DOS_CHEFES.update(ATAQUES_COMBINADOS_DA_IRIS)
PADROES_DOS_CHEFES.update(ATAQUES_SUPREMOS)
