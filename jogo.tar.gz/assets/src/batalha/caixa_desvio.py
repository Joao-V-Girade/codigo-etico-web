"""O turno do inimigo: a caixa abre, os padrões atacam e a mini Ada desvia. Ela não atira aqui."""

import math

import pygame

from src.batalha.mini_ada import MiniAda
from src.batalha.padroes import criar_padrao
from src.sistemas.cores import cor
from src.sistemas.recursos import ler_json
from src.sistemas.textos import resolver
from src.sistemas.entrada import acao_do_evento, esta_pressionada
from src.ui.barras import desenhar_barra
from src.ui.caixa_texto import desenhar_caixa

MARGEM_DA_CAIXA = 2
BASE_DA_CAIXA = 150
PASSO_MAXIMO = 0.05
TEMPO_DO_AVISO_DE_VELOCIDADE = 1.2
TEMPO_ENTRE_LEITURAS = 0.25  # A memória do chefe lê a posição 4 vezes por segundo (D49).


class CaixaDesvio:
    def __init__(self, jogo, luta, regras, nomes_dos_padroes, caixa_inicial, alvo=None, sorte=None, titulo=None):
        """titulo é o nome do ataque supremo: aparece em cima da caixa, que fica com a borda rosa."""
        self.jogo = jogo
        self.luta = luta
        self.regras = regras
        self.dados = regras["caixa"]
        self.fila = list(nomes_dos_padroes)
        self.total_de_ataques = len(self.fila)
        self.com_revisao = False  # ÍRIS: este turno tem um ataque a menos, por causa da REVISÃO.
        self.alvo = alvo
        self.sorte = sorte
        self.titulo = titulo
        self.pressionada = esta_pressionada
        self.segurava_pulo = False
        self.terminou = False
        self.levou_dano = False
        self.leitura = TEMPO_ENTRE_LEITURAS
        self.textos = ler_json("data/interface.json")["batalha"]
        self.primeiro_padrao = True
        self.padrao = None
        self.tempo_recusando = 0.0
        self.recarga_do_recusar = 0.0
        # Um ataque supremo machuca muito, mas nunca derrota sozinho quem está com a vida cheia (D63).
        limite = luta.limite_do_supremo(regras["caixa"]["limite_do_supremo"])
        self.dano_restante = math.ceil(luta.vida_maxima * limite) if titulo else None
        self.nivel = 0
        self.origem = pygame.Rect(caixa_inicial)
        self.retangulo = pygame.Rect(caixa_inicial)
        self.destino = pygame.Rect(caixa_inicial)
        self.mini_ada = None
        self.fase = "abrindo"
        self.tempo = 0.0
        self._mirar_no_proximo_padrao()

    def _mirar_no_proximo_padrao(self):
        largura, altura = self.regras["padroes"][self.fila[0]]["caixa"]
        self.origem = pygame.Rect(self.retangulo)
        if self.tela_cheia:
            self.destino = pygame.Rect((320 - largura) // 2, (180 - altura) // 2, largura, altura)
        else:
            self.destino = pygame.Rect((320 - largura) // 2, BASE_DA_CAIXA - altura, largura, altura)
        self.fase = "abrindo"
        self.tempo = 0.0

    @property
    def tela_cheia(self):
        """O maior ataque da ÍRIS ocupa a tela inteira: menu e barras somem."""
        return bool(self.fila) and self.regras["padroes"][self.fila[0]].get("tela_cheia", False)

    @property
    def interior(self):
        return self.retangulo.inflate(-2 * MARGEM_DA_CAIXA, -2 * MARGEM_DA_CAIXA)

    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        if acao == "confirmar" and self.mini_ada:
            self.mini_ada.corpo.pedir_pulo()
        elif acao == "cancelar" and self.padrao:
            if self.titulo:
                self.padrao.apertar_especial()
            else:
                self._recusar()

    def _recusar(self):
        """ÍRIS, segunda forma: um arranque curto em que nada atinge a mini Ada, pago com AUTONOMIA."""
        if self.recarga_do_recusar > 0 or not self.luta.pode_recusar() or self.mini_ada is None:
            return
        mecanica = self.luta.mecanica
        self.luta.recusar()
        self.tempo_recusando = mecanica["tempo_do_recusar"]
        self.recarga_do_recusar = mecanica["recarga_do_recusar"]
        self.mini_ada.invencivel = max(self.mini_ada.invencivel, mecanica["tempo_do_recusar"])

    def _interpolar(self, fracao):
        def meio(a, b):
            return int(a + (b - a) * fracao)

        self.retangulo = pygame.Rect(
            meio(self.origem.x, self.destino.x),
            meio(self.origem.y, self.destino.y),
            meio(self.origem.w, self.destino.w),
            meio(self.origem.h, self.destino.h),
        )

    def atualizar(self, dt):
        dt = min(dt, PASSO_MAXIMO)
        self.tempo += dt
        self.tempo_recusando = max(0.0, self.tempo_recusando - dt)
        self.recarga_do_recusar = max(0.0, self.recarga_do_recusar - dt)
        if self.fase == "abrindo":
            self._interpolar(min(1.0, self.tempo / self.dados["abrir"]))
            self._mover_mini_ada(dt)
            if self.tempo >= self.dados["abrir"]:
                self._comecar_padrao()
        elif self.fase == "atacando":
            # A partir do 5º turno, o ataque corre mais rápido. A mini Ada continua na mesma velocidade.
            # O ataque supremo não acelera: ele fica difícil pelo que exige, não pela pressa (D63).
            self.padrao.segurar_especial(self.pressionada("cancelar"))
            self.padrao.atualizar(dt * (1.0 if self.titulo else self.luta.fator_de_velocidade))
            self._mover_mini_ada(dt)
            self._checar_dano()
            self._ler_posicao(dt)
            if self.luta.derrotada:
                self.terminou = True
            elif self.padrao.terminou():
                self.padrao = None
                self.primeiro_padrao = False
                self.fila.pop(0)
                self.fase = "entre_padroes" if self.fila else "fechando"
                self.tempo = 0.0
        elif self.fase == "entre_padroes":
            self._mover_mini_ada(dt)
            if self.tempo >= self.luta.pausa_entre_ataques(self.dados["pausa_entre_padroes"]):
                self._mirar_no_proximo_padrao()
        elif self.fase == "fechando":
            if self.tempo >= self.dados["fechar"]:
                self.terminou = True

    def _comecar_padrao(self):
        self.retangulo = pygame.Rect(self.destino)
        if self.mini_ada is None:
            self.mini_ada = MiniAda(self.interior.centerx - 4, self.interior.bottom - 15, self.regras["caixa"]["fisica"])
        self.nivel = self.luta.registrar_ataque(self.fila[0])
        self.padrao = criar_padrao(self.fila[0], self.regras, self.sorte, self.nivel, self.luta.forma)
        self.padrao.fonte = self.jogo.fonte
        self.padrao.fator = 1.0 if self.titulo else self.luta.fator_de_velocidade
        interior = self.interior
        # O ataque supremo não usa memória: ele é sempre igual, para o jogador aprender a escapar.
        alvo = self.alvo
        if alvo is None and not self.titulo:
            alvo = self.luta.alvo_guiado(self.fila[0], (interior.x, interior.y, interior.w, interior.h))
        self.guiado = alvo is not None
        self.padrao.iniciar(interior, alvo)
        self.padrao.receber_luta(self.luta)
        self.padrao.ver_jogador(self.mini_ada.area_de_dano.center)
        self.fase = "atacando"
        self.tempo = 0.0

    def _mover_mini_ada(self, dt):
        if self.mini_ada is None:
            return
        direcao = 0
        if self.pressionada("esquerda"):
            direcao -= 1
        if self.pressionada("direita"):
            direcao += 1
        segura = self.pressionada("confirmar")
        if self.segurava_pulo and not segura:
            self.mini_ada.corpo.soltar_pulo()
        self.segurava_pulo = segura
        plataformas = self.padrao.plataformas() if self.padrao else ()
        limites = self.padrao.limites(self.interior) if self.padrao else self.interior
        lentidao = (self.padrao.lentidao() if self.padrao else 1.0) * self.luta.multiplicador_da_velocidade
        if self.tempo_recusando > 0:
            lentidao *= self.luta.mecanica["arranque_do_recusar"]
            direcao = direcao or (-1 if self.mini_ada.olhando_esquerda else 1)
        self.mini_ada.corpo.invertida = self.padrao.gravidade_invertida() if self.padrao else False
        if self.padrao and self.padrao.modo_voo():
            vertical = (1 if self.pressionada("baixo") else 0) - (1 if self.pressionada("cima") else 0)
            self.mini_ada.voar(dt, direcao, vertical, limites, self.padrao)
            self.padrao.ver_jogador(self.mini_ada.area_de_dano.center)
            return
        self.mini_ada.corpo.forca_do_pulo = self.dados["fisica"]["pulo"] * self.luta.multiplicador_do_pulo
        self.mini_ada.atualizar(dt, direcao, limites, plataformas, lentidao)
        if self.padrao:
            corpo = self.mini_ada.corpo
            corpo.x += self.padrao.empurrao() * dt
            self.padrao.carregar_corpo(corpo, dt, plataformas)
            # ÍRIS: com a AUTONOMIA baixa, um fio puxa a mini Ada para o meio.
            puxao = 0 if self.padrao.sem_puxao() else self.luta.puxao_da_autonomia()
            if puxao:
                corpo.x += (1 if self.interior.centerx > corpo.x else -1) * puxao * dt
            corpo.x = max(limites.left, min(corpo.x, limites.right - corpo.largura))
            self.padrao.ver_jogador(self.mini_ada.area_de_dano.center)

    def _ler_posicao(self, dt):
        """Conta em qual terço da caixa a mini Ada está. Só chefes têm memória."""
        memoria = self.luta.memoria
        if memoria is None:
            return
        self.leitura -= dt
        if self.leitura <= 0:
            self.leitura += TEMPO_ENTRE_LEITURAS
            fracao = (self.mini_ada.corpo.retangulo.centerx - self.interior.left) / self.interior.width
            memoria.observar("terco", min(2, max(0, int(fracao * 3))))

    def _checar_dano(self):
        if self.mini_ada.invencivel > 0:
            return
        area = self.mini_ada.area_de_dano
        if any(area.colliderect(perigo) for perigo in self.padrao.perigos()):
            if self.padrao.absorve_o_golpe():
                self.mini_ada.invencivel = self.dados["invencivel"]
                return
            dano = self.padrao.dano
            if self.dano_restante is not None:
                dano = min(dano, self.dano_restante)
                self.dano_restante -= dano
            self.luta.ferir_ada(dano)
            self.padrao.ao_atingir()
            if self.padrao.cola_rotulo:
                self.luta.colar_rotulo()
            self.mini_ada.invencivel = self.dados["invencivel"]
            self.levou_dano = True

    def _desenhar_aviso_de_velocidade(self, tela):
        """Mostra o nome do ataque supremo ou, no comecinho do turno, que os ataques aceleraram."""
        if self.titulo:
            fonte = self.jogo.fonte
            titulo = resolver(self.titulo)
            largura = fonte.largura(titulo)
            x, y = (320 - largura) // 2, self.retangulo.top + 2 if self.tela_cheia else self.retangulo.top - 13
            # Uma tarja escura deixa o nome legível na frente do chefe.
            pygame.draw.rect(tela, cor("neutros.tinta"), (x - 4, y + 1, largura + 8, 12))
            pygame.draw.rect(tela, cor("vitrine.rosa"), (x - 4, y + 1, largura + 8, 12), 1)
            fonte.desenhar(tela, x, y, titulo, cor("vitrine.rosa_claro"), cor("neutros.tinta"))
            self._desenhar_dica(tela, y)
            return
        aceleracao = self.regras["aceleracao"]
        acelerando = self.luta.turno >= aceleracao["a_partir_do_turno"] and self.luta.fator_de_velocidade > 1
        if acelerando and self.primeiro_padrao and self.fase == "atacando" and self.tempo < TEMPO_DO_AVISO_DE_VELOCIDADE:
            percentual = round((self.luta.fator_de_velocidade - 1) * 100)
            texto = f"{self.textos['mais_rapido']} +{percentual}%"
            fonte = self.jogo.fonte
            fonte.desenhar(tela, (320 - fonte.largura(texto)) // 2, self.retangulo.top - 13, texto, cor("vitrine.rosa"), cor("neutros.tinta"))

    def _desenhar_vida(self, tela):
        """Sem o menu, a vida fica dentro da caixa, para o jogador não perder essa informação."""
        fonte = self.jogo.fonte
        y = self.retangulo.bottom - 14
        fonte.desenhar(tela, self.retangulo.left + 4, y, self.textos["vida"], fonte.cores["texto"], cor("neutros.tinta"))
        fracao = self.luta.vida / self.luta.vida_maxima
        desenhar_barra(tela, (self.retangulo.left + 34, y + 4, 60, 5), fracao, cor("verde.limao"))

    def _desenhar_dica(self, tela, y_do_titulo):
        """O controle novo do ataque supremo fica escrito na tela: ninguém precisa descobrir apanhando."""
        dica = self.padrao.dados.get("dica") if self.padrao else None
        if not dica:
            return
        fonte = self.jogo.fonte
        texto = resolver(dica)
        largura = fonte.largura(texto)
        x, y = (320 - largura) // 2, y_do_titulo + 13 if self.tela_cheia else y_do_titulo - 13
        pygame.draw.rect(tela, cor("neutros.tinta"), (x - 3, y + 1, largura + 6, 12))
        fonte.desenhar(tela, x, y, texto, cor("verde.limao"), cor("neutros.tinta"))

    def _desenhar_contador(self, tela):
        """ÍRIS, segunda forma: mostra qual ataque é este e se a REVISÃO tirou um deles."""
        if self.titulo or self.luta.forma != 2 or not self.fila:
            return
        fonte = self.jogo.fonte
        atual = self.total_de_ataques - len(self.fila) + 1
        texto = f"{self.textos['ataque']} {atual}/{self.total_de_ataques}"
        if self.com_revisao:
            texto += f" {self.textos['com_revisao']}"
        fonte.desenhar(tela, self.retangulo.left, self.retangulo.top - 13, texto, cor("neutros.gelo"), cor("neutros.tinta"))

    def _desenhar_recusar(self, tela):
        """O controle novo da segunda forma fica escrito na tela, e some quando não pode ser usado."""
        if self.titulo or not self.luta.pode_recusar() or self.recarga_do_recusar > 0:
            return
        fonte = self.jogo.fonte
        texto = self.textos["recusar"]
        fonte.desenhar(tela, self.retangulo.right - fonte.largura(texto), self.retangulo.top - 13, texto, cor("vila.sol"), cor("neutros.tinta"))

    def desenhar(self, tela):
        cores = self.jogo.fonte.cores
        borda = cor("vitrine.rosa") if self.titulo else cores["borda_caixa"]
        desenhar_caixa(tela, self.retangulo, borda, cores["fundo_caixa"], MARGEM_DA_CAIXA)
        recorte_antes = tela.get_clip()
        tela.set_clip(self.interior)
        if self.padrao:
            self.padrao.desenhar_avisos(tela)
            self.padrao.desenhar(tela)
        if self.mini_ada:
            self.mini_ada.desenhar(tela)
        if self.padrao:
            self.padrao.desenhar_por_cima(tela)
        tela.set_clip(recorte_antes)
        self._desenhar_aviso_de_velocidade(tela)
        self._desenhar_contador(tela)
        self._desenhar_recusar(tela)
        if self.tela_cheia:
            self._desenhar_vida(tela)
