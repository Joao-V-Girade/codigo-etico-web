"""Os padrões de ataque na caixa de desvio. Cada padrão é uma classe com iniciar, atualizar e terminou.

Cada estilo pede uma reação diferente do jogador (05, seção 5):
- Chão: NuvemDePoeira, Varrida. É preciso pular.
- Céu: LixoCaindo, ChuvaDeBlocos. É preciso andar até um lugar seguro.
- Mira: RajadaMirada. O tiro vai onde o jogador estava, então é preciso não ficar parado.
- Zonas: Lasers. É preciso ler o aviso e decidir: sair da coluna, pular ou ficar no chão.
- Paredes: ParedesComVao. É preciso subir na plataforma ou ficar embaixo, conforme o vão.
- Órbita: Orbita. É preciso achar a brecha nos anéis de drones que se abrem.

iniciar() já recebe um alvo opcional, um ponto (x, y) na caixa, para a memória dos chefes entrar na
FP5 sem mudar nada aqui (D49). Sem alvo, o padrão ataca do jeito normal. O ZIM nunca usa alvo: ele
segue uma regra fixa (D50).
"""

import math
import random

import pygame

from src.sistemas.cores import cor
from src.sistemas.recursos import carregar_imagem

QUADROS_POR_SEGUNDO = 8


class Padrao:
    depende_do_jogador = False  # True quando o ataque reage à posição da mini Ada.
    cola_rotulo = False  # True quando o acerto cola um rótulo RISCO na Ada (CRIVO, D63).
    precisa_do_especial = False  # True quando a saída passa pelo controle novo do ataque supremo.

    def __init__(self, dados, sorte=None):
        self.dados = dados
        self.dano = dados["dano"]
        self.sorte = sorte or random.Random()
        self.caixa = None
        self.alvo = None
        self.jogador = None
        self.fonte = None  # A caixa entrega a fonte aos ataques que escrevem na tela.
        self.tempo = 0.0
        self.intensidade = 0  # ECO: quanto maior o Engajamento, mais objetos no ataque (D63).
        self.fator = 1.0  # A velocidade do turno, para o ataque calcular quanto tempo o jogador tem de verdade.

    def iniciar(self, caixa, alvo=None):
        self.caixa = caixa
        self.alvo = alvo
        self.tempo = 0.0

    def ver_jogador(self, posicao):
        """A caixa conta onde a mini Ada está agora. Só os ataques que miram usam isso."""
        self.jogador = posicao

    def plataformas(self):
        """Retângulos onde a mini Ada pode pisar enquanto este padrão durar."""
        return []

    def limites(self, interior):
        """O espaço onde a mini Ada pode andar. A Peneira usa só metade da caixa."""
        return interior

    def empurrao(self):
        """Força lateral sobre a mini Ada, em pixels por segundo: vento ou chão inclinado."""
        return 0.0

    def lentidao(self):
        """Multiplica a velocidade da mini Ada. Abaixo de 1, ela anda mais devagar."""
        return 1.0

    def gravidade_invertida(self):
        """True quando a mini Ada cai para o teto (ÍRIS, Removendo Limites)."""
        return False

    def carregar_corpo(self, corpo, dt, plataformas):
        """Leva a mini Ada junto com o que se move debaixo dela (ÍRIS, Câmara em Órbita)."""

    def sem_puxao(self):
        """True enquanto o puxão da AUTONOMIA seria injusto, como quando andar é proibido."""
        return False

    def absorve_o_golpe(self):
        """True quando algo bloqueia este golpe no lugar da mini Ada (ÍRIS, Decisão Final)."""
        return False

    def ao_atingir(self):
        """Chamada quando o ataque acerta a mini Ada."""

    def receber_luta(self, luta):
        """A caixa entrega a luta antes de começar: alguns ataques mudam conforme a mecânica do chefe."""
        self.intensidade = luta.engajamento

    def apertar_especial(self):
        """Tecla X, só nos ataques supremos que dão um controle novo."""

    def segurar_especial(self, segurando):
        """Diz, a cada quadro, se o X está segurado."""

    def pode_usar_especial(self):
        return False

    def modo_voo(self):
        """True quando a mini Ada voa em vez de andar e pular (Desligamento Geral)."""
        return False

    def antecedencia(self):
        """Quanto tempo antes o ataque mostra o que vai fazer, quando isso é mais que o aviso. Serve para o robô de teste."""
        return 0.0

    def perigos_visiveis(self, centro):
        """O que o jogador consegue reconhecer como perigo. Só muda quando o ataque esconde a verdade."""
        return self.perigos()

    def desenhar_avisos(self, tela):
        """Avisos desenhados antes de tudo, como as marcas na borda da caixa."""

    def desenhar_por_cima(self, tela):
        """Desenho que fica na frente da mini Ada, como escuridão ou janelas que tapam a visão."""

    def atualizar(self, dt):
        self.tempo += dt

    def terminou(self):
        return self.tempo >= self.dados.get("duracao", 0)

    def perigos(self):
        """Os retângulos que machucam neste quadro."""
        return []

    def desenhar(self, tela):
        pass


class NuvemDePoeira(Padrao):
    """Nuvens andam devagar na horizontal. As baixas pedem um pulo. Nas altas, é só ficar no chão."""

    LARGURA = 18
    ALTURA = 12

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.nuvens = []
        self.proxima = 0.2
        self.lado = 1

    def _escolher_altura(self):
        baixa = self.caixa.bottom - self.ALTURA
        alta = self.caixa.bottom - 37
        if self.alvo is not None:
            return min((baixa, alta), key=lambda y: abs(y - self.alvo[1]))
        return self.sorte.choice((baixa, baixa, alta))

    def atualizar(self, dt):
        super().atualizar(dt)
        velocidade = self.dados["velocidade"]
        for nuvem in self.nuvens:
            nuvem["x"] += nuvem["sentido"] * velocidade * dt
        self.nuvens = [n for n in self.nuvens if self.caixa.left - self.LARGURA < n["x"] < self.caixa.right]

        self.proxima -= dt
        if self.proxima <= 0 and self.tempo < self.dados["duracao"]:
            self.proxima += self.dados["intervalo"]
            self.lado = -self.lado
            inicio = self.caixa.right - 1 if self.lado < 0 else self.caixa.left - self.LARGURA + 1
            self.nuvens.append({"x": float(inicio), "y": self._escolher_altura(), "sentido": self.lado})

    def terminou(self):
        return self.tempo >= self.dados["duracao"] and not self.nuvens

    def perigos(self):
        # A área que machuca é menor que o desenho: encostar de raspão não conta.
        return [pygame.Rect(int(n["x"]) + 3, n["y"] + 2, self.LARGURA - 6, self.ALTURA - 4) for n in self.nuvens]

    def desenhar(self, tela):
        quadro = int(self.tempo * QUADROS_POR_SEGUNDO) % 2 + 1
        imagem = carregar_imagem(f"assets/sprites/ataques/poeira_{quadro}.png")
        for nuvem in self.nuvens:
            tela.blit(imagem, (int(nuvem["x"]), nuvem["y"]))


class Varrida(Padrao):
    """A vassoura passa rente ao chão, sempre com aviso antes. É só pular."""

    LARGURA = 30
    ALTURA = 14

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["repeticoes"]
        self.sentido = 1
        # Com alvo, a vassoura vem do lado mais distante dele, para continuar dando tempo de reagir.
        if alvo is not None and alvo[0] < caixa.centerx:
            self.sentido = -1
        self._preparar_passada()

    def _preparar_passada(self):
        self.fase = "aviso"
        self.tempo_fase = 0.0
        self.x = float(self.caixa.left - self.LARGURA if self.sentido > 0 else self.caixa.right)

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        if self.fase == "aviso" and self.tempo_fase >= self.dados["aviso"]:
            self.fase = "passando"
        elif self.fase == "passando":
            self.x += self.sentido * self.dados["velocidade"] * dt
            saiu = self.x > self.caixa.right if self.sentido > 0 else self.x < self.caixa.left - self.LARGURA
            if saiu:
                self.restantes -= 1
                self.fase = "pausa"
                self.tempo_fase = 0.0
        elif self.fase == "pausa" and self.tempo_fase >= self.dados["pausa"] and self.restantes > 0:
            self._preparar_passada()

    def terminou(self):
        return self.restantes <= 0 and self.fase == "pausa"

    def perigos(self):
        if self.fase != "passando":
            return []
        return [pygame.Rect(int(self.x) + 2, self.caixa.bottom - self.ALTURA + 5, self.LARGURA - 4, self.ALTURA - 5)]

    def desenhar(self, tela):
        if self.fase == "aviso" and int(self.tempo_fase * 10) % 2 == 0:
            faixa = pygame.Rect(self.caixa.left, self.caixa.bottom - 3, self.caixa.width, 3)
            pygame.draw.rect(tela, cor("vitrine.rosa"), faixa)
            ponta_x = self.caixa.left + 4 if self.sentido > 0 else self.caixa.right - 5
            pygame.draw.polygon(
                tela,
                cor("vitrine.rosa"),
                [(ponta_x, self.caixa.bottom - 14), (ponta_x, self.caixa.bottom - 6), (ponta_x + 5 * self.sentido, self.caixa.bottom - 10)],
            )
        elif self.fase == "passando":
            quadro = int(self.tempo * QUADROS_POR_SEGUNDO * 2) % 2 + 1
            imagem = carregar_imagem(f"assets/sprites/ataques/vassoura_{quadro}.png")
            tela.blit(imagem, (int(self.x), self.caixa.bottom - self.ALTURA))


class LixoCaindo(Padrao):
    """Lixo cai do alto, com a sombra avisando onde. Pular não adianta: é preciso andar."""

    TAMANHO = 12

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.itens = []
        self.proximo = 0.1

    def _criar_item(self):
        margem = self.TAMANHO // 2 + 1
        if self.alvo is not None:
            x = self.alvo[0] + self.sorte.randint(-16, 16)
        else:
            x = self.sorte.randint(self.caixa.left + margem, self.caixa.right - margem)
        x = max(self.caixa.left + margem, min(x, self.caixa.right - margem))
        self.itens.append({"x": x, "y": float(self.caixa.top - self.TAMANHO), "aviso": self.dados["aviso"], "tipo": self.sorte.randint(1, 3)})

    def atualizar(self, dt):
        super().atualizar(dt)
        for item in self.itens:
            if item["aviso"] > 0:
                item["aviso"] -= dt
            else:
                item["y"] += self.dados["velocidade"] * dt
        self.itens = [item for item in self.itens if item["y"] < self.caixa.bottom]
        self.proximo -= dt
        if self.proximo <= 0 and self.tempo < self.dados["duracao"]:
            self.proximo += self.dados["intervalo"]
            self._criar_item()

    def terminou(self):
        return self.tempo >= self.dados["duracao"] and not self.itens

    def perigos(self):
        lado = self.TAMANHO - 4
        return [pygame.Rect(item["x"] - lado // 2, int(item["y"]) + 2, lado, lado) for item in self.itens if item["aviso"] <= 0]

    def desenhar(self, tela):
        for item in self.itens:
            largura = 12 if item["aviso"] <= 0 else 6 + int(self.tempo * 12) % 4
            pygame.draw.rect(tela, cor("neutros.chumbo"), (item["x"] - largura // 2, self.caixa.bottom - 2, largura, 2))
            if item["aviso"] <= 0:
                imagem = carregar_imagem(f"assets/sprites/ataques/lixo_{item['tipo']}.png")
                tela.blit(imagem, (item["x"] - self.TAMANHO // 2, int(item["y"])))


class ChuvaDeBlocos(Padrao):
    """Uma fileira de blocos cai com um único vão. O chão mostra onde ele vai estar."""

    ALTURA = 10

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["fileiras"]
        self.vao_x = caixa.centerx
        if alvo is not None:
            self.vao_x = caixa.right - 24 if alvo[0] < caixa.centerx else caixa.left + 24
        self._nova_fileira(primeira=True)

    def _nova_fileira(self, primeira=False):
        vao = self.dados["vao"]
        if not primeira:
            maximo = self.dados["distancia_maxima"]
            self.vao_x += self.sorte.choice((-1, 1)) * self.sorte.randint(maximo // 2, maximo)
        self.vao_x = max(self.caixa.left + vao // 2 + 2, min(self.vao_x, self.caixa.right - vao // 2 - 2))
        self.fase = "aviso"
        self.tempo_fase = 0.0
        self.y = float(self.caixa.top - self.ALTURA)

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        if self.fase == "aviso" and self.tempo_fase >= self.dados["aviso"]:
            self.fase = "caindo"
        elif self.fase == "caindo":
            self.y += self.dados["velocidade"] * dt
            if self.y >= self.caixa.bottom:
                self.restantes -= 1
                if self.restantes > 0:
                    self._nova_fileira()
                else:
                    self.fase = "fim"

    def terminou(self):
        return self.fase == "fim"

    def _blocos(self):
        metade = self.dados["vao"] // 2
        y = int(self.y)
        esquerda = pygame.Rect(self.caixa.left, y, self.vao_x - metade - self.caixa.left, self.ALTURA)
        direita = pygame.Rect(self.vao_x + metade, y, self.caixa.right - self.vao_x - metade, self.ALTURA)
        return [esquerda, direita]

    def perigos(self):
        return self._blocos() if self.fase == "caindo" else []

    def desenhar(self, tela):
        if self.fase == "fim":
            return
        metade = self.dados["vao"] // 2
        if self.fase == "aviso" or self.fase == "caindo":
            # O aviso mostra só onde é perigoso: o vão é o lugar sem marca.
            pygame.draw.rect(tela, cor("vitrine.rosa"), (self.caixa.left, self.caixa.bottom - 3, self.vao_x - metade - self.caixa.left, 3))
            pygame.draw.rect(tela, cor("vitrine.rosa"), (self.vao_x + metade, self.caixa.bottom - 3, self.caixa.right - self.vao_x - metade, 3))
        if self.fase == "caindo":
            imagem = carregar_imagem("assets/sprites/ataques/bloco.png")
            for bloco in self._blocos():
                for x in range(bloco.left, bloco.right, imagem.get_width()):
                    largura = min(imagem.get_width(), bloco.right - x)
                    tela.blit(imagem, (x, bloco.top), (0, 0, largura, self.ALTURA))


class RajadaMirada(Padrao):
    """Uma linha fina mostra a mira e o tiro segue essa linha. Quem fica parado é atingido."""

    depende_do_jogador = True

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["tiros"]
        self.proxima = 0.1
        self.miras = []
        self.tiros = []
        self.origem_indice = 0

    def _origem(self):
        pontos = (
            (self.caixa.left + 6, self.caixa.top + 6),
            (self.caixa.right - 6, self.caixa.top + 6),
            (self.caixa.centerx, self.caixa.top + 4),
        )
        self.origem_indice += 1
        return pontos[self.origem_indice % len(pontos)]

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proxima -= dt
        if self.proxima <= 0 and self.restantes > 0:
            self.restantes -= 1
            self.proxima += self.dados["intervalo"]
            destino = self.alvo or self.jogador or self.caixa.center
            self.miras.append({"origem": self._origem(), "destino": destino, "tempo": self.dados["mira"]})

        for mira in self.miras:
            mira["tempo"] -= dt
            if mira["tempo"] <= 0:
                self._disparar(mira)
        self.miras = [mira for mira in self.miras if mira["tempo"] > 0]

        for tiro in self.tiros:
            tiro["x"] += tiro["vx"] * dt
            tiro["y"] += tiro["vy"] * dt
        self.tiros = [tiro for tiro in self.tiros if self.caixa.inflate(16, 16).collidepoint(tiro["x"], tiro["y"])]

    def _disparar(self, mira):
        x0, y0 = mira["origem"]
        dx, dy = mira["destino"][0] - x0, mira["destino"][1] - y0
        distancia = math.hypot(dx, dy) or 1.0
        velocidade = self.dados["velocidade"]
        self.tiros.append({"x": float(x0), "y": float(y0), "vx": dx / distancia * velocidade, "vy": dy / distancia * velocidade})

    def terminou(self):
        return self.restantes <= 0 and not self.miras and not self.tiros

    def perigos(self):
        return [pygame.Rect(int(tiro["x"]) - 2, int(tiro["y"]) - 2, 4, 4) for tiro in self.tiros]

    def desenhar(self, tela):
        for mira in self.miras:
            if int(mira["tempo"] * 16) % 2 == 0:
                pygame.draw.line(tela, cor("vitrine.rosa"), mira["origem"], mira["destino"])
        imagem = carregar_imagem("assets/sprites/ataques/tiro_inimigo.png")
        for tiro in self.tiros:
            tela.blit(imagem, (int(tiro["x"]) - 4, int(tiro["y"]) - 4))


class Lasers(Padrao):
    """Raios com aviso. O formato muda a resposta: sair da coluna, pular ou ficar no chão."""

    LARGURA_COLUNA = 12
    ALTURA_FAIXA = 8

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.ondas = list(self.dados["ondas"])
        self.fase = "aviso"
        self.tempo_fase = 0.0
        self._montar_onda()

    def _montar_onda(self):
        tipo = self.ondas[0]
        if tipo == "colunas":
            passo = self.dados["distancia_das_colunas"]
            inicio = self.caixa.left + self.sorte.randint(4, passo - self.LARGURA_COLUNA)
            self.raios = [
                pygame.Rect(x, self.caixa.top, self.LARGURA_COLUNA, self.caixa.height)
                for x in range(inicio, self.caixa.right - self.LARGURA_COLUNA, passo)
            ]
        elif tipo == "baixo":
            self.raios = [pygame.Rect(self.caixa.left, self.caixa.bottom - self.ALTURA_FAIXA, self.caixa.width, self.ALTURA_FAIXA)]
        else:  # "alto": quem fica no chão está seguro, e quem pula é atingido.
            self.raios = [pygame.Rect(self.caixa.left, self.caixa.bottom - 40, self.caixa.width, self.ALTURA_FAIXA)]

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        if self.fase == "aviso" and self.tempo_fase >= self.dados["aviso"]:
            self.fase = "ativo"
            self.tempo_fase = 0.0
        elif self.fase == "ativo" and self.tempo_fase >= self.dados["ativo"]:
            self.fase = "pausa"
            self.tempo_fase = 0.0
        elif self.fase == "pausa" and self.tempo_fase >= self.dados["pausa"]:
            self.ondas.pop(0)
            self.tempo_fase = 0.0
            if self.ondas:
                self.fase = "aviso"
                self._montar_onda()
            else:
                self.fase = "fim"

    def terminou(self):
        return self.fase == "fim"

    def perigos(self):
        return list(self.raios) if self.fase == "ativo" else []

    def desenhar(self, tela):
        if self.fase == "aviso" and int(self.tempo_fase * 12) % 2 == 0:
            for raio in self.raios:
                if raio.width > raio.height:
                    pygame.draw.line(tela, cor("vitrine.rosa"), (raio.left, raio.centery), (raio.right, raio.centery))
                else:
                    pygame.draw.line(tela, cor("vitrine.rosa"), (raio.centerx, raio.top), (raio.centerx, raio.bottom))
        elif self.fase == "ativo":
            for raio in self.raios:
                pygame.draw.rect(tela, cor("vitrine.rosa"), raio)
                pygame.draw.rect(tela, cor("neutros.branco"), raio.inflate(-4, -4))


class ParedesComVao(Padrao):
    """Paredes atravessam a caixa com um vão: embaixo ou em cima da plataforma. A posição decide."""

    ESPESSURA = 8
    ALTURA_PLATAFORMA = 30

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.plataforma = pygame.Rect(0, caixa.bottom - self.ALTURA_PLATAFORMA, self.dados["largura_plataforma"], 4)
        self.plataforma.centerx = caixa.centerx
        self.niveis = list(self.dados["vaos"])
        self.paredes = []
        self.proxima = 0.0

    def plataformas(self):
        return [self.plataforma]

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proxima -= dt
        if self.proxima <= 0 and self.niveis:
            self.proxima += self.dados["intervalo"]
            self.paredes.append({"x": float(self.caixa.right), "nivel": self.niveis.pop(0)})
        for parede in self.paredes:
            parede["x"] -= self.dados["velocidade"] * dt
        self.paredes = [parede for parede in self.paredes if parede["x"] > self.caixa.left - self.ESPESSURA]

    def terminou(self):
        return not self.niveis and not self.paredes

    def _vao(self, nivel):
        """Devolve o topo e a base do vão."""
        if nivel == "chao":
            return self.plataforma.top + 4, self.caixa.bottom
        return self.plataforma.top - self.dados["altura_do_vao"], self.plataforma.top

    def _retangulos(self, parede):
        topo, base = self._vao(parede["nivel"])
        x = int(parede["x"])
        acima = pygame.Rect(x, self.caixa.top, self.ESPESSURA, topo - self.caixa.top)
        abaixo = pygame.Rect(x, base, self.ESPESSURA, self.caixa.bottom - base)
        return [r for r in (acima, abaixo) if r.height > 0]

    def perigos(self):
        return [r for parede in self.paredes for r in self._retangulos(parede)]

    def desenhar(self, tela):
        pygame.draw.rect(tela, cor("vila.sol"), self.plataforma)
        for parede in self.paredes:
            for retangulo in self._retangulos(parede):
                pygame.draw.rect(tela, cor("vitrine.rosa_escuro"), retangulo)
                pygame.draw.rect(tela, cor("vitrine.rosa"), retangulo.inflate(-4, 0))


class Orbita(Padrao):
    """Anéis de drones nascem no meio da caixa, giram e se abrem. É preciso achar a brecha."""

    LADO = 6

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["aneis"]
        self.proximo = 0.0
        self.aneis = []
        # Com alvo, muda só a coluna: o anel nasce no meio da altura, nunca em cima do jogador.
        self.centro = (alvo[0], caixa.centery) if alvo else caixa.center
        self.raio_final = math.hypot(caixa.width, caixa.height) / 2 + 12 + math.hypot(self.centro[0] - caixa.centerx, self.centro[1] - caixa.centery)

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proximo -= dt
        if self.proximo <= 0 and self.restantes > 0:
            self.restantes -= 1
            self.proximo += self.dados["intervalo"]
            sentido = 1 if self.restantes % 2 else -1
            self.aneis.append({"raio": 6.0, "angulo": self.sorte.random() * math.tau, "sentido": sentido})
        for anel in self.aneis:
            anel["raio"] += self.dados["expansao"] * dt
            anel["angulo"] += anel["sentido"] * self.dados["rotacao"] * dt
        self.aneis = [anel for anel in self.aneis if anel["raio"] < self.raio_final]

    def terminou(self):
        return self.restantes <= 0 and not self.aneis

    def _pontos(self):
        total = self.dados["drones"]
        for anel in self.aneis:
            for numero in range(total):
                angulo = anel["angulo"] + numero * math.tau / total
                yield int(self.centro[0] + math.cos(angulo) * anel["raio"]), int(self.centro[1] + math.sin(angulo) * anel["raio"])

    def perigos(self):
        return [pygame.Rect(x - self.LADO // 2, y - self.LADO // 2, self.LADO, self.LADO) for x, y in self._pontos()]

    def desenhar(self, tela):
        imagem = carregar_imagem("assets/sprites/ataques/drone.png")
        for x, y in self._pontos():
            tela.blit(imagem, (x - 4, y - 4))


PADROES = {
    "nuvem_de_poeira": NuvemDePoeira,
    "varrida": Varrida,
    "lixo_caindo": LixoCaindo,
    "chuva_de_blocos": ChuvaDeBlocos,
    "rajada_mirada": RajadaMirada,
    "lasers": Lasers,
    "paredes_com_vao": ParedesComVao,
    "orbita": Orbita,
}


def dados_no_nivel(dados, nivel):
    """Repetir um ataque deixa ele mais forte (D66). "evolui" diz quanto cada número muda por nível."""
    if nivel <= 0 or "evolui" not in dados:
        return dados
    nivel = min(nivel, dados["nivel_maximo"])
    novos = dict(dados)
    for chave, passo in dados["evolui"].items():
        novos[chave] = dados[chave] + passo * nivel
    return novos


def dados_da_forma(dados, forma):
    """Na segunda forma da ÍRIS, os ataques antigos mudam de jeito: "forma2" troca só o que precisa."""
    if forma == 2 and "forma2" in dados:
        return {**dados, **dados["forma2"]}
    return dados


def criar_padrao(nome, regras, sorte=None, nivel=0, forma=1):
    dados = dados_da_forma(regras["padroes"][nome], forma)
    if "partes" in dados:  # Ataque combinado: ele precisa dos números de cada parte.
        dados = {**dados, "dados_das_partes": [regras["padroes"][parte] for parte in dados["partes"]]}
    return PADROES[nome](dados_no_nivel(dados, nivel), sorte)


# Os ataques exclusivos dos chefes usam a classe Padrao, por isso entram aqui no fim.
from src.batalha.padroes_chefes import PADROES_DOS_CHEFES  # noqa: E402

PADROES.update(PADROES_DOS_CHEFES)
