"""O inimigo na arena de tiro. O corpo e o jeito de lutar vêm de "arena_dados", em data/inimigos.json.

Inteligência: "ia" em data/batalha.json sobe aos poucos. comum_0 (ZIM) nem olha os tiros, comum_1 a
comum_3 reagem cada vez melhor, e só o nível chefe desvia bem e usa a memória do jogador (D49, D57).

Corpo e peso (D59): cada chefe tem o seu. "pode_pular": false é para quem é pesado demais. "voa" é para
quem flutua. "posicao_fixa" é para quem nunca sai do lugar, como a ÍRIS (D63). "desvio" diz como ele escapa
de um tiro, e "sequencia" é a série de movimentos que ele repete. Os retângulos são descritos com o inimigo
olhando para a direita e são espelhados ao virar. O que é único de cada chefe fica em mecanicas_arena.py.
"""

import math
import random

import pygame

from src.batalha.fisica import Corpo
from src.sistemas.cores import cor
from src.sistemas.recursos import carregar_imagem

QUADROS_POR_SEGUNDO = 8
TEMPO_DE_PISCADA_DE_DANO = 0.3
TEMPO_ENTRE_DECISOES = 0.5
ALCANCE_DE_VISAO = 130  # Tiros mais longe que isto ainda não preocupam.
ALCANCE_ATE_A_PLATAFORMA = 80
MARGEM_DO_TOPO = 16  # O sprite não sobe tanto a ponto de sair da tela.
BONUS_MAXIMO_DA_MEMORIA = 0.25
CHANCE_MAXIMA_DE_DESVIAR = 0.9  # Nem o chefe desvia de tudo: sempre dá para acertar.
TEMPO_DO_BLOQUEIO = 0.6
VELOCIDADE_DE_VOO = 70
SUBIDA_DO_DESVIO = 30
RAIO_DO_ANEL = 44


class InimigoArena:
    def __init__(self, id_inimigo, dados, ia, chao_y, limites, plataformas, memoria=None, sorte=None, sequencia=None):
        self.dados = dados
        self.ia = ia
        self.tamanho = dados["tamanho"]
        # O teto impede que um inimigo alto saia da tela ao pular.
        self.limites = pygame.Rect(limites.left, MARGEM_DO_TOPO + dados["corpo"][1], limites.width, limites.bottom - MARGEM_DO_TOPO - dados["corpo"][1])
        self.plataformas = plataformas
        self.memoria = memoria
        self.memoria_ligada = False  # A arena liga quando chega o turno em que o chefe usa o que viu.
        self.sorte = sorte or random.Random()
        rel_x, rel_y, largura, altura = dados["corpo"]
        self.rel_y = rel_y
        x_inicial = limites.right - self.tamanho - 40 + rel_x
        self.fisico = Corpo(x_inicial, chao_y - altura, largura, altura, dados["fisica"])
        self.fisico.no_chao = True
        # Quem tem posição fixa (a ÍRIS) fica sempre no mesmo lugar, e o corpo dela não empurra ninguém.
        self.fixo = "posicao_fixa" in dados
        if self.fixo:
            self.fisico.x = float(dados["posicao_fixa"][0] - largura // 2)
            self.fisico.y = float(dados["posicao_fixa"][1] - altura // 2)
        self.pode_pular = dados.get("pode_pular", True)
        self.voa = dados.get("voa", False)
        self.modo_de_desvio = dados.get("desvio", "pular")
        self.sequencia = sequencia or dados.get("sequencia")
        self.indice_do_passo = 0
        self.tempo_do_passo = 0.0
        self.passo_comecou = False
        self.golpes_pedidos = []  # A arena transforma cada pedido nos perigos que aparecem na tela.
        self.pedido_de_troca = False  # O ECO pede, e a mecânica dele troca todo mundo de palco.
        self.empacado = 0.0  # Exo: depois de bater, ele fica parado e mostra o ponto fraco.
        self.velocidade_de_voo = 1.0
        self.destino_de_voo = None
        self.ajuste_de_voo = 0.0
        self.sentido = -1
        self.tempo = 0.0
        self.tempo_andando = 0.0
        self.tempo_aberto = 0.0
        self.proxima_decisao = TEMPO_ENTRE_DECISOES
        self.espera_desvio = 0.0
        self.protecao = 0.0
        self.piscada = 0.0
        self.bloqueio = 0.0
        self.desvios = 0
        self.chao_y = chao_y
        pasta = "assets/sprites/inimigos"
        self.quadros_lado = [self._carregar(f"{pasta}/{id_inimigo}_lado_{n}.png") for n in (1, 2)]
        self.quadro_aberto = self._carregar(f"{pasta}/{id_inimigo}_lado_aberto.png")

    def _carregar(self, caminho):
        """Na arena, a ÍRIS aparece maior que o desenho original."""
        imagem = carregar_imagem(caminho)
        escala = self.dados.get("escala", 1)
        if escala == 1:
            return imagem
        return pygame.transform.scale(imagem, (imagem.get_width() * escala, imagem.get_height() * escala))

    # ---------- Posição ----------
    @property
    def corpo(self):
        return self.fisico.retangulo

    @property
    def x_do_sprite(self):
        rel_x, _, largura, _ = self.dados["corpo"]
        if self.sentido < 0:
            rel_x = self.tamanho - rel_x - largura
        return int(self.fisico.x) - rel_x

    @property
    def y_do_sprite(self):
        return int(self.fisico.y) - self.rel_y

    @property
    def aberto(self):
        """O ponto fraco aparece só em certos momentos."""
        return self.tempo_aberto > 0

    @property
    def ponto_fraco(self):
        x, y, largura, altura = self.dados["ponto_fraco"]
        if self.sentido < 0:
            x = self.tamanho - x - largura
        return pygame.Rect(self.x_do_sprite + x, self.y_do_sprite + y, largura, altura)

    # ---------- Defesas ----------
    def _anel_deixa_passar(self, tiro):
        """A abertura do anel gira. O tiro só passa se chegar pelo ângulo em que ela está agora."""
        anel = self.dados["anel"]
        abertura_em = (self.tempo * anel["velocidade"]) % math.tau
        centro = self.corpo.center
        area = tiro.retangulo
        angulo = math.atan2(area.centery - centro[1], area.centerx - centro[0])
        diferenca = abs((angulo - abertura_em + math.pi) % math.tau - math.pi)
        return diferenca <= anel["abertura"] / 2

    def acerta_o_ponto_fraco(self, tiro):
        """Diz se o tiro pegou no ponto fraco.

        O anel da ÍRIS não bloqueia mais nada (D69): o tiro pelo vão, ou com o anel parado, vale o dobro.
        Um ponto fraco no meio do corpo, como a tela do CRIVO, é acertado de frente, na altura dele.
        """
        if "anel" in self.dados:
            return self.aberto or self._anel_deixa_passar(tiro)
        if not self.aberto:
            return False
        area = tiro.retangulo
        if self.dados.get("ponto_fraco_no_corpo_todo"):
            return area.colliderect(self.corpo)  # ECO: de boca aberta, qualquer tiro nele vale o dobro.
        fraco = self.ponto_fraco
        if area.colliderect(fraco):
            return True
        no_meio_do_corpo = fraco.left >= self.corpo.left and fraco.right <= self.corpo.right
        de_frente = tiro.vx * self.sentido < 0
        return no_meio_do_corpo and de_frente and area.colliderect(self.corpo) and area.top < fraco.bottom and area.bottom > fraco.top

    def _satelites(self):
        dados = self.dados.get("satelites")
        if not dados:
            return []
        corpo = self.corpo
        lista = []
        for numero in range(dados["quantidade"]):
            angulo = self.tempo * dados["velocidade"] + numero * math.tau / dados["quantidade"]
            x = corpo.centerx + math.cos(angulo) * dados["raio"]
            y = corpo.centery + math.sin(angulo) * dados["raio"]
            lista.append(pygame.Rect(int(x) - 5, int(y) - 5, 10, 10))
        return lista

    def bloqueia(self, tiro):
        """Diz se uma defesa para o tiro antes de ele acertar o corpo."""
        area = tiro.retangulo
        if any(area.colliderect(satelite) for satelite in self._satelites()):
            return True
        if not area.colliderect(self.corpo.inflate(16, 16)):
            return False
        if "anel" in self.dados:
            return False
        if self.bloqueio > 0 and tiro.sentido != self.sentido:
            return True
        return False

    # ---------- Memória ----------
    def _habito(self, categoria):
        if self.memoria is None or not self.memoria_ligada:
            return None, 0.0
        return self.memoria.habito(categoria)

    # ---------- Decisões livres (quem não tem sequência) ----------
    def _virar(self, abrir_ponto_fraco=True):
        self.sentido = -self.sentido
        self.tempo_andando = 0.0
        if abrir_ponto_fraco:
            self.tempo_aberto = self.dados["aberto"]

    def _plataforma_ao_alcance(self):
        """A plataforma mais perto que dá para alcançar pulando, se houver."""
        fisica = self.dados["fisica"]
        altura_do_pulo = fisica["pulo"] ** 2 / (2 * fisica["gravidade"])
        corpo = self.corpo
        melhor = None
        for plataforma in self.plataformas:
            subida = corpo.bottom - plataforma.top
            cabe_na_tela = plataforma.top - self.tamanho >= MARGEM_DO_TOPO
            if 0 < subida < altura_do_pulo and cabe_na_tela:
                distancia = abs(plataforma.centerx - corpo.centerx)
                if distancia < ALCANCE_ATE_A_PLATAFORMA and (melhor is None or distancia < melhor[0]):
                    melhor = (distancia, plataforma)
        return melhor[1] if melhor else None

    def _chance_de_subir(self):
        """Quem atira sempre do chão faz o chefe preferir ficar no alto, onde esses tiros passam por baixo."""
        chance = self.ia["pular_plataforma"]
        altura, forca = self._habito("altura_do_tiro")
        if altura == "chao":
            chance += (1 - chance) * forca
        elif altura == "alto":
            chance *= 1 - forca
        return chance

    def _decidir(self, ada):
        if self.pode_pular and self.fisico.no_chao and self.sorte.random() < self._chance_de_subir():
            plataforma = self._plataforma_ao_alcance()
            if plataforma:
                self.sentido = 1 if plataforma.centerx >= self.corpo.centerx else -1
                self.fisico.pedir_pulo()
                return

        # Quem é esperto não deixa as costas viradas para a Ada, e o chefe lembra de que lado ela costuma atirar.
        lado, forca = self._habito("lado_do_tiro")
        if lado:
            preferido = -1 if lado == "esquerda" else 1
            if self.sentido != preferido and self.sorte.random() < forca:
                self._virar(abrir_ponto_fraco=False)
                return
        ada_nas_costas = (ada.centerx - self.corpo.centerx) * self.sentido < 0
        if ada_nas_costas and self.sorte.random() < self.ia["vira_para_ada"]:
            self._virar(abrir_ponto_fraco=False)

    # ---------- Desvios ----------
    def _vem_na_minha_direcao(self, tiro):
        corpo = self.corpo
        distancia = corpo.centerx - tiro.retangulo.centerx
        if tiro.vx == 0 or distancia * tiro.vx <= 0 or abs(distancia) >= ALCANCE_DE_VISAO:
            return False
        # Onde o tiro vai estar quando chegar à coluna do inimigo: agora ele pode vir em diagonal.
        altura_na_chegada = tiro.retangulo.centery + tiro.vy * (distancia / tiro.vx)
        return corpo.top <= altura_na_chegada <= corpo.bottom

    def _tentar_desviar(self, tiros):
        """Cada tiro é avaliado uma vez, e só depois do tempo de reação."""
        if self.ia["desviar"] <= 0 or self.modo_de_desvio == "nenhum":
            return  # Os primeiros inimigos nem olham para os tiros (D57).
        if self.aberto and self.modo_de_desvio == "bloquear":
            return  # Com o ponto fraco à mostra, ele não levanta os braços: é a chance do jogador.
        for tiro in tiros:
            if tiro.avaliado or tiro.idade < self.ia["reacao"] or not self._vem_na_minha_direcao(tiro):
                continue
            tiro.avaliado = True
            chance = self.ia["desviar"]
            altura, forca = self._habito("altura_do_tiro")
            if altura is not None and altura == tiro.origem:
                chance += BONUS_MAXIMO_DA_MEMORIA * forca
            if self.espera_desvio <= 0 and self.sorte.random() < min(chance, CHANCE_MAXIMA_DE_DESVIAR):
                self.espera_desvio = self.ia["intervalo_desvio"]
                self.desvios += 1
                self._executar_desvio(tiro)

    def _executar_desvio(self, tiro):
        modo = self.modo_de_desvio
        if modo == "bloquear":
            # Pesado demais para pular: o chefe vira para o tiro e levanta os braços.
            self.sentido = -tiro.sentido
            self.bloqueio = TEMPO_DO_BLOQUEIO
        elif modo == "subir":
            self.ajuste_de_voo = -SUBIDA_DO_DESVIO if self.corpo.centery > tiro.retangulo.centery else SUBIDA_DO_DESVIO
        elif self.pode_pular and self.fisico.no_chao:
            self.fisico.pedir_pulo()
        else:
            self.sentido = -self.sentido

    # ---------- Sequência de movimentos (D59) ----------
    def _encarar(self, ada):
        self.sentido = 1 if ada.centerx >= self.corpo.centerx else -1

    def _rodar_sequencia(self, dt, ada):
        """Roda o passo atual da sequência e devolve (direção, multiplicador de velocidade)."""
        passo = self.sequencia[self.indice_do_passo]
        acao = passo["acao"]
        primeira_vez = not self.passo_comecou
        self.passo_comecou = True
        self.tempo_do_passo += dt
        direcao, multiplicador = 0, passo.get("velocidade", 1.0)

        if acao == "andar":
            alvo = passo.get("para", "ada")
            if alvo == "ada":
                self._encarar(ada)
            elif alvo == "longe":
                self._encarar(ada)
                self.sentido = -self.sentido
            else:
                self.sentido = -1 if alvo == "esquerda" else 1
            direcao = self.sentido
        elif acao == "investida":
            if primeira_vez:
                self._encarar(ada)
            direcao = self.sentido
        elif acao == "abrir":
            if primeira_vez:
                self._encarar(ada)
            self.tempo_aberto = 0.05
        elif acao == "golpe" and primeira_vez:
            self._encarar(ada)
            self.golpes_pedidos.append(passo)
        elif acao == "mergulho":
            # A VIGIA desce de uma vez até onde a Ada estava, sem encostar no chão.
            if primeira_vez:
                self._encarar(ada)
                y = min(ada.centery, self.limites.bottom - self.fisico.altura // 2 - 16)
                self.destino_de_voo = (ada.centerx, y)
            self.velocidade_de_voo = multiplicador
        elif acao == "trocar" and primeira_vez:
            self.pedido_de_troca = True
        elif acao == "pular" and primeira_vez:
            if self.pode_pular:
                self.fisico.pedir_pulo()
            direcao = self.sentido
        elif acao == "voar":
            self._encarar(ada)
            x = ada.centerx if passo.get("x") == "ada" else passo.get("x", self.corpo.centerx)
            self.destino_de_voo = (x, passo["y"])
            self.velocidade_de_voo = multiplicador

        if self.tempo_do_passo >= passo["tempo"]:
            self.tempo_do_passo = 0.0
            self.passo_comecou = False
            self.indice_do_passo = (self.indice_do_passo + 1) % len(self.sequencia)
        return direcao, multiplicador

    @property
    def em_investida(self):
        return bool(self.sequencia) and self.empacado <= 0 and self.sequencia[self.indice_do_passo]["acao"] == "investida"

    @property
    def preparando_investida(self):
        return bool(self.sequencia) and self.sequencia[self.indice_do_passo].get("prepara_investida", False)

    def empacar(self, tempo):
        """Exo: a investida acabou numa batida. Ele fica parado, com o ponto fraco à mostra, e segue a sequência."""
        self.empacado = tempo
        self.tempo_aberto = max(self.tempo_aberto, tempo)
        self.tempo_do_passo = 0.0
        self.passo_comecou = False
        self.indice_do_passo = (self.indice_do_passo + 1) % len(self.sequencia)

    def _voar(self, dt):
        """Quem flutua vai direto ao destino, sem gravidade."""
        if self.destino_de_voo is None:
            return
        x, y = self.destino_de_voo
        y += self.ajuste_de_voo
        self.ajuste_de_voo *= max(0.0, 1 - 2.5 * dt)
        passo = VELOCIDADE_DE_VOO * self.velocidade_de_voo * dt
        centro = self.corpo.center
        self.fisico.x += max(-passo, min(x - centro[0], passo))
        self.fisico.y += max(-passo, min(y - centro[1], passo))
        self.fisico.x = max(self.limites.left, min(self.fisico.x, self.limites.right - self.fisico.largura))
        self.fisico.y = max(self.limites.top, min(self.fisico.y, self.limites.bottom - self.fisico.altura))

    # ---------- Atualização ----------
    def atualizar(self, dt, ada, tiros):
        self.tempo += dt
        self.protecao = max(0.0, self.protecao - dt)
        self.piscada = max(0.0, self.piscada - dt)
        self.tempo_aberto = max(0.0, self.tempo_aberto - dt)
        self.espera_desvio = max(0.0, self.espera_desvio - dt)
        self.bloqueio = max(0.0, self.bloqueio - dt)
        self._tentar_desviar(tiros)

        if self.empacado > 0:
            self.empacado = max(0.0, self.empacado - dt)
            return

        if self.sequencia:
            direcao, multiplicador = self._rodar_sequencia(dt, ada)
            if self.voa:
                self._voar(dt)
            else:
                self.fisico.mover(dt, direcao, self.limites, self.plataformas if self.pode_pular else (), multiplicador)
            return

        self.proxima_decisao -= dt
        if self.proxima_decisao <= 0:
            self.proxima_decisao += TEMPO_ENTRE_DECISOES
            self._decidir(ada)
        self.tempo_andando += dt
        if self.tempo_andando >= self.dados["andar"]:
            self._virar()
        self.fisico.mover(dt, self.sentido, self.limites, self.plataformas)
        if self.corpo.left <= self.limites.left and self.sentido < 0 or self.corpo.right >= self.limites.right and self.sentido > 0:
            self._virar()

    def proteger(self, tempo):
        self.protecao = tempo
        self.piscada = TEMPO_DE_PISCADA_DE_DANO

    # ---------- Desenho ----------
    def _imagem(self):
        if self.aberto and "anel" not in self.dados:
            imagem = self.quadro_aberto
        else:
            imagem = self.quadros_lado[int(self.tempo * QUADROS_POR_SEGUNDO) % 2]
        if self.piscada > 0 and int(self.tempo * 24) % 2:
            imagem = imagem.copy()
            imagem.fill((110, 110, 110, 0), special_flags=pygame.BLEND_RGBA_ADD)
        if self.sentido < 0 and not self.fixo:  # A ÍRIS não vira: ela fica sempre igual, no mesmo lugar.
            imagem = pygame.transform.flip(imagem, True, False)
        return imagem

    def desenhar(self, tela, camera):
        imagem = self._imagem()
        tela.blit(imagem, (self.x_do_sprite - camera, self.y_do_sprite))
        for satelite in self._satelites():
            pygame.draw.rect(tela, cor("neutros.nevoa"), satelite.move(-camera, 0))
            pygame.draw.rect(tela, cor("vitrine.rosa"), satelite.inflate(-6, -6).move(-camera, 0))
        if "anel" in self.dados:
            self._desenhar_anel(tela, camera)
        if self.bloqueio > 0:
            x = self.corpo.right + 4 if self.sentido > 0 else self.corpo.left - 8
            pygame.draw.rect(tela, cor("vila.sol"), (x - camera, self.corpo.top + 10, 4, self.corpo.height - 20))
        if self.aberto and "anel" not in self.dados and self.dados.get("marca_o_ponto_fraco"):
            # Provisório (FP4): mostra onde está o ponto fraco quando ele fica fora da cabine.
            fraco = self.ponto_fraco.move(-camera, 0)
            pygame.draw.rect(tela, cor("vitrine.rosa"), fraco)
            pygame.draw.rect(tela, cor("neutros.branco"), fraco, 1)

    def _desenhar_anel(self, tela, camera):
        anel = self.dados["anel"]
        if self.tempo_aberto > 0:
            return  # O anel para e abre por completo: o olho fica exposto.
        centro = (self.corpo.centerx - camera, self.corpo.centery)
        abertura_em = (self.tempo * anel["velocidade"]) % math.tau
        for grau in range(0, 360, 10):
            angulo = math.radians(grau)
            diferenca = abs((angulo - abertura_em + math.pi) % math.tau - math.pi)
            if diferenca > anel["abertura"] / 2:
                raio = anel.get("raio", RAIO_DO_ANEL)
                ponto = (int(centro[0] + math.cos(angulo) * raio), int(centro[1] + math.sin(angulo) * raio))
                pygame.draw.rect(tela, cor("vitrine.vidro"), (*ponto, 2, 2))
