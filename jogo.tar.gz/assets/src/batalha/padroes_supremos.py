"""Os ataques supremos (D62, D63). Cada um tem uma regra ou um controle que só existe nele.

- CRIVO, Veredito Final: entrar com recurso. Levar 3 PROVAS à coluna sem marca encerra o ataque. O tribunal aperta a cada rodada.
- VIGIA, Olho Total: o Lume tapa uma lente (X). Passar raspando nos cones faz ele voltar mais rápido.
- ECO, Transmissão Global: a Lupa da Rafa (segurar X) mostra o que é verdade. A cada corte de câmera, tudo muda de sentido.
- Exo-Desligador, Desligamento Geral: "traga alicate". Com X, a mini Ada corta os cabos que alimentam o braço.
- ÍRIS, Atualização 9.0 (primeira forma): tela inteira, voando com o Lume, enquanto ela ataca com balas, mísseis e raios.
- ÍRIS, Decisão Final (segunda forma): tela inteira, um duelo contra o olho, com as paredes fechando.

Eles não aceleram com os turnos e têm um teto de dano, que sobe com a ordem dos chefes (caixa_desvio.py). Ficam
difíceis pelo que exigem do jogador, não pela pressa. Algumas ideias vêm de chefes de Deltarune, só como inspiração:
ocupar a tela inteira, atirar durante o desvio, a caixa que aperta, recompensar quem passa raspando e a virada no meio
do ataque. Nada do jogo é reproduzido.
"""

import math

import pygame

from src.batalha.padroes import Padrao
from src.batalha.padroes_chefes import ComItens, _desenhar_texto
from src.batalha.padroes_iris import RaiosEmLeque
from src.sistemas.cores import cor
from src.sistemas.recursos import carregar_imagem


class Veredito(Padrao):
    """CRIVO: colunas condenadas são esmagadas. Quem leva 3 provas ao prato verde encerra o julgamento."""

    TERCOS = 3
    LADO_DA_PROVA = 10

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.rodada = 0
        self.seguro = 1
        self.entregues = 0
        self.carregando = False
        self.prova = None
        self._preparar()

    def _preparar(self):
        fracao = self.rodada / max(1, self.dados["rodadas"] - 1)
        self.aviso = self.dados["aviso_inicial"] + (self.dados["aviso_final"] - self.dados["aviso_inicial"]) * fracao
        if self.rodada:
            # Só anda uma coluna por vez: sempre dá tempo de chegar.
            opcoes = [t for t in (self.seguro - 1, self.seguro + 1) if 0 <= t < self.TERCOS]
            self.seguro = self.sorte.choice(opcoes)
        if not self.carregando and self.prova is None:
            self._nova_prova()
        self.fase = "aviso"
        self.tempo_fase = 0.0

    def _nova_prova(self):
        """A prova sempre aparece numa coluna condenada: pegar é arriscar."""
        condenadas = [t for t in range(self.TERCOS) if t != self.seguro]
        coluna = self._coluna(self.sorte.choice(condenadas))
        self.prova = pygame.Rect(coluna.centerx - self.LADO_DA_PROVA // 2, coluna.bottom - self.LADO_DA_PROVA - 2, self.LADO_DA_PROVA, self.LADO_DA_PROVA)

    def lentidao(self):
        return self.dados["lentidao_com_prova"] if self.carregando else 1.0

    def ao_atingir(self):
        self.carregando = False  # Quem é atingido deixa a prova cair.

    def _conferir_prova(self):
        if self.jogador is None:
            return
        if self.prova and self.prova.inflate(6, 6).collidepoint(self.jogador):
            self.prova = None
            self.carregando = True
        elif self.carregando and self._coluna(self.seguro).collidepoint(self.jogador):
            self.carregando = False
            self.entregues += 1
            if self.entregues >= self.dados["provas"]:
                self.fase, self.tempo_fase = "aceito", 0.0

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        if self.fase == "aceito":
            if self.tempo_fase >= self.dados["tempo_do_recurso"]:
                self.fase = "fim"
            return
        self._conferir_prova()
        if self.fase == "aviso" and self.tempo_fase >= self.aviso:
            self.fase, self.tempo_fase = "desce", 0.0
        elif self.fase == "desce" and self.tempo_fase >= self.dados["descida"]:
            self.fase, self.tempo_fase = "parado", 0.0
        elif self.fase == "parado" and self.tempo_fase >= self.dados["parado"]:
            self.rodada += 1
            if self.rodada >= self.dados["rodadas"]:
                self.fase = "fim"
            else:
                self._preparar()

    def terminou(self):
        return self.fase == "fim"

    def _coluna(self, terco):
        largura = self.caixa.width // self.TERCOS
        return pygame.Rect(self.caixa.left + terco * largura, self.caixa.top, largura, self.caixa.height)

    def _altura(self):
        if self.fase == "desce":
            return int(self.caixa.height * min(1.0, self.tempo_fase / self.dados["descida"]))
        return self.caixa.height if self.fase == "parado" else 0

    def _aperto(self):
        """O tribunal fecha: as paredes avançam um pouco a cada rodada."""
        return min(self.rodada, self.dados["rodadas"] - 1) * self.dados["aperto_por_rodada"]

    def _paredes(self):
        aperto = self._aperto()
        if aperto <= 0 or self.fase in ("fim", "aceito"):
            return []
        c = self.caixa
        return [pygame.Rect(c.left, c.top, aperto, c.height), pygame.Rect(c.right - aperto, c.top, aperto, c.height)]

    def perigos(self):
        altura = self._altura()
        lista = self._paredes()
        if altura <= 0:
            return lista
        for terco in range(self.TERCOS):
            if terco != self.seguro:
                coluna = self._coluna(terco)
                lista.append(pygame.Rect(coluna.left, coluna.top, coluna.width, altura))
        return lista

    def desenhar(self, tela):
        if self.fase == "fim":
            return
        if self.fase == "aceito":
            _desenhar_texto(self, tela, self.dados["texto_recurso"], self.caixa.left + 30, self.caixa.centery - 6, "verde.limao")
            return
        for terco in range(self.TERCOS):
            coluna = self._coluna(terco)
            # Só as colunas condenadas têm marca: a poupada é a que fica sem nada.
            if terco != self.seguro and self.fase == "aviso":
                pygame.draw.rect(tela, cor("vitrine.rosa"), (coluna.left, coluna.bottom - 3, coluna.width, 3))
        for parede in self._paredes():
            pygame.draw.rect(tela, cor("vitrine.rosa"), parede)
        if self.prova:
            pygame.draw.rect(tela, cor("neutros.branco"), self.prova)
            pygame.draw.rect(tela, cor("neutros.chumbo"), self.prova, 1)
        for r in self.perigos():
            pygame.draw.rect(tela, cor("balanca.carimbo"), r)
            pygame.draw.rect(tela, cor("balanca.vinho_carimbo"), (r.left, r.bottom - 5, r.width, 5))
            _desenhar_texto(self, tela, self.dados["texto"], r.left + 6, r.bottom - 17, "balanca.areia")
        _desenhar_texto(self, tela, f"{self.dados['texto_provas']} {self.entregues}/{self.dados['provas']}", self.caixa.left + 3, self.caixa.top, "neutros.gelo")

    def desenhar_por_cima(self, tela):
        if self.carregando and self.jogador:
            pygame.draw.rect(tela, cor("neutros.branco"), (self.jogador[0] - 4, self.jogador[1] - 14, 8, 6))


class OlhoTotal(Padrao):
    """VIGIA: cones de 4 câmeras cruzam a caixa. O Lume pode tapar uma lente, e isso abre um ponto cego."""

    precisa_do_especial = True

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.tapada = None
        self.tempo_tapada = 0.0
        self.recarga = 0.0
        self.raspando = False
        self.cameras = list(self.dados["cameras"])

    def _centro(self, indice):
        camera = self.cameras[indice]
        zona = self.caixa.left + self.caixa.width * camera["zona"]
        return zona + math.sin(self.tempo * camera["ritmo"] + camera["fase"]) * self.dados["curso_do_cone"]

    def _cone(self, indice):
        largura = self.dados["largura_do_cone"]
        return pygame.Rect(int(self._centro(indice)) - largura // 2, self.caixa.top, largura, self.caixa.height)

    def pode_usar_especial(self):
        return self.recarga <= 0

    def apertar_especial(self):
        """O Lume voa até a lente mais próxima da mini Ada e fica na frente dela."""
        if self.recarga > 0:
            return
        x = self.jogador[0] if self.jogador else self.caixa.centerx
        self.tapada = min(range(len(self.cameras)), key=lambda indice: abs(self._centro(indice) - x))
        self.tempo_tapada = self.dados["tempo_tapada"]
        self.recarga = self.dados["tempo_tapada"] + self.dados["tempo_de_volta"]

    def _raspando(self):
        """Passar perto de um cone, sem encostar, é arriscado: em troca, o Lume volta mais rápido."""
        if self.jogador is None or self.tempo < self.dados["aquecimento"]:
            return False
        perto = pygame.Rect(self.jogador[0] - 3, self.jogador[1] - 6, 7, 13).inflate(2 * self.dados["distancia_do_raspao"], 0)
        area = pygame.Rect(self.jogador[0] - 3, self.jogador[1] - 6, 7, 13)
        cones = self.perigos()
        return perto.collidelist(cones) != -1 and area.collidelist(cones) == -1

    def atualizar(self, dt):
        super().atualizar(dt)
        self.raspando = self._raspando()
        self.recarga = max(0.0, self.recarga - dt * (self.dados["bonus_do_raspao"] if self.raspando else 1))
        self.tempo_tapada = max(0.0, self.tempo_tapada - dt)
        if self.tempo_tapada <= 0:
            self.tapada = None

    def terminou(self):
        return self.tempo >= self.dados["duracao"]

    def perigos(self):
        if self.tempo < self.dados["aquecimento"]:
            return []
        return [self._cone(indice) for indice in range(len(self.cameras)) if indice != self.tapada]

    def desenhar(self, tela):
        ativo = self.tempo >= self.dados["aquecimento"]
        camada = pygame.Surface(self.caixa.size, pygame.SRCALPHA)
        for indice in range(len(self.cameras)):
            if indice != self.tapada:
                cor_da_luz = (255, 95, 168, 130) if ativo else (255, 95, 168, 45)
                pygame.draw.rect(camada, cor_da_luz, self._cone(indice).move(-self.caixa.left, -self.caixa.top))
        tela.blit(camada, self.caixa.topleft)
        for indice in range(len(self.cameras)):
            x = int(self._centro(indice))
            pygame.draw.rect(tela, cor("neutros.chumbo"), (x - 5, self.caixa.top, 10, 6))
            pygame.draw.rect(tela, cor("vitrine.rosa"), (x - 2, self.caixa.top + 2, 4, 3))

    def desenhar_por_cima(self, tela):
        if self.raspando and self.jogador and int(self.tempo * 20) % 2:
            pygame.draw.circle(tela, cor("vitrine.vidro"), self.jogador, 10, 1)
        if self.tapada is not None:
            imagem = carregar_imagem("assets/sprites/lume/lume_helice.png")
            tela.blit(imagem, (int(self._centro(self.tapada)) - imagem.get_width() // 2, self.caixa.top))
        elif self.recarga <= 0 and self.jogador:
            imagem = carregar_imagem("assets/sprites/lume/lume_normal.png")
            tela.blit(imagem, (self.jogador[0] - imagem.get_width() // 2, self.jogador[1] - 18))


class TransmissaoGlobal(ComItens):
    """ECO: a caixa enche de manchetes iguais. Só a Lupa da Rafa mostra quais são verdadeiras e machucam."""

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.faixas = [dict(faixa, proxima=faixa.get("fase", 0.0)) for faixa in self.dados["faixas"]]
        self.lupa = False
        self.proximo_corte = self.dados["intervalo_dos_cortes"]

    def segurar_especial(self, segurando):
        self.lupa = segurando

    def lentidao(self):
        return self.dados["lentidao_com_lupa"] if self.lupa else 1.0

    def _corte_de_camera(self):
        """CORTA! A edição inverte a cena: tudo o que está na tela passa a andar para o outro lado."""
        for item in self.itens:
            if item.get("aviso", 0) <= 0:
                item["vx"] = -item["vx"]
        for faixa in self.faixas:
            faixa["sentido"] = -faixa["sentido"]

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proximo_corte -= dt
        if self.proximo_corte <= 0:
            self.proximo_corte += self.dados["intervalo_dos_cortes"]
            if self.tempo < self.dados["duracao"]:
                self._corte_de_camera()
        for faixa in self.faixas:
            faixa["proxima"] -= dt
            if faixa["proxima"] <= 0 and self.tempo < self.dados["duracao"]:
                faixa["proxima"] += faixa["intervalo"]
                largura = faixa["largura"]
                x = self.caixa.left - largura if faixa["sentido"] > 0 else self.caixa.right
                y = self.caixa.bottom - faixa["altura_no_chao"]
                self._agendar(x=float(x), y=y, l=largura, a=10, vx=faixa["sentido"] * faixa["velocidade"],
                              machuca=self.sorte.random() < self.dados["parte_verdadeira"])
        self._mover_itens(dt)

    def terminou(self):
        return self.tempo >= self.dados["duracao"] and not self.itens

    def _dentro_da_lupa(self, retangulo, centro):
        x = max(retangulo.left, min(centro[0], retangulo.right))
        y = max(retangulo.top, min(centro[1], retangulo.bottom))
        return math.hypot(x - centro[0], y - centro[1]) <= self.dados["raio_da_lupa"]

    def perigos_visiveis(self, centro):
        """Sem a Lupa, tudo parece perigo. Com ela, só as verdadeiras que estão dentro do círculo."""
        if not self.lupa:
            return [self._retangulo(i) for i in self.itens if i.get("aviso", 0) <= 0]
        return [p for p in self.perigos() if self._dentro_da_lupa(p, centro)]

    def desenhar(self, tela):
        for item in self.itens:
            r = self._retangulo(item)
            revelada = self.lupa and self.jogador and self._dentro_da_lupa(r, self.jogador)
            if revelada and not item["machuca"]:
                pygame.draw.rect(tela, cor("eco.roxo"), r, 1)  # Falsa: quando checada, vira só o contorno.
                continue
            pygame.draw.rect(tela, cor("vermelho.vermelho"), r)
            pygame.draw.rect(tela, cor("vila.sol"), r, 1)
            _desenhar_texto(self, tela, self.dados["texto"], r.left + 2, r.top - 2, "neutros.branco")
            if revelada:
                pygame.draw.rect(tela, cor("vitrine.rosa"), (r.right - 9, r.top + 1, 8, 8))
                pygame.draw.rect(tela, cor("neutros.branco"), (r.right - 7, r.top + 3, 4, 4))

    def desenhar_por_cima(self, tela):
        if self.tempo < self.dados["duracao"] and self.proximo_corte < self.dados["aviso_do_corte"] and int(self.proximo_corte * 12) % 2 == 0:
            pygame.draw.rect(tela, cor("vitrine.rosa"), self.caixa, 2)
            _desenhar_texto(self, tela, self.dados["texto_do_corte"], self.caixa.centerx - 16, self.caixa.top + 2, "vitrine.rosa")
        if self.lupa and self.jogador:
            pygame.draw.circle(tela, cor("vila.sol"), self.jogador, self.dados["raio_da_lupa"], 1)


class DesligamentoGeral(ComItens):
    """Exo: "traga alicate", dizia o panfleto do Desconecta. Três cabos alimentam o braço, e o X corta o que estiver perto.

    O braço varre alto ou baixo, destroços caem e o chão dá choques, sempre com aviso. Cada cabo cortado enfraquece o exo:
    o 1º acaba com os destroços, o 2º deixa o braço mais lento e o 3º desliga tudo. Quem só desvia também sobrevive.
    """

    ALTURA_DO_CHOQUE = 6

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.cabos = [{"x": caixa.left + int(caixa.width * fracao), "cortado": False} for fracao in self.dados["cabos"]]
        self.proximo_destroco = 0.4
        self.ordem = list(self.dados["varridas"])
        self.sentido = 1
        self.tempo_do_choque = self.dados["intervalo_dos_choques"]
        self.choque = "espera"
        self.desligado = 0.0
        self._preparar_braco()

    def _cortados(self):
        return sum(cabo["cortado"] for cabo in self.cabos)

    def pode_usar_especial(self):
        return self.jogador is not None and self._cabo_perto() is not None

    def _cabo_perto(self):
        if self.jogador is None:
            return None
        for cabo in self.cabos:
            if not cabo["cortado"] and abs(cabo["x"] - self.jogador[0]) <= self.dados["alcance_do_alicate"]:
                return cabo
        return None

    def apertar_especial(self):
        cabo = self._cabo_perto()
        if cabo:
            cabo["cortado"] = True
            if self._cortados() == len(self.cabos):
                self.desligado = self.dados["tempo_desligando"]

    def _preparar_braco(self):
        self.varrida = "aviso"
        self.tempo_da_varrida = 0.0
        self.x_braco = float(self.caixa.left - self.dados["comprimento"] if self.sentido > 0 else self.caixa.right)

    def _faixa_do_braco(self):
        c = self.caixa
        if self.ordem[0] == "baixa":
            return c.bottom - self.dados["altura_baixa"], self.dados["altura_baixa"]
        return c.bottom - 17 - self.dados["altura_alta"], self.dados["altura_alta"]

    def _velocidade_do_braco(self):
        lento = self._cortados() >= 2
        return self.dados["velocidade"] * (self.dados["lentidao_do_braco"] if lento else 1)

    def _atualizar_braco(self, dt):
        if not self.ordem:
            return
        self.tempo_da_varrida += dt
        if self.varrida == "aviso" and self.tempo_da_varrida >= self.dados["aviso"]:
            self.varrida = "varrendo"
        elif self.varrida == "varrendo":
            self.x_braco += self.sentido * self._velocidade_do_braco() * dt
            comprimento = self.dados["comprimento"]
            if (self.sentido > 0 and self.x_braco > self.caixa.right) or (self.sentido < 0 and self.x_braco < self.caixa.left - comprimento):
                self.ordem.pop(0)
                self.sentido = -self.sentido
                if self.ordem:
                    self._preparar_braco()

    def _atualizar_choque(self, dt):
        self.tempo_do_choque -= dt
        if self.tempo_do_choque > 0:
            return
        if self.choque == "espera":
            self.choque, self.tempo_do_choque = "aviso", self.dados["aviso"]
        elif self.choque == "aviso":
            self.choque, self.tempo_do_choque = "ativo", self.dados["tempo_do_choque"]
        else:
            self.choque, self.tempo_do_choque = "espera", self.dados["intervalo_dos_choques"]

    def atualizar(self, dt):
        super().atualizar(dt)
        if self.desligado > 0:
            self.desligado -= dt
            if self.desligado <= 0:
                self.ordem = []
                self.itens = []
            return
        self._atualizar_braco(dt)
        self._atualizar_choque(dt)
        self.proximo_destroco -= dt
        if self.proximo_destroco <= 0 and self.ordem and self._cortados() == 0:
            self.proximo_destroco += self.dados["intervalo_dos_destrocos"]
            x = self.sorte.randint(self.caixa.left + 6, self.caixa.right - 16)
            self._agendar(x=float(x), y=float(self.caixa.top - 10), l=10, a=10, vy=self.dados["velocidade_dos_destrocos"])
        self._mover_itens(dt)
        self.itens = [i for i in self.itens if i["y"] < self.caixa.bottom]

    def terminou(self):
        return not self.ordem and not self.itens

    def perigos(self):
        if self.desligado > 0:
            return []  # Com o último cabo cortado, tudo para.
        lista = super().perigos()
        c = self.caixa
        if self.choque == "ativo":
            lista.append(pygame.Rect(c.left, c.bottom - self.ALTURA_DO_CHOQUE, c.width, self.ALTURA_DO_CHOQUE))
        if self.ordem and self.varrida == "varrendo":
            topo, altura = self._faixa_do_braco()
            lista.append(pygame.Rect(int(self.x_braco), topo, self.dados["comprimento"], altura))
        return lista

    def desenhar(self, tela):
        c = self.caixa
        for cabo in self.cabos:
            if cabo["cortado"]:
                pygame.draw.line(tela, cor("neutros.chumbo"), (cabo["x"], c.top), (cabo["x"], c.top + 14), 2)
            else:
                pygame.draw.line(tela, cor("vila.sol"), (cabo["x"], c.top), (cabo["x"], c.bottom), 2)
                pygame.draw.rect(tela, cor("vila.laranja_forte"), (cabo["x"] - 3, c.bottom - 12, 7, 12))
        if self.choque == "aviso" and int(self.tempo_do_choque * 12) % 2 == 0:
            pygame.draw.rect(tela, cor("vitrine.rosa"), (c.left, c.bottom - 3, c.width, 3))
        elif self.choque == "ativo" and self.desligado <= 0:
            pygame.draw.rect(tela, cor("vitrine.rosa"), (c.left, c.bottom - self.ALTURA_DO_CHOQUE, c.width, self.ALTURA_DO_CHOQUE))
        if self.ordem and self.desligado <= 0:
            topo, altura = self._faixa_do_braco()
            if self.varrida == "aviso" and int(self.tempo_da_varrida * 10) % 2 == 0:
                pygame.draw.rect(tela, cor("vitrine.rosa"), (c.left, topo, c.width, altura), 1)
            elif self.varrida == "varrendo":
                r = pygame.Rect(int(self.x_braco), topo, self.dados["comprimento"], altura)
                pygame.draw.rect(tela, cor("neutros.chumbo"), r)
                pygame.draw.rect(tela, cor("vila.laranja_forte"), (r.left, r.top, r.width, 3))
        for item in self.itens:
            pygame.draw.rect(tela, cor("neutros.cinza_claro"), self._retangulo(item))
        texto = f"{self.dados['texto_cabos']} {self._cortados()}/{len(self.cabos)}"
        _desenhar_texto(self, tela, texto, c.left + 3, c.top, "neutros.gelo")
        if self.desligado > 0:
            _desenhar_texto(self, tela, self.dados["texto_desligado"], c.centerx - 28, c.centery - 8, "vila.sol")

    def desenhar_por_cima(self, tela):
        if self._cabo_perto() is not None and self.jogador:
            _desenhar_texto(self, tela, "X", self.jogador[0] - 2, self.jogador[1] - 22, "vila.sol")


class _DuelonaTelaCheia(Padrao):
    """Base dos dois supremos da ÍRIS: tela inteira, o olho no alto e a mini Ada podendo atirar com X."""

    IMAGEM = "assets/sprites/inimigos/iris_frente_1.png"

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.tiros = []
        self.recarga = 0.0
        self.luta = None

    def receber_luta(self, luta):
        super().receber_luta(luta)
        self.luta = luta

    def pode_usar_especial(self):
        return self.recarga <= 0

    def vale_atirar(self):
        """Diz se um jogador atento atiraria agora. Serve para o robô de teste."""
        return True

    def _direcao_do_tiro(self):
        return 0.0, -1.0

    def apertar_especial(self):
        if self.recarga > 0 or self.jogador is None:
            return
        self.recarga = self.dados["recarga_do_tiro"]
        vx, vy = self._direcao_do_tiro()
        velocidade = self.dados["velocidade_do_tiro"]
        self.tiros.append({"x": float(self.jogador[0]), "y": float(self.jogador[1]), "vx": vx * velocidade, "vy": vy * velocidade})

    def _mover_tiros(self, dt):
        self.recarga = max(0.0, self.recarga - dt)
        for tiro in self.tiros:
            tiro["x"] += tiro["vx"] * dt
            tiro["y"] += tiro["vy"] * dt
        self.tiros = [t for t in self.tiros if self.caixa.collidepoint(t["x"], t["y"])]

    def _desenhar_tiros(self, tela):
        for tiro in self.tiros:
            pygame.draw.rect(tela, cor("vitrine.vidro"), (int(tiro["x"]) - 2, int(tiro["y"]) - 2, 4, 4))


class Atualizacao9(Padrao):
    """ÍRIS, primeira forma: a tela inteira vira o céu do núcleo, e a mini Ada voa com o Lume enquanto a instalação avança.

    Três etapas, que somam ataques: BAIXANDO (balas em leque), INSTALANDO (mísseis de dados, que perseguem e dá para
    despistar) e REINICIANDO (a luz cai, e os raios vêm mais rápido). Em 100%, um clarão deixa um só lugar seguro.

    Três pacotes flutuam em lugares perigosos (D69), e o X recusa o que estiver perto. Cada um corresponde a um ataque, que
    fica mais fraco até o fim. Cada pacote recusado também alarga o lugar seguro do clarão. O jogador decide quanto arriscar.
    """

    IMAGEM = "assets/sprites/inimigos/iris_frente_1.png"
    ALTURA_DA_BARRA = 7
    LADO_DA_BALA = 5
    LADO_DO_MISSIL = 8

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.barra = 0.0
        self.olho = (caixa.centerx, caixa.top + 24)
        self.balas = []
        self.misseis = []
        self.proxima_bala = self.dados["primeira_bala"]
        self.proximo_missil = self.dados["primeiro_missil"]
        self.raios = None
        self.espera_dos_raios = self.dados["primeiro_raio"]
        self.fase = "instalando"
        self.tempo_fase = 0.0
        largura = self.dados["vao_do_clarao"]
        self.vao = self.sorte.randint(caixa.left + 20, caixa.right - 20 - largura)
        self.pacotes = [dict(pacote, recusado=False, x=caixa.centerx + pacote["x"], y=caixa.top + pacote["y"]) for pacote in self.dados["pacotes"]]
        self.tempo_do_texto = 0.0

    def _recusou(self, tipo):
        return any(p["recusado"] for p in self.pacotes if p["tipo"] == tipo)

    def _pacote_perto(self):
        if self.jogador is None:
            return None
        alcance = self.dados["alcance_do_pacote"]
        for pacote in self.pacotes:
            if not pacote["recusado"] and math.hypot(pacote["x"] - self.jogador[0], pacote["y"] - self.jogador[1]) <= alcance:
                return pacote
        return None

    def pode_usar_especial(self):
        return self._pacote_perto() is not None

    def apertar_especial(self):
        pacote = self._pacote_perto()
        if pacote:
            pacote["recusado"] = True
            self.tempo_do_texto = self.dados["tempo_do_texto"]

    def _largura_do_vao(self):
        return self.dados["vao_do_clarao"] + self.dados["vao_por_pacote"] * sum(p["recusado"] for p in self.pacotes)

    def modo_voo(self):
        return True

    def estado_de_voo(self):
        return False, 0.0

    def mover_corpo(self, corpo, dt, dx, dy, limites, estado=None):
        corpo.no_chao = False
        corpo.vel_y = 0.0
        corpo.x = max(limites.left, min(corpo.x + dx * corpo.velocidade * dt, limites.right - corpo.largura))
        corpo.y = max(limites.top + self.dados["teto_do_voo"], min(corpo.y + dy * corpo.velocidade * dt, limites.bottom - corpo.altura))

    def _etapa(self):
        if self.barra < self.dados["barra_instalando"]:
            return 0
        return 1 if self.barra < self.dados["barra_reiniciando"] else 2

    def _soltar_balas(self):
        alvo = self.jogador or self.caixa.center
        base = math.atan2(alvo[1] - self.olho[1], alvo[0] - self.olho[0])
        quantas = self.dados["balas_por_etapa"][self._etapa()]
        if self._recusou("balas"):
            quantas = max(1, quantas - self.dados["balas_a_menos"])
        abertura = self.dados["abertura_das_balas"]
        velocidade = self.dados["velocidade_das_balas"]
        for numero in range(quantas):
            angulo = base + (numero - (quantas - 1) / 2) * abertura
            self.balas.append({"x": float(self.olho[0]), "y": float(self.olho[1]), "vx": math.cos(angulo) * velocidade, "vy": math.sin(angulo) * velocidade})

    def _soltar_missil(self):
        lado = self.sorte.choice((-1, 1))
        self.misseis.append({"x": float(self.olho[0] + lado * 30), "y": float(self.olho[1]), "angulo": math.pi / 2, "armando": self.dados["aviso"], "vida": self.dados["vida_do_missil"]})

    def _atualizar_misseis(self, dt):
        alvo = self.jogador or self.caixa.center
        vivos = []
        for missil in self.misseis:
            if missil["armando"] > 0:
                missil["armando"] -= dt
                vivos.append(missil)
                continue
            missil["vida"] -= dt
            if missil["vida"] <= 0:
                continue
            desejado = math.atan2(alvo[1] - missil["y"], alvo[0] - missil["x"])
            diferenca = (desejado - missil["angulo"] + math.pi) % math.tau - math.pi
            passo = self.dados["curva_do_missil"] * dt
            missil["angulo"] += max(-passo, min(diferenca, passo))
            missil["x"] += math.cos(missil["angulo"]) * self.dados["velocidade_do_missil"] * dt
            missil["y"] += math.sin(missil["angulo"]) * self.dados["velocidade_do_missil"] * dt
            vivos.append(missil)
        self.misseis = vivos

    def _atualizar_ataques(self, dt):
        self.barra = min(100.0, self.barra + self.dados["subida_da_barra"] * dt)
        etapa = self._etapa()
        self.proxima_bala -= dt
        if self.proxima_bala <= 0:
            self.proxima_bala = self.dados["intervalo_das_balas"][etapa] * (self.dados["pausa_recusada"] if self._recusou("balas") else 1)
            self._soltar_balas()
        if etapa >= 1:
            self.proximo_missil -= dt
            if self.proximo_missil <= 0:
                self.proximo_missil = self.dados["intervalo_dos_misseis"][etapa] * (self.dados["pausa_recusada"] if self._recusou("misseis") else 1)
                self._soltar_missil()
        if self.raios:
            self.raios.atualizar(dt)
            if self.raios.terminou():
                self.raios = None
                self.espera_dos_raios = self.dados["pausa_dos_raios"][etapa] * (self.dados["pausa_recusada"] if self._recusou("raios") else 1)
        else:
            self.espera_dos_raios -= dt
            if self.espera_dos_raios <= 0:
                raios = self.dados["raios"]["raios"] - (self.dados["raios_a_menos"] if self._recusou("raios") else 0)
                self.raios = RaiosEmLeque(dict(self.dados["raios"], dano=self.dano, raios=raios), self.sorte)
                self.raios.iniciar(self.caixa)

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        self.tempo_do_texto = max(0.0, self.tempo_do_texto - dt)
        for bala in self.balas:
            bala["x"] += bala["vx"] * dt
            bala["y"] += bala["vy"] * dt
        self.balas = [b for b in self.balas if self.caixa.collidepoint(b["x"], b["y"])]
        self._atualizar_misseis(dt)
        if self.fase == "instalando":
            self._atualizar_ataques(dt)
            if self.barra >= 100:
                self.raios = None
                self.fase, self.tempo_fase = "aviso_do_clarao", 0.0
        elif self.fase == "aviso_do_clarao" and self.tempo_fase >= self.dados["aviso_do_clarao"]:
            self.fase, self.tempo_fase = "clarao", 0.0
        elif self.fase == "clarao" and self.tempo_fase >= self.dados["tempo_do_clarao"]:
            self.fase = "fim"

    def terminou(self):
        return self.fase == "fim"

    def _lados_do_clarao(self):
        c = self.caixa
        largura = self._largura_do_vao()
        # O vão cresce para os dois lados, sem sair da tela.
        inicio = max(c.left + 4, min(self.vao - (largura - self.dados["vao_do_clarao"]) // 2, c.right - 4 - largura))
        return [pygame.Rect(c.left, c.top, inicio - c.left, c.height), pygame.Rect(inicio + largura, c.top, c.right - inicio - largura, c.height)]

    def perigos(self):
        if self.fase == "clarao":
            return self._lados_do_clarao()
        if self.fase == "fim":
            return []
        metade = self.LADO_DA_BALA // 2
        lista = [pygame.Rect(int(b["x"]) - metade, int(b["y"]) - metade, self.LADO_DA_BALA, self.LADO_DA_BALA) for b in self.balas]
        metade = self.LADO_DO_MISSIL // 2
        lista += [pygame.Rect(int(m["x"]) - metade, int(m["y"]) - metade, self.LADO_DO_MISSIL, self.LADO_DO_MISSIL) for m in self.misseis if m["armando"] <= 0]
        if self.raios:
            lista += self.raios.perigos()
        return lista

    def _desenhar_missil(self, tela, missil):
        """Um pacote de dados com ponta: a atualização vindo atrás de você. Pisca enquanto arma."""
        if missil["armando"] > 0 and int(missil["armando"] * 12) % 2:
            return
        angulo = missil["angulo"]
        x, y = missil["x"], missil["y"]
        frente = (x + math.cos(angulo) * 7, y + math.sin(angulo) * 7)
        esquerda = (x + math.cos(angulo + 2.4) * 6, y + math.sin(angulo + 2.4) * 6)
        direita = (x + math.cos(angulo - 2.4) * 6, y + math.sin(angulo - 2.4) * 6)
        pygame.draw.polygon(tela, cor("vitrine.rosa"), [frente, esquerda, direita])
        pygame.draw.circle(tela, cor("neutros.branco"), (int(x), int(y)), 2)
        rastro = (x - math.cos(angulo) * 10, y - math.sin(angulo) * 10)
        pygame.draw.line(tela, cor("vitrine.vidro"), (x, y), rastro)

    def desenhar(self, tela):
        c = self.caixa
        tela.blit(carregar_imagem(self.IMAGEM), (c.centerx - 48, c.top - 24))
        if self._etapa() == 2 or self.fase in ("aviso_do_clarao", "clarao"):
            escuro = pygame.Surface(c.size, pygame.SRCALPHA)
            escuro.fill((13, 11, 20, 215))
            tela.blit(escuro, c.topleft)
        barra = pygame.Rect(c.left + 40, c.top + 26, c.width - 80, self.ALTURA_DA_BARRA)
        pygame.draw.rect(tela, cor("neutros.chumbo"), barra)
        pygame.draw.rect(tela, cor("vitrine.rosa"), (barra.left, barra.top, int(barra.width * self.barra / 100), barra.height))
        pygame.draw.rect(tela, cor("neutros.gelo"), barra, 1)
        _desenhar_texto(self, tela, f"{self.dados['textos_das_etapas'][self._etapa()]} {int(self.barra)}%", barra.left, barra.bottom, "neutros.gelo")
        self._desenhar_pacotes(tela)
        if self.raios:
            self.raios.desenhar(tela)
        for bala in self.balas:
            pygame.draw.circle(tela, cor("vitrine.rosa"), (int(bala["x"]), int(bala["y"])), 3)
            pygame.draw.circle(tela, cor("neutros.branco"), (int(bala["x"]), int(bala["y"])), 1)
        for missil in self.misseis:
            self._desenhar_missil(tela, missil)
        if self.fase == "aviso_do_clarao":
            if int(self.tempo_fase * 12) % 2 == 0:
                for r in self._lados_do_clarao():
                    pygame.draw.rect(tela, cor("vitrine.rosa"), r, 2)
        elif self.fase == "clarao":
            for r in self._lados_do_clarao():
                pygame.draw.rect(tela, cor("neutros.branco"), r)

    def _desenhar_pacotes(self, tela):
        balanco = int(math.sin(self.tempo * 4) * 2)
        perto = self._pacote_perto()
        for pacote in self.pacotes:
            if pacote["recusado"]:
                continue
            area = pygame.Rect(pacote["x"] - 7, pacote["y"] - 7 + balanco, 14, 14)
            pygame.draw.rect(tela, cor("neutros.tinta"), area)
            pygame.draw.rect(tela, cor("vila.sol"), area, 1)
            _desenhar_texto(self, tela, pacote["letra"], area.left + 4, area.top - 1, "vila.sol")
            if pacote is perto:
                _desenhar_texto(self, tela, "X", area.left + 4, area.top - 13, "neutros.branco")
        if self.tempo_do_texto > 0:
            _desenhar_texto(self, tela, self.dados["texto_recusado"], self.caixa.centerx - 28, self.caixa.bottom - 28, "vila.sol")

    def desenhar_por_cima(self, tela):
        if self.jogador:
            imagem = carregar_imagem("assets/sprites/lume/lume_helice.png")
            tela.blit(imagem, (self.jogador[0] - imagem.get_width() // 2, self.jogador[1] - 18))


class DecisaoFinal(_DuelonaTelaCheia):
    """ÍRIS, segunda forma: um duelo. O olho fica no meio da tela, com uma fenda que gira, e o X atira na direção dele.

    Só entra o tiro que chega pela fenda: o que bate fora volta contra a mini Ada, então apertar sem parar não adianta.
    Anéis com uma brecha saem do olho, e as paredes fecham aos poucos. Quem acerta
    o bastante vence o duelo e encerra o ataque, tirando Integridade de verdade. Se as paredes chegarem ao fim, o ataque
    acaba sem vitória. Isto é o oposto do resto da luta: aqui, quem decide é o jogador.

    A cada 3 acertos, duas placas surgem no chão, e andar até uma delas escolhe o efeito (D69): abrir as paredes, alargar a
    fenda por um tempo ou ganhar o escudo do Lume, que bloqueia o próximo golpe.
    """

    IMAGEM = "assets/sprites/inimigos/iris2_frente_1.png"
    RAIO_DO_OLHO = 30
    LADO_DO_DRONE = 6

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.acertos = 0
        self.rebotes = []
        self.aneis = []
        self.proximo_anel = self.dados["aviso"]
        self.brecha = math.pi / 2  # Aponta para baixo: é onde a mini Ada está.
        self.fase = "duelo"
        self.tempo_fase = 0.0
        self.centro = (caixa.centerx, caixa.top + 58)
        largura = self.dados["largura_plataforma"]
        y = caixa.bottom - 30
        self.todas = [pygame.Rect(caixa.left + 40, y, largura, 4), pygame.Rect(caixa.right - 40 - largura, y, largura, 4)]
        self.placas = []
        self.recuo = 0.0
        self.tempo_da_fenda_larga = 0.0
        self.escudo = False

    def plataformas(self):
        return self.todas if self.corte() < 30 else []

    def corte(self):
        fracao = min(1.0, self.tempo / self.dados["duracao"])
        return max(0.0, fracao * (self.caixa.width - self.dados["largura_minima"]) / 2 - self.recuo)

    def _abertura(self):
        extra = self.dados["fenda_larga"] if self.tempo_da_fenda_larga > 0 else 1.0
        return self.dados["abertura_da_fenda"] * extra

    def _abrir_escolha(self):
        """Duas placas no chão, uma de cada lado. Andar até uma delas escolhe, e a outra some."""
        c = self.caixa
        largura = self.dados["largura_da_placa"]
        altura = self.dados["altura_da_placa"]
        # A vida fica no canto de baixo, à esquerda: a placa nunca cobre a barra.
        margem = max(int(self.corte()) + 6, self.dados["margem_da_placa"])
        opcoes = self.sorte.sample(self.dados["escolhas"], 2)
        self.placas = [
            {"tipo": opcoes[0]["id"], "texto": opcoes[0]["texto"], "area": pygame.Rect(c.left + margem, c.bottom - altura, largura, altura)},
            {"tipo": opcoes[1]["id"], "texto": opcoes[1]["texto"], "area": pygame.Rect(c.right - margem - largura, c.bottom - altura, largura, altura)},
        ]
        self.tempo_das_placas = self.dados["tempo_das_placas"]

    def _escolher(self, tipo):
        self.placas = []
        if tipo == "paredes":
            self.recuo += self.dados["recuo_das_paredes"]
        elif tipo == "fenda":
            self.tempo_da_fenda_larga = self.dados["tempo_da_fenda_larga"]
        elif tipo == "escudo":
            self.escudo = True

    def _conferir_placas(self, dt):
        self.tempo_da_fenda_larga = max(0.0, self.tempo_da_fenda_larga - dt)
        if not self.placas:
            return
        self.tempo_das_placas -= dt
        if self.tempo_das_placas <= 0:
            self.placas = []
            return
        for placa in self.placas:
            if self.jogador and placa["area"].collidepoint(self.jogador):
                self._escolher(placa["tipo"])
                return

    def absorve_o_golpe(self):
        if self.escudo:
            self.escudo = False
            return True
        return False

    def _direcao_do_tiro(self):
        dx, dy = self.centro[0] - self.jogador[0], self.centro[1] - self.jogador[1]
        distancia = math.hypot(dx, dy) or 1.0
        return dx / distancia, dy / distancia

    def _fenda(self):
        return (self.tempo * self.dados["giro_da_fenda"]) % math.tau

    def _entra_pela_fenda(self, x, y):
        angulo = math.atan2(y - self.centro[1], x - self.centro[0])
        return abs((angulo - self._fenda() + math.pi) % math.tau - math.pi) <= self._abertura() / 2

    def vale_atirar(self):
        return self.jogador is not None and self._entra_pela_fenda(*self.jogador)

    def _conferir_tiros(self):
        restantes = []
        for tiro in self.tiros:
            dx, dy = tiro["x"] - self.centro[0], tiro["y"] - self.centro[1]
            if math.hypot(dx, dy) > self.RAIO_DO_OLHO:
                restantes.append(tiro)
                continue
            if self._entra_pela_fenda(tiro["x"], tiro["y"]):
                self.acertos += 1
                if self.luta:
                    self.luta.ferir_inimigo(self.dados["dano_por_acerto"])
                if self.acertos % self.dados["acertos_por_escolha"] == 0 and self.acertos < self.dados["acertos_necessarios"]:
                    self._abrir_escolha()
            else:
                self.rebotes.append({"x": tiro["x"], "y": tiro["y"], "vx": -tiro["vx"] * 0.4, "vy": -tiro["vy"] * 0.4})
        self.tiros = restantes

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        self._mover_tiros(dt)
        if self.fase != "duelo":
            if self.tempo_fase >= self.dados["tempo_do_fim"]:
                self.fase = "fim"
            return
        self._conferir_tiros()
        self._conferir_placas(dt)
        for rebote in self.rebotes:
            rebote["x"] += rebote["vx"] * dt
            rebote["y"] += rebote["vy"] * dt
        self.rebotes = [r for r in self.rebotes if self.caixa.collidepoint(r["x"], r["y"])]
        self.proximo_anel -= dt
        if self.proximo_anel <= 0:
            self.proximo_anel += self.dados["intervalo_dos_aneis"]
            # A brecha anda só o que dá para acompanhar, e sempre fica virada para o chão.
            limite = self.dados["brecha_maxima"]
            desvio = self.sorte.uniform(-self.dados["passo_da_brecha"], self.dados["passo_da_brecha"])
            self.brecha = max(math.pi / 2 - limite, min(self.brecha + desvio, math.pi / 2 + limite))
            self.aneis.append({"raio": float(self.RAIO_DO_OLHO), "brecha": self.brecha})
        for anel in self.aneis:
            anel["raio"] += self.dados["velocidade_dos_aneis"] * dt
        self.aneis = [a for a in self.aneis if a["raio"] < 340]
        if self.acertos >= self.dados["acertos_necessarios"]:
            self.fase, self.tempo_fase = "vencida", 0.0
            self.aneis = []
        elif self.tempo >= self.dados["duracao"]:
            self.fase, self.tempo_fase = "perdida", 0.0
            self.aneis = []

    def terminou(self):
        return self.fase == "fim"

    def _pontos_do_anel(self, anel):
        passo = self.dados["passo_dos_drones"] / anel["raio"]
        angulo = 0.0
        while angulo < math.tau:
            diferenca = abs((angulo - anel["brecha"] + math.pi) % math.tau - math.pi)
            if diferenca * anel["raio"] > self.dados["brecha_dos_aneis"] / 2:
                yield int(self.centro[0] + math.cos(angulo) * anel["raio"]), int(self.centro[1] + math.sin(angulo) * anel["raio"])
            angulo += passo

    def perigos(self):
        if self.fase != "duelo":
            return []
        metade = self.LADO_DO_DRONE // 2
        lista = [pygame.Rect(x - metade, y - metade, self.LADO_DO_DRONE, self.LADO_DO_DRONE) for anel in self.aneis for x, y in self._pontos_do_anel(anel)]
        lista += [pygame.Rect(int(r["x"]) - 3, int(r["y"]) - 3, 6, 6) for r in self.rebotes]
        corte = int(self.corte())
        if corte > 0:
            lista.append(pygame.Rect(self.caixa.left, self.caixa.top, corte, self.caixa.height))
            lista.append(pygame.Rect(self.caixa.right - corte, self.caixa.top, corte, self.caixa.height))
        return lista

    def desenhar(self, tela):
        c = self.caixa
        for plataforma in self.plataformas():
            pygame.draw.rect(tela, cor("vila.laranja_forte"), plataforma)
        tela.blit(carregar_imagem(self.IMAGEM), (self.centro[0] - 48, self.centro[1] - 48))
        # A fenda é a parte do círculo por onde o tiro entra.
        fenda = self._fenda()
        metade = self._abertura() / 2
        for grau in range(0, 360, 6):
            angulo = math.radians(grau)
            if abs((angulo - fenda + math.pi) % math.tau - math.pi) > metade:
                x = int(self.centro[0] + math.cos(angulo) * self.RAIO_DO_OLHO)
                y = int(self.centro[1] + math.sin(angulo) * self.RAIO_DO_OLHO)
                pygame.draw.rect(tela, cor("neutros.branco"), (x - 1, y - 1, 3, 3))
        for r in self.perigos():
            pygame.draw.rect(tela, cor("vitrine.rosa"), r)
        self._desenhar_tiros(tela)
        y = c.top + 28
        _desenhar_texto(self, tela, f"{self.dados['texto_acertos']} {self.acertos}/{self.dados['acertos_necessarios']}", c.right - 90, y, "neutros.gelo")
        for placa in self.placas:
            area = placa["area"]
            pygame.draw.rect(tela, cor("vila.sol"), (area.left, area.bottom - 3, area.width, 3))
            pygame.draw.rect(tela, cor("vila.sol"), area, 1)
            _desenhar_texto(self, tela, placa["texto"], area.left + 2, area.top, "vila.sol")
        if self.fase == "vencida":
            _desenhar_texto(self, tela, self.dados["texto_vencida"], c.left + 90, c.centery + 20, "vila.sol")

    def desenhar_por_cima(self, tela):
        if self.escudo and self.jogador:
            pygame.draw.circle(tela, cor("vitrine.vidro"), self.jogador, 11, 1)


ATAQUES_SUPREMOS = {
    "veredito": Veredito,
    "olho_total": OlhoTotal,
    "transmissao_global": TransmissaoGlobal,
    "desligamento_geral": DesligamentoGeral,
    "atualizacao_9": Atualizacao9,
    "decisao_final": DecisaoFinal,
}
