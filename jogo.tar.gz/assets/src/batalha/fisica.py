"""Gravidade, pulo e colisão. A arena de tiro e a caixa de desvio usam este mesmo código (D40).

Muda só o tamanho do espaço e os números de "fisica" em data/batalha.json.
"""

import pygame

TEMPO_DE_GUARDA_DO_PULO = 0.1  # Aperta um pouco antes de tocar o chão e o pulo ainda vale.


class Corpo:
    def __init__(self, x, y, largura, altura, fisica):
        self.x = float(x)
        self.y = float(y)
        self.largura = largura
        self.altura = altura
        self.gravidade = fisica["gravidade"]
        self.velocidade = fisica["velocidade"]
        self.forca_do_pulo = fisica["pulo"]
        self.corte_do_pulo = fisica["corte_do_pulo"]
        self.vel_y = 0.0
        self.no_chao = False
        self._pulo_guardado = 0.0
        self.pulos_no_ar_maximo = fisica.get("pulos_no_ar", 0)  # 1 = pulo duplo.
        self.pulos_no_ar = self.pulos_no_ar_maximo
        self.invertida = False  # ÍRIS, Removendo Limites: a gravidade puxa para o teto.

    @property
    def retangulo(self):
        return pygame.Rect(int(self.x), int(self.y), self.largura, self.altura)

    def pedir_pulo(self):
        self._pulo_guardado = TEMPO_DE_GUARDA_DO_PULO

    def soltar_pulo(self):
        """Soltar o botão durante a subida corta o pulo, como em Mega Man clássico."""
        subindo = self.vel_y > 0 if self.invertida else self.vel_y < 0
        if subindo:
            self.vel_y *= self.corte_do_pulo

    def mover(self, dt, direcao, limites, plataformas=(), multiplicador=1.0):
        """direcao: -1, 0 ou 1. limites: retângulo do espaço. As plataformas só seguram quem vem de cima."""
        self._pulo_guardado = max(0.0, self._pulo_guardado - dt)

        # Primeiro resolve a horizontal...
        self.x += direcao * self.velocidade * multiplicador * dt
        self.x = max(limites.left, min(self.x, limites.right - self.largura))

        # ...depois a vertical.
        if self._pulo_guardado > 0 and (self.no_chao or self.pulos_no_ar > 0):
            if not self.no_chao:
                self.pulos_no_ar -= 1
            self.vel_y = self.forca_do_pulo if self.invertida else -self.forca_do_pulo
            self.no_chao = False
            self._pulo_guardado = 0.0

        base_antes = self.y + self.altura
        self.vel_y += -self.gravidade * dt if self.invertida else self.gravidade * dt
        self.y += self.vel_y * dt
        self.no_chao = False

        if self.invertida:
            # O teto vira chão. As plataformas só existem para quem cai para baixo.
            if self.y <= limites.top:
                self.y = float(limites.top)
                self.vel_y = 0.0
                self.no_chao = True
                self.pulos_no_ar = self.pulos_no_ar_maximo
            elif self.y + self.altura > limites.bottom:
                self.y = float(limites.bottom - self.altura)
                self.vel_y = min(0.0, self.vel_y)
            return

        if self.vel_y >= 0:
            for plataforma in plataformas:
                por_cima = base_antes <= plataforma.top + 1 and self.y + self.altura >= plataforma.top
                na_largura = self.x + self.largura > plataforma.left and self.x < plataforma.right
                if por_cima and na_largura:
                    self._pousar(plataforma.top)
                    break
        if self.y + self.altura >= limites.bottom:
            self._pousar(limites.bottom)
        if self.y < limites.top:
            self.y = float(limites.top)
            self.vel_y = max(0.0, self.vel_y)

    def _pousar(self, topo):
        self.y = float(topo - self.altura)
        self.vel_y = 0.0
        self.no_chao = True
        self.pulos_no_ar = self.pulos_no_ar_maximo
