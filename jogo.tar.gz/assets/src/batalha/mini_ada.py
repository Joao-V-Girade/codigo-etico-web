"""A mini Ada, que anda e pula dentro da caixa de desvio. Fica no lugar do coração do Undertale."""

import pygame

from src.batalha.fisica import Corpo
from src.sistemas.recursos import carregar_imagem

LARGURA = 9
ALTURA = 15
LARGURA_SPRITE = 11
ALTURA_SPRITE = 16
QUADROS_POR_SEGUNDO = 8
PISCADAS_POR_SEGUNDO = 12


class MiniAda:
    def __init__(self, x, y, fisica):
        self.corpo = Corpo(x, y, LARGURA, ALTURA, fisica)
        self.quadros = {
            nome: carregar_imagem(f"assets/sprites/ada/mini_ada_{nome}.png")
            for nome in ("parada", "andar_1", "andar_2", "pular", "dano")
        }
        self.olhando_esquerda = False
        self.andando = False
        self.tempo = 0.0
        self.invencivel = 0.0

    @property
    def area_de_dano(self):
        return self.corpo.retangulo.inflate(-2, -2)

    def atualizar(self, dt, direcao, limites, plataformas=(), multiplicador=1.0):
        self.tempo += dt
        self.invencivel = max(0.0, self.invencivel - dt)
        self.andando = direcao != 0
        if direcao:
            self.olhando_esquerda = direcao < 0
        self.corpo.mover(dt, direcao, limites, plataformas, multiplicador)

    def voar(self, dt, direcao, vertical, limites, padrao):
        """No Desligamento Geral, o Lume carrega a mini Ada. Quem decide como ela se move é o ataque."""
        self.tempo += dt
        self.invencivel = max(0.0, self.invencivel - dt)
        self.andando = direcao != 0
        if direcao:
            self.olhando_esquerda = direcao < 0
        padrao.mover_corpo(self.corpo, dt, direcao, vertical, limites)

    def _quadro(self):
        if self.invencivel > 0:
            return self.quadros["dano"]
        if not self.corpo.no_chao:
            return self.quadros["pular"]
        if self.andando:
            return self.quadros["andar_1" if int(self.tempo * QUADROS_POR_SEGUNDO) % 2 else "andar_2"]
        return self.quadros["parada"]

    def desenhar(self, tela):
        if self.invencivel > 0 and int(self.tempo * PISCADAS_POR_SEGUNDO) % 2:
            return
        imagem = self._quadro()
        if self.olhando_esquerda:
            imagem = pygame.transform.flip(imagem, True, False)
        if self.corpo.invertida:
            imagem = pygame.transform.flip(imagem, False, True)
        x = self.corpo.retangulo.centerx - LARGURA_SPRITE // 2
        y = self.corpo.retangulo.bottom - ALTURA_SPRITE
        tela.blit(imagem, (x, y))
