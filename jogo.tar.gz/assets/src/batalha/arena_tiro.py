"""A tela de COMBATE: plataformas no mapa inteiro, mira, combo e os golpes próprios de cada chefe (D40, D61).

O que deixa o combate mais divertido:
- Movimento: pulo duplo e impulso (a Ada atravessa perigos durante o impulso).
- Mira: o mouse atira para onde aponta, e no teclado "cima" atira na diagonal.
- Combo: acertar em sequência dá energia, tempo e, a partir de certo ponto, mais dano. Levar um golpe zera.
- Baterias: aparecem nas plataformas e recompensam quem sobe.
- Resposta: faíscas, tremor e uma pequena pausa nos acertos fortes.
"""

import math
import random

import pygame

from config import ALTURA_TELA, LARGURA_TELA
from src.batalha.ada_arena import AdaArena
from src.batalha.inimigo import InimigoArena
from src.batalha.mecanicas_arena import criar_mecanica
from src.sistemas.cores import cor
from src.sistemas.entrada import acao_do_evento, acao_do_mouse, esta_pressionada
from src.sistemas.recursos import carregar_imagem
from src.sistemas.textos import resolver
from src.ui.barras import desenhar_barra

DESLOCAMENTO_DA_CAMERA = 16
PASSO_MAXIMO = 0.05
ALTURA_DA_PLATAFORMA = 10
TEMPO_DO_NUMERO = 0.7
LARGURA_DOS_LIMITES = LARGURA_TELA + 2 * DESLOCAMENTO_DA_CAMERA
RAIZ_DE_METADE = 0.7071
TAMANHO_DA_BATERIA = 8
VIDA_DA_FAISCA = 0.35
ALTURA_DA_MARCA = 6


class ArenaTiro:
    def __init__(self, jogo, luta, regras, id_inimigo, textos):
        self.jogo = jogo
        self.luta = luta
        self.regras = regras["arena"]
        self.textos = textos
        inimigo = luta.inimigo
        self.cenario = regras["arenas"][inimigo["arena"]]
        chao_y = self.cenario["chao_y"]
        self.chao_y = chao_y
        # Uma arena pode ser maior que a tela: ela é desenhada à parte e reduzida para caber inteira.
        # A tela não anda: assim, a ÍRIS fica sempre parada no centro.
        self.mundo = self.cenario.get("mundo")
        if self.mundo:
            self.limites = pygame.Rect(0, 0, self.mundo[0], chao_y)
            self.tela_do_mundo = pygame.Surface(self.mundo, 0, 32)
            self.reducao = self.mundo[0] / LARGURA_TELA
        else:
            self.limites = pygame.Rect(-DESLOCAMENTO_DA_CAMERA, 0, LARGURA_DOS_LIMITES, chao_y)
        self.camadas = [(carregar_imagem(f"assets/fundos/{c['imagem']}.png"), c) for c in self.cenario["camadas"]]
        self.imagem_chao = carregar_imagem(f"assets/fundos/{self.cenario['chao']}.png")
        self.imagem_plataforma = carregar_imagem(f"assets/fundos/{self.cenario['plataforma']}.png")
        self.tempo = 0.0
        # A lista é a mesma para a Ada e o inimigo. O cenário muda: plataformas andam, piscam e somem.
        self.dados_das_plataformas = [
            {"dados": p, "indice": indice, "retangulo": pygame.Rect(p["x"], p["y"], self.imagem_plataforma.get_width(), ALTURA_DA_PLATAFORMA)}
            for indice, p in enumerate(self.cenario["plataformas"])
            if indice not in luta.plataformas_cortadas
        ]
        self.plataformas = []
        self.golpes = []
        self.ada = AdaArena(20, chao_y, self.regras)
        dados_da_arena = inimigo["arena_dados"]
        sequencia = dados_da_arena.get("sequencia_fase2") if luta.em_fase2 else None
        self.inimigo = InimigoArena(
            id_inimigo + luta.sufixo_visual(), dados_da_arena, regras["ia"][dados_da_arena["ia"]], chao_y, self.limites, self.plataformas, luta.memoria,
            sequencia=sequencia,
        )
        self.inimigo.memoria_ligada = luta.memoria_em_uso
        self.numeros = []
        self.faiscas = []
        self.tremor = 0.0
        # O que é único de cada chefe fica na mecânica dele (D63).
        self.mecanica = criar_mecanica(self)
        self.mecanica.preparar()
        self._atualizar_plataformas(0.0)
        self.pressionada = esta_pressionada
        self.posicao_do_mouse = pygame.mouse.get_pos
        self.sorte = random.Random()
        self.tiros = []
        self.baterias = []
        self.proxima_bateria = self.regras["baterias"]["intervalo"]
        self.combo = 0
        self.tempo_do_combo = 0.0
        self.impacto = 0.0
        self.tempo_restante = self.regras["tempo"]
        self.preparar = self.regras["preparar"]
        self.segurava_pulo = False
        self.terminou = False

    # ---------- Cenário vivo ----------
    def _plataforma_ligada(self, dados):
        pisca = dados.get("pisca")
        if not pisca:
            return True
        return (self.tempo + pisca.get("fase", 0)) % pisca["periodo"] < pisca["ligada"]

    def _vai_apagar(self, dados):
        pisca = dados.get("pisca")
        if not pisca:
            return False
        restante = pisca["ligada"] - (self.tempo + pisca.get("fase", 0)) % pisca["periodo"]
        return 0 < restante < self.regras["aviso_da_plataforma"]

    def _atualizar_plataformas(self, dt):
        """Move as plataformas e leva junto quem está em cima delas."""
        for plataforma in self.dados_das_plataformas:
            dados = plataforma["dados"]
            retangulo = plataforma["retangulo"]
            antes = retangulo.topleft
            if "prato" in dados:
                retangulo.y = self.mecanica.y_do_prato(dados)
            orbita = dados.get("orbita")
            if orbita:
                # ÍRIS: as plataformas giram em volta do olho, numa órbita achatada.
                centro_x, centro_y = self.cenario["centro_da_orbita"]
                angulo = orbita["fase"] + self.tempo * orbita["velocidade"] * self.mecanica.ritmo_da_orbita()
                retangulo.x = int(centro_x + math.cos(angulo) * orbita["raio_x"]) - retangulo.width // 2
                retangulo.y = int(centro_y + math.sin(angulo) * orbita["raio_y"])
            movimento = dados.get("move")
            if movimento:
                onda = math.sin((self.tempo + movimento.get("fase", 0)) * math.tau / movimento["periodo"]) * movimento["amplitude"]
                if movimento["eixo"] == "x":
                    retangulo.x = int(dados["x"] + onda)
                else:
                    retangulo.y = int(dados["y"] + onda)
            if dt > 0:
                self._levar_quem_esta_em_cima(retangulo, antes)
        self.plataformas[:] = [p["retangulo"] for p in self.dados_das_plataformas if self._plataforma_ligada(p["dados"])]

    def _levar_quem_esta_em_cima(self, retangulo, antes):
        dx, dy = retangulo.x - antes[0], retangulo.y - antes[1]
        if not (dx or dy):
            return
        # Só leva quem pisa de verdade: quem flutua, como a ÍRIS, nunca é carregado.
        corpos = (self.ada.corpo,) if self.inimigo.voa else (self.ada.corpo, self.inimigo.fisico)
        for corpo in corpos:
            pisando = corpo.no_chao and abs(corpo.y + corpo.altura - antes[1]) <= 1
            na_largura = corpo.x + corpo.largura > antes[0] and corpo.x < antes[0] + retangulo.width
            if pisando and na_largura:
                corpo.x += dx
                corpo.y += dy

    def _aplicar_vento(self, dt):
        vento = self.cenario.get("vento")
        if vento:
            corpo = self.ada.corpo
            corpo.x += math.sin(self.tempo * math.tau / vento["periodo"]) * vento["forca"] * self.mecanica.forca_do_vento() * dt
            corpo.x = max(self.limites.left, min(corpo.x, self.limites.right - corpo.largura))

    # ---------- Golpes do inimigo ----------
    def _criar_golpes(self, pedido):
        """Transforma um passo "golpe" da sequência de movimentos nos perigos que aparecem na arena."""
        forma = pedido.get("forma", "onda")
        corpo = self.inimigo.corpo
        ada = self.ada.retangulo
        comum = {"aviso": pedido.get("aviso", 0.0), "ativo": pedido.get("ativo", 0.0), "segue": pedido.get("segue", False)}
        if forma == "onda":
            altura = pedido.get("altura", 10)
            y = corpo.centery - altura // 2 if pedido.get("na_altura_do_corpo") else self.chao_y - altura
            for sentido in (-1, 1):
                self.golpes.append({"forma": "onda", "x": float(corpo.centerx), "y": y, "altura": altura, "sentido": sentido})
        elif forma == "faixa":
            altura = pedido.get("altura", 10)
            self.golpes.append(dict(comum, forma="faixa", y=ada.centery - altura // 2, altura=altura))
        else:
            largura = pedido.get("largura", 20)
            mira = pedido.get("mira", "ada")
            if mira == "frente":
                posicoes = [corpo.centerx + self.inimigo.sentido * (corpo.width // 2 + largura // 2)]
            elif mira == "grade":
                quantos = pedido.get("quantos", 3)
                passo = self.limites.width // (quantos + 1)
                inicio = self.limites.left + self.sorte.randint(passo // 2, passo)
                posicoes = [inicio + indice * passo for indice in range(quantos)]
            else:
                posicoes = [ada.centerx]
            for x in posicoes:
                self.golpes.append(dict(comum, forma="coluna", x=float(x), largura=largura, deixa_marca=pedido.get("deixa_marca", False)))

    def _area_do_golpe(self, golpe):
        if golpe["forma"] == "onda":
            return pygame.Rect(int(golpe["x"]) - 5, golpe["y"], 10, golpe["altura"])
        if golpe["forma"] == "faixa":
            return pygame.Rect(self.limites.left, golpe["y"], self.limites.width, golpe["altura"])
        if golpe["forma"] == "marca":
            return pygame.Rect(int(golpe["x"]) - golpe["largura"] // 2, self.chao_y - ALTURA_DA_MARCA, golpe["largura"], ALTURA_DA_MARCA)
        return pygame.Rect(int(golpe["x"]) - golpe["largura"] // 2, 0, golpe["largura"], self.chao_y)

    def _atualizar_golpes(self, dt):
        while self.inimigo.golpes_pedidos:
            self._criar_golpes(self.inimigo.golpes_pedidos.pop(0))
        vivos = []
        for golpe in self.golpes:
            if golpe["forma"] == "onda":
                golpe["x"] += golpe["sentido"] * self.regras["velocidade_da_onda"] * dt
                if self.limites.left - 10 < golpe["x"] < self.limites.right + 10:
                    vivos.append(golpe)
            else:
                if golpe["segue"]:
                    passo = self.regras["velocidade_do_feixe"] * dt
                    golpe["x"] += max(-passo, min(self.ada.retangulo.centerx - golpe["x"], passo))
                if golpe["aviso"] > 0:
                    golpe["aviso"] -= dt
                    vivos.append(golpe)
                    continue
                golpe["ativo"] -= dt
                if golpe["ativo"] > 0:
                    vivos.append(golpe)
                elif golpe.get("deixa_marca") and self.luta.em_fase2:
                    # CRIVO, depois da metade: o carimbo deixa uma marca NEGADO no chão, que leva a Ada para os pratos.
                    vivos.append({"forma": "marca", "x": golpe["x"], "largura": golpe["largura"], "aviso": 0.0,
                                  "ativo": self.regras["tempo_da_marca"], "segue": False})
            if self._area_do_golpe(golpe).colliderect(self.ada.retangulo):
                self._atingir_ada(self.ada.retangulo.centerx + 1 if golpe.get("sentido", 0) < 0 else self.ada.retangulo.centerx - 1)
        self.golpes = vivos

    def _atingir_ada(self, de_onde_x):
        """Na arena, um golpe não tira vida: empurra e zera o combo. O perigo de vida fica no turno do inimigo."""
        if self.ada.empurrar(de_onde_x):
            self.combo = 0
            self.tremor = self.regras["tempo_do_tremor"]
            self.mecanica.ao_atingir_ada()

    # ---------- Entrada ----------
    def _mira_do_mouse(self, posicao):
        """A direção do Pulsor até o ponteiro. A Ada vira para esse lado."""
        origem = self.ada.retangulo.center
        x, y = self.tela_para_arena(posicao)
        dx = x - origem[0]
        dy = y - origem[1]
        distancia = math.hypot(dx, dy)
        if distancia < 1:
            return None
        self.ada.sentido = 1 if dx >= 0 else -1
        return dx / distancia, dy / distancia

    def _mira_do_teclado(self):
        """Segurar "cima" atira na diagonal para o alto. Sem isso, o tiro vai reto."""
        if self.pressionada("cima"):
            return self.ada.sentido * RAIZ_DE_METADE, -RAIZ_DE_METADE
        return None

    def tratar_evento(self, evento):
        acao = acao_do_evento(evento)
        if acao == "confirmar":
            self.ada.corpo.pedir_pulo()
        if self.preparar > 0:
            return
        if acao == "cancelar":
            self._guardar_tiro(self.ada.apertar_tiro(len(self.tiros), self._mira_do_teclado()))
        elif acao == "impulso":
            self.ada.dar_impulso()
        clique = acao_do_mouse(evento)
        if clique == "tiro_mouse":
            self._guardar_tiro(self.ada.atirar_normal(len(self.tiros), self._mira_do_mouse(evento.pos)))
        elif clique == "carga_mouse":
            self.ada.comecar_carga("carga_mouse")

    def _guardar_tiro(self, tiro):
        if not tiro:
            return
        tiro.origem = "chao" if self.ada.retangulo.bottom >= self.chao_y else "alto"
        self.tiros.append(tiro)
        memoria = self.luta.memoria
        if memoria and self.mecanica.pode_observar():  # Fora do cone, a VIGIA não coleta dados.
            lado = "esquerda" if self.ada.retangulo.centerx < self.inimigo.corpo.centerx else "direita"
            memoria.observar("altura_do_tiro", tiro.origem)
            memoria.observar("lado_do_tiro", lado)

    def _ler_teclas(self, dt):
        direcao = 0
        if self.pressionada("esquerda"):
            direcao -= 1
        if self.pressionada("direita"):
            direcao += 1
        segura = self.pressionada("confirmar")
        if self.segurava_pulo and not segura:
            self.ada.corpo.soltar_pulo()
        self.segurava_pulo = segura

        if self.ada.carregando:
            if self.pressionada(self.ada.botao_de_carga):
                self.ada.carga += dt
            else:
                if self.ada.botao_de_carga == "carga_mouse":
                    mira = self._mira_do_mouse(self.posicao_do_mouse())
                else:
                    mira = self._mira_do_teclado()
                self._guardar_tiro(self.ada.soltar_tiro(self.luta, mira))
        return direcao

    # ---------- Lógica ----------
    def atualizar(self, dt):
        dt = min(dt, PASSO_MAXIMO)
        self.tremor = max(0.0, self.tremor - dt)
        self._atualizar_faiscas(dt)
        if self.impacto > 0:  # Um instante de pausa faz o acerto forte parecer forte.
            self.impacto -= dt
            return
        self.tempo += dt
        self._atualizar_plataformas(dt)
        if self.preparar > 0:
            self.preparar -= dt
            direcao = 0
            self.segurava_pulo = self.pressionada("confirmar")
        else:
            direcao = self._ler_teclas(dt)
            self.tempo_restante = max(0.0, self.tempo_restante - dt)
            self.inimigo.atualizar(dt, self.ada.retangulo, self.tiros)
            self.mecanica.atualizar(dt)
        self.ada.atualizar(dt, direcao, self.limites, self.plataformas)
        if self.preparar <= 0:
            self._aplicar_vento(dt)
            self._atualizar_golpes(dt)
            self._atualizar_baterias(dt)
            self._atualizar_combo(dt)
        self._atualizar_tiros(dt)
        if not self.inimigo.fixo and self.ada.retangulo.colliderect(self.inimigo.corpo):
            self._atingir_ada(self.inimigo.corpo.centerx)
        self.numeros = [n for n in self.numeros if n["tempo"] > 0]
        for numero in self.numeros:
            numero["tempo"] -= dt
            numero["y"] -= 20 * dt
        # O aviso do Lume interrompe o combate na hora, para ninguém destruir sem perceber (05, seção 8).
        # A ult também: quando o chefe chega à vida dela, ela vem logo em seguida (D68).
        if self.tempo_restante <= 0 or self.luta.destruido or self.luta.aviso_pendente or self.luta.ult_pendente:
            self.terminou = True

    def finalizar(self):
        """Chamada quando o COMBATE acaba: o que aconteceu aqui muda o turno do inimigo."""
        self.mecanica.ao_terminar()

    def _atualizar_combo(self, dt):
        if self.combo > 0:
            self.tempo_do_combo -= dt
            if self.tempo_do_combo <= 0:
                self.combo = 0

    def _ganhar_tempo(self, segundos):
        maximo = self.regras["tempo"] * self.regras["combo"]["tempo_maximo"]
        self.tempo_restante = min(maximo, self.tempo_restante + segundos)

    def _contar_acerto(self):
        """A cada acerto, o combo sobe. De tempos em tempos, ele dá energia e alguns décimos de segundo."""
        dados = self.regras["combo"]
        self.combo += 1
        self.tempo_do_combo = dados["janela"]
        if self.combo % dados["a_cada"] == 0:
            self.luta.energia = min(self.luta.energia_maxima, self.luta.energia + dados["energia"])
            self._ganhar_tempo(dados["tempo"])

    def _bonus_do_combo(self):
        dados = self.regras["combo"]
        return dados["bonus_de_dano"] if self.combo >= dados["bonus_a_partir_de"] else 0

    def _atualizar_baterias(self, dt):
        """Baterias aparecem nas plataformas: subir vale a pena."""
        dados = self.regras["baterias"]
        self.proxima_bateria -= dt
        if self.proxima_bateria <= 0 and len(self.baterias) < dados["maximo"] and self.plataformas:
            self.proxima_bateria = dados["intervalo"]
            self.baterias.append({"plataforma": self.sorte.choice(self.plataformas), "t": dados["duracao"]})
        restantes = []
        for bateria in self.baterias:
            bateria["t"] -= dt
            if self._area_da_bateria(bateria).colliderect(self.ada.retangulo):
                self.luta.energia = min(self.luta.energia_maxima, self.luta.energia + dados["energia"])
                self._ganhar_tempo(dados["tempo"])
                area = self._area_da_bateria(bateria)
                self._soltar_faiscas(area.centerx, area.centery, 6, "vitrine.ciano")
            elif bateria["t"] > 0:
                restantes.append(bateria)
        self.baterias = restantes

    def _area_da_bateria(self, bateria):
        plataforma = bateria["plataforma"]
        return pygame.Rect(plataforma.centerx - TAMANHO_DA_BATERIA // 2, plataforma.top - TAMANHO_DA_BATERIA - 4, TAMANHO_DA_BATERIA, TAMANHO_DA_BATERIA)

    def _soltar_faiscas(self, x, y, quantas, nome_cor):
        for _ in range(quantas):
            self.faiscas.append({
                "x": float(x), "y": float(y), "vx": self.sorte.uniform(-70, 70), "vy": self.sorte.uniform(-90, 20),
                "t": VIDA_DA_FAISCA, "cor": nome_cor,
            })

    def _atualizar_faiscas(self, dt):
        for faisca in self.faiscas:
            faisca["x"] += faisca["vx"] * dt
            faisca["y"] += faisca["vy"] * dt
            faisca["vy"] += 240 * dt
            faisca["t"] -= dt
        self.faiscas = [f for f in self.faiscas if f["t"] > 0]

    def _atualizar_tiros(self, dt):
        vivos = []
        for tiro in self.tiros:
            tiro.atualizar(dt)
            if self._acertou(tiro):
                continue
            na_tela = self.limites.left - 20 < tiro.x < self.limites.right + 20 and -20 < tiro.y < self.chao_y
            if na_tela:
                vivos.append(tiro)
        self.tiros = vivos

    def _acertou(self, tiro):
        inimigo = self.inimigo
        if self.mecanica.tiro_parado_pelo_cenario(tiro):
            area = tiro.retangulo
            self._soltar_faiscas(area.centerx, area.centery, 3, "neutros.gelo")
            return True
        if inimigo.bloqueia(tiro):
            area = tiro.retangulo
            self._soltar_faiscas(area.centerx, area.centery, 3, "neutros.gelo")
            return True  # Satélites, anel de luz ou braços levantados: o tiro para aí, sem dano.
        alcancou = tiro.retangulo.colliderect(inimigo.corpo) or (inimigo.aberto and tiro.retangulo.colliderect(inimigo.ponto_fraco))
        if not alcancou:
            return False
        fraco = inimigo.acerta_o_ponto_fraco(tiro)
        if inimigo.protecao > 0:
            return True  # O tiro bate e some, mas o inimigo acabou de levar dano.
        # ÍRIS: qualquer tiro acerta, então o bônus do combo fica só para quem mira no vão (D69).
        bonus = self._bonus_do_combo() if fraco or "anel" not in inimigo.dados else 0
        dano = tiro.dano * (self.regras["multiplicador_ponto_fraco"] if fraco else 1) + bonus
        aplicado = self.luta.ferir_inimigo(dano)
        if aplicado > 0:
            inimigo.proteger(self.regras["protecao_do_inimigo"])
            self._contar_acerto()
            self.mecanica.ao_acertar(fraco)
            area = tiro.retangulo
            self._soltar_faiscas(area.centerx, area.centery, 8 if fraco or tiro.carregado else 4, "vila.sol")
            if fraco or tiro.carregado:
                self.impacto = self.regras["pausa_de_impacto"]
                self.tremor = self.regras["tempo_do_tremor"]
            cor_numero = "vermelho.coral" if fraco else "vila.creme"
            texto = f"{self.textos['ponto_fraco']} {aplicado}" if fraco else str(aplicado)
            self.numeros.append({"texto": texto, "x": area.centerx, "y": inimigo.corpo.top - 4, "cor": cor_numero, "tempo": TEMPO_DO_NUMERO})
        return True

    # ---------- Desenho ----------
    def camera(self):
        if self.mundo:
            return 0  # O mundo inteiro é desenhado à parte, e depois recortado.
        fracao = (self.ada.retangulo.centerx - LARGURA_TELA / 2) / (LARGURA_TELA / 2)
        return int(fracao * DESLOCAMENTO_DA_CAMERA)

    def tela_para_arena(self, posicao):
        """Converte um ponto da tela, como o do mouse, para a posição na arena."""
        if self.mundo:
            return posicao[0] * self.reducao, posicao[1] * self.reducao
        return posicao[0] + self.camera(), posicao[1]

    def _desenhar_fundo(self, tela, camera):
        if self.mundo:
            tela.blit(self.camadas[0][0], (0, 0))
            self._desenhar_plataformas(tela, camera)
            return
        for imagem, dados in self.camadas:
            largura = imagem.get_width()
            sobra = largura - LARGURA_TELA
            x = -sobra / 2 - camera * dados["velocidade"]
            y = self.chao_y - imagem.get_height() if imagem.get_height() >= self.chao_y else 0
            if "sozinha" in dados:
                x = (x - self.tempo * dados["sozinha"]) % largura
                tela.blit(imagem, (int(x) - largura, y))
            tela.blit(imagem, (int(x), y))
        x_chao = -(self.imagem_chao.get_width() - LARGURA_TELA) // 2 - camera
        tela.blit(self.imagem_chao, (x_chao, self.chao_y))
        self._desenhar_plataformas(tela, camera)

    def _desenhar_plataformas(self, tela, camera):
        for plataforma in self.dados_das_plataformas:
            if not self._plataforma_ligada(plataforma["dados"]):
                continue
            # A plataforma pisca antes de apagar: ninguém cai sem aviso.
            if self._vai_apagar(plataforma["dados"]) and int(self.tempo * 12) % 2:
                continue
            tela.blit(self.imagem_plataforma, (plataforma["retangulo"].x - camera, plataforma["retangulo"].y))

    def _desenhar_golpes(self, tela, camera):
        for golpe in self.golpes:
            area = self._area_do_golpe(golpe).move(-camera, 0)
            if golpe["forma"] == "onda":
                pygame.draw.rect(tela, cor("vila.sol"), area)
                pygame.draw.rect(tela, cor("vila.laranja_forte"), area, 1)
            elif golpe["forma"] == "marca":
                pygame.draw.rect(tela, cor("balanca.carimbo"), area)
            elif golpe["aviso"] > 0:
                if int(golpe["aviso"] * 12) % 2 == 0:
                    pygame.draw.rect(tela, cor("vitrine.rosa"), area, 1)
            else:
                pygame.draw.rect(tela, cor("vitrine.rosa"), area)
                pygame.draw.rect(tela, cor("neutros.branco"), area.inflate(-4, -4))

    def _desenhar_baterias(self, tela, camera):
        balanco = int(math.sin(self.tempo * 5) * 2)
        for bateria in self.baterias:
            # Provisório: a arte final fica na FP4 (D60).
            area = self._area_da_bateria(bateria).move(-camera, balanco)
            pygame.draw.rect(tela, cor("neutros.tinta"), area.inflate(2, 2))
            pygame.draw.rect(tela, cor("vitrine.ciano"), area)
            pygame.draw.rect(tela, cor("vitrine.vidro"), (area.centerx - 1, area.top + 1, 2, area.height - 2))

    def _desenhar_hud(self, tela):
        fonte = self.jogo.fonte
        cores = fonte.cores
        fundo = pygame.Surface((LARGURA_TELA, 26), pygame.SRCALPHA)
        fundo.fill((13, 11, 20, 170))
        tela.blit(fundo, (0, 0))
        nome = resolver(self.luta.inimigo["nome"], self.jogo.estado.nome)
        fonte.desenhar(tela, 6, 0, nome, cores["nomes"]["MODULO"])
        x_barra = max(40, 6 + fonte.largura(nome) + 4)  # Nomes longos empurram a barra, sem cobrir o texto.
        desenhar_barra(tela, (x_barra, 5, 136 - x_barra, 5), self.luta.integridade / self.luta.integridade_maxima, cor("vila.laranja_forte"))
        fonte.desenhar(tela, 142, 0, self.textos["tempo"], cores["texto"])
        desenhar_barra(tela, (176, 5, 138, 5), self.tempo_restante / self.regras["tempo"], cor("vila.sol"))
        fonte.desenhar(tela, 6, 12, self.textos["vida"], cores["texto"])
        desenhar_barra(tela, (40, 17, 96, 5), self.luta.vida / self.luta.vida_maxima, cor("verde.limao"))
        fonte.desenhar(tela, 142, 12, self.textos["energia"], cores["texto"])
        desenhar_barra(tela, (190, 17, 124, 5), self.luta.energia / self.luta.energia_maxima, cor("vitrine.ciano"))
        if self.combo >= 2:
            texto = f"{self.textos['combo']} x{self.combo}"
            nome_cor = "vermelho.coral" if self._bonus_do_combo() else "vila.sol"
            x = (LARGURA_TELA - fonte.largura(texto)) // 2
            fonte.desenhar(tela, x, 27, texto, cor(nome_cor), cor("neutros.tinta"))
        situacao = self.luta.texto_da_mecanica(self.textos)
        if situacao:
            fonte.desenhar(tela, 6, 27, situacao, cor("vila.sol"), cor("neutros.tinta"))

    def desenhar(self, tela):
        camera = self.camera()
        janela = tela
        if self.mundo:
            tela = self.tela_do_mundo
        self._desenhar_fundo(tela, camera)
        self.mecanica.desenhar_atras(tela, camera)
        self._desenhar_baterias(tela, camera)
        self._desenhar_golpes(tela, camera)
        self.inimigo.desenhar(tela, camera)
        self.ada.desenhar(tela, camera, self.luta.energia)
        for tiro in self.tiros:
            tiro.desenhar(tela, camera)
        self.mecanica.desenhar_frente(tela, camera)
        for faisca in self.faiscas:
            pygame.draw.rect(tela, cor(faisca["cor"]), (int(faisca["x"]) - camera, int(faisca["y"]), 2, 2))
        if self.mundo:
            pygame.transform.smoothscale(tela, janela.get_size(), janela)
            tela = janela
        # Os números ficam fora da redução, para continuarem fáceis de ler.
        reducao = self.reducao if self.mundo else 1
        for numero in self.numeros:
            largura = self.jogo.fonte.largura(numero["texto"])
            x = max(2, min(int(numero["x"] / reducao) - camera - largura // 2, LARGURA_TELA - largura - 2))
            self.jogo.fonte.desenhar(tela, x, int(numero["y"] / reducao), numero["texto"], cor(numero["cor"]), cor("neutros.tinta"))
        if self.tremor > 0 and not self.mundo:  # Na câmara da ÍRIS, a tela nunca treme: ela fica parada.
            forca = 2 if int(self.tempo * 40) % 2 else -2
            tela.scroll(forca, 0)
        self._desenhar_hud(tela)
        self.mecanica.desenhar_hud(tela)
        if self.preparar > 0:
            texto = self.textos["pronto"]
            x = (LARGURA_TELA - self.jogo.fonte.largura(texto)) // 2
            self.jogo.fonte.desenhar(tela, x, ALTURA_TELA // 2 - 20, texto, self.jogo.fonte.cores["destaque"], cor("neutros.tinta"))
