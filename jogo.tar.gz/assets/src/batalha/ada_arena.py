"""A Ada na arena de tiro: corre, pula, atira e carrega o Pulsor. Sprites de 24x32 (provisórios, FP4)."""

import pygame

from src.batalha.fisica import Corpo
from src.batalha.projeteis import Tiro
from src.sistemas.cores import cor
from src.sistemas.recursos import carregar_imagem

LARGURA = 12
ALTURA = 28
LARGURA_SPRITE = 24
ALTURA_SPRITE = 32
QUADROS_POR_SEGUNDO = 10
TEMPO_MOSTRANDO_O_BRACO = 0.2
ALTURA_DO_TIRO = 12  # Distância do topo do corpo até a mão com o Pulsor.


class AdaArena:
    def __init__(self, x, chao_y, regras):
        self.regras = regras
        self.corpo = Corpo(x, chao_y - ALTURA, LARGURA, ALTURA, regras["fisica"])
        nomes = (
            "parada", "correr_1", "correr_2", "correr_3", "correr_4", "pular", "cair",
            "atirar", "atirar_correndo", "atirar_pulando", "dano",
        )
        self.quadros = {nome: carregar_imagem(f"assets/sprites/ada/ada_arena_{nome}.png") for nome in nomes}
        self.sentido = 1
        self.andando = False
        self.tempo = 0.0
        self.recarga = 0.0
        self.braco = 0.0
        self.carregando = False
        self.carga = 0.0
        self.botao_de_carga = "cancelar"  # A ação que precisa continuar segurada: X ou botão direito.
        self.empurrao = 0.0
        self.sentido_empurrao = 0
        self.imune = 0.0
        self.impulso = 0.0
        self.recarga_do_impulso = 0.0
        self.multiplicador = 1.0  # CRIVO: os rótulos deixam a Ada mais lenta (D63).

    @property
    def retangulo(self):
        return self.corpo.retangulo

    def empurrar(self, de_onde_x):
        """Golpes e encostões só empurram: o perigo de verdade fica no turno do inimigo (05, seção 4).

        Devolve True se o golpe pegou. Durante o impulso e logo depois de um golpe, a Ada está imune.
        """
        if self.imune > 0:
            return False
        self.empurrao = self.regras["tempo_de_empurrao"]
        self.imune = self.empurrao + self.regras["imunidade_depois_do_golpe"]
        self.sentido_empurrao = -1 if self.retangulo.centerx < de_onde_x else 1
        return True

    def dar_impulso(self):
        """Um arranque rápido para o lado em que a Ada olha. Serve para atravessar perigos."""
        dados = self.regras["impulso"]
        if self.recarga_do_impulso > 0 or self.empurrao > 0:
            return False
        self.impulso = dados["tempo"]
        self.recarga_do_impulso = dados["recarga"]
        self.imune = max(self.imune, dados["tempo"])
        return True

    def atualizar(self, dt, direcao, limites, plataformas):
        self.tempo += dt
        self.recarga = max(0.0, self.recarga - dt)
        self.braco = max(0.0, self.braco - dt)
        self.imune = max(0.0, self.imune - dt)
        self.recarga_do_impulso = max(0.0, self.recarga_do_impulso - dt)
        if self.impulso > 0:
            self.impulso = max(0.0, self.impulso - dt)
            self.corpo.vel_y = 0.0
            self.andando = True
            self.corpo.mover(dt, self.sentido, limites, plataformas, multiplicador=self.regras["impulso"]["multiplicador"])
            return
        if self.empurrao > 0:
            self.empurrao = max(0.0, self.empurrao - dt)
            self.andando = False
            self.corpo.mover(dt, self.sentido_empurrao, limites, plataformas, multiplicador=1.4)
            return
        self.andando = direcao != 0
        if direcao:
            self.sentido = direcao
        self.corpo.mover(dt, direcao, limites, plataformas, self.multiplicador)

    def _criar_tiro(self, dados, carregado, mira=None):
        x = self.retangulo.right + 6 if self.sentido > 0 else self.retangulo.left - 6
        self.braco = TEMPO_MOSTRANDO_O_BRACO
        return Tiro(x, self.retangulo.top + ALTURA_DO_TIRO, self.sentido, dados, carregado, mira)

    def comecar_carga(self, botao):
        self.carregando = True
        self.carga = 0.0
        self.botao_de_carga = botao

    def apertar_tiro(self, tiros_na_tela, mira=None):
        """O X atira na hora e já começa a carregar. Devolve o tiro, ou None se não pode atirar."""
        self.comecar_carga("cancelar")
        return self.atirar_normal(tiros_na_tela, mira)

    def atirar_normal(self, tiros_na_tela, mira=None):
        """O tiro simples, sem carga. É o que o clique esquerdo faz."""
        if self.recarga > 0 or tiros_na_tela >= self.regras["maximo_de_tiros"]:
            return None
        self.recarga = self.regras["intervalo_entre_tiros"]
        return self._criar_tiro(self.regras["tiro_normal"], False, mira)

    def carga_pronta(self, energia):
        dados = self.regras["tiro_carregado"]
        return self.carregando and self.carga >= dados["segurar"] and energia >= dados["custo"]

    def soltar_tiro(self, luta, mira=None):
        """Soltar depois de 1 segundo dispara o tiro carregado, se houver energia."""
        tiro = None
        dados = self.regras["tiro_carregado"]
        if self.carga_pronta(luta.energia) and luta.gastar_energia(dados["custo"]):
            tiro = self._criar_tiro(dados, True, mira)
        self.carregando = False
        self.carga = 0.0
        return tiro

    def _quadro(self):
        atirando = self.braco > 0
        if self.empurrao > 0:
            return self.quadros["dano"]
        if not self.corpo.no_chao:
            if atirando:
                return self.quadros["atirar_pulando"]
            return self.quadros["pular" if self.corpo.vel_y < 0 else "cair"]
        if self.andando:
            if atirando:
                return self.quadros["atirar_correndo"]
            return self.quadros[f"correr_{int(self.tempo * QUADROS_POR_SEGUNDO) % 4 + 1}"]
        return self.quadros["atirar" if atirando else "parada"]

    def desenhar(self, tela, camera, energia):
        imagem = self._quadro()
        if self.sentido < 0:
            imagem = pygame.transform.flip(imagem, True, False)
        x = self.retangulo.centerx - LARGURA_SPRITE // 2 - camera
        y = self.retangulo.bottom - ALTURA_SPRITE + 1
        # Durante a imunidade, a Ada pisca, para o jogador saber que está protegido.
        if self.imune <= 0 or self.impulso > 0 or int(self.tempo * 20) % 2:
            tela.blit(imagem, (x, y))
        if self.impulso > 0:
            rastro = -self.sentido * 10
            pygame.draw.line(tela, cor("vitrine.vidro"), (x + 12 + rastro, y + 12), (x + 12 + 2 * rastro, y + 12))
            pygame.draw.line(tela, cor("vitrine.vidro"), (x + 12 + rastro, y + 22), (x + 12 + 2 * rastro, y + 22))
        if self.carregando and self.carga > 0.2:
            self._desenhar_carga(tela, camera, energia)

    def _desenhar_carga(self, tela, camera, energia):
        """Um brilho em volta do Pulsor. Quando o tiro está pronto, ele pulsa em duas cores."""
        cx = (self.retangulo.right + 5 if self.sentido > 0 else self.retangulo.left - 5) - camera
        cy = self.retangulo.top + ALTURA_DO_TIRO
        dados = self.regras["tiro_carregado"]
        if energia < dados["custo"]:
            return
        fracao = min(1.0, self.carga / dados["segurar"])
        raio = 2 + int(fracao * 4)
        pronta = self.carga_pronta(energia)
        nome = "vitrine.vidro" if pronta and int(self.tempo * 16) % 2 else "vitrine.ciano"
        pygame.draw.circle(tela, cor(nome), (cx, cy), raio, 1)
