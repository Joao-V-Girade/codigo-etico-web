"""A mecânica única de cada chefe na tela de COMBATE (D63). Os números ficam em "mecanica", em data/inimigos.json.

- CRIVO, Rótulos que pesam: cada golpe cola um rótulo. A arena é uma balança: o prato com a Ada desce e o outro sobe.
- VIGIA, Esconde-esconde: um cone de visão enche o Dossiê. O olho só abre quando ela perde a Ada de vista.
- ECO, Checar a manchete: atirar nos BOATOS baixa o Engajamento e atirar nos FATOS sobe. Em zero, ele fica em silêncio, exposto.
- ÍRIS, Piloto Automático: ela não sai do lugar e lança fios que puxam a Ada. Cortar 3 fios para o anel que protege o olho.
- Exo-Desligador, Investida nos pilares: atrair o exo para um pilar faz ele empacar e mostrar os tubos de vapor.

A situação de cada mecânica fica guardada na Luta (regras_batalha.py), porque ela muda também o turno do inimigo.
"""

import math
import random

import pygame

from src.sistemas.cores import cor

RAIOS_DO_CONE = 13
CINZA_DAS_COPIAS = (150, 150, 160, 255)


class MecanicaArena:
    """Quem não tem mecânica própria, como o ZIM, usa esta: nada muda."""

    def __init__(self, arena):
        self.arena = arena
        self.luta = arena.luta
        self.dados = arena.luta.mecanica
        self.sorte = random.Random()

    def atualizar(self, dt):
        pass

    def preparar(self):
        """Chamada uma vez, com a arena já montada."""

    def tiro_parado_pelo_cenario(self, tiro):
        return False

    def ritmo_da_orbita(self):
        return 1.0

    def ao_acertar(self, fraco):
        pass

    def ao_atingir_ada(self):
        pass

    def ao_terminar(self):
        pass

    def pode_observar(self):
        return True

    def forca_do_vento(self):
        return 1.0

    def y_do_prato(self, dados):
        return dados["y"]

    def desenhar_atras(self, tela, camera):
        pass

    def desenhar_frente(self, tela, camera):
        pass

    def desenhar_hud(self, tela):
        """O que fica preso à tela, mesmo quando a câmera anda."""


class RotulosQuePesam(MecanicaArena):
    """CRIVO: quem é atingido carrega o rótulo. A balança mostra o peso: com rótulos, o prato afunda mais rápido."""

    def __init__(self, arena):
        super().__init__(arena)
        self.inclinacao = 0.0  # De -1 a 1. Positivo: o prato da direita está mais baixo.

    def _prato_da_ada(self):
        corpo = self.arena.ada.corpo
        if not corpo.no_chao:
            return 0
        for plataforma in self.arena.dados_das_plataformas:
            lado = plataforma["dados"].get("prato")
            r = plataforma["retangulo"]
            if lado and abs(corpo.y + corpo.altura - r.top) <= 1 and corpo.x + corpo.largura > r.left and corpo.x < r.right:
                return lado
        return 0

    def atualizar(self, dt):
        ada = self.arena.ada
        ada.multiplicador = self.luta.multiplicador_da_velocidade
        ada.corpo.forca_do_pulo = self.arena.regras["fisica"]["pulo"] * self.luta.multiplicador_do_pulo
        lado = self._prato_da_ada()
        if lado:
            velocidade = self.dados["afundar"] * (1 + self.luta.rotulos * self.dados["afundar_por_rotulo"])
            destino = float(lado)
        else:
            velocidade = self.dados["voltar"]
            destino = 0.0
        passo = velocidade * dt
        self.inclinacao += max(-passo, min(destino - self.inclinacao, passo))

    def y_do_prato(self, dados):
        return int(dados["y"] + self.inclinacao * dados["prato"] * self.dados["curso_do_prato"])

    def ao_acertar(self, fraco):
        if fraco:
            self.luta.tirar_rotulo()

    def ao_atingir_ada(self):
        self.luta.colar_rotulo()

    def desenhar_frente(self, tela, camera):
        # Os rótulos ficam visíveis na própria Ada.
        ada = self.arena.ada.retangulo
        for numero in range(self.luta.rotulos):
            x = ada.left - 2 + numero * 6 - camera
            pygame.draw.rect(tela, cor("balanca.areia"), (x, ada.top - 7, 5, 5))
            pygame.draw.rect(tela, cor("balanca.carimbo"), (x, ada.top - 7, 5, 5), 1)


class EscondeEsconde(MecanicaArena):
    """VIGIA: o cone registra quem está na luz. Atrás dos painéis, ela perde a Ada e o olho se abre, procurando."""

    def __init__(self, arena):
        super().__init__(arena)
        chao = arena.chao_y
        self.paineis = [
            pygame.Rect(p["x"], p.get("y", chao - p["altura"]), p["largura"], p["altura"])
            for p in arena.cenario["paineis"]
        ]
        self.angulos = [math.pi / 2, math.pi / 2]
        self.sem_ver = 0.0
        self.visto = False
        self.espera_do_olho = 0.0
        self.espera_do_feixe = 0.0

    def _origens(self):
        inimigo = self.arena.inimigo
        origens = [inimigo.corpo.center]
        if self.luta.em_fase2:
            satelites = inimigo._satelites()
            if satelites:
                origens.append(satelites[0].center)
        return origens

    def _cone_ve(self, origem, angulo, alvo):
        dx, dy = alvo[0] - origem[0], alvo[1] - origem[1]
        if math.hypot(dx, dy) > self.dados["alcance"]:
            return False
        diferenca = abs((math.atan2(dy, dx) - angulo + math.pi) % math.tau - math.pi)
        if diferenca > self.dados["abertura"] / 2:
            return False
        return not any(painel.clipline(origem, alvo) for painel in self.paineis)

    def atualizar(self, dt):
        alvo = self.arena.ada.retangulo.center
        tempo = self.arena.tempo
        self.visto = False
        for indice, origem in enumerate(self._origens()):
            if self._cone_ve(origem, self.angulos[indice], alvo):
                self.visto = True
        for indice, origem in enumerate(self._origens()):
            if self.visto:
                destino = math.atan2(alvo[1] - origem[1], alvo[0] - origem[0])
            else:
                destino = math.pi / 2 + math.sin(tempo * self.dados["ritmo_da_varredura"] + indice * 2) * self.dados["varredura"]
            diferenca = (destino - self.angulos[indice] + math.pi) % math.tau - math.pi
            passo = self.dados["giro"] * dt
            self.angulos[indice] += max(-passo, min(diferenca, passo))

        self.espera_do_olho = max(0.0, self.espera_do_olho - dt)
        self.espera_do_feixe = max(0.0, self.espera_do_feixe - dt)
        if self.visto:
            self.sem_ver = 0.0
            self.luta.registrar_no_dossie(self.dados["registro_por_segundo"] * dt)
        else:
            self.sem_ver += dt
            if self.sem_ver >= self.dados["tempo_para_perder"] and self.espera_do_olho <= 0:
                # Ela perdeu a Ada: abre o olho para procurar. Este é o momento de sair e atirar.
                self.arena.inimigo.tempo_aberto = self.dados["olho_aberto"]
                self.espera_do_olho = self.dados["olho_aberto"] + self.dados["recarga_do_olho"]
        if self.luta.dossie_cheio and self.visto and self.espera_do_feixe <= 0:
            self.espera_do_feixe = self.dados["recarga_do_feixe"]
            self.arena.inimigo.golpes_pedidos.append(self.dados["feixe"])

    def tiro_parado_pelo_cenario(self, tiro):
        return any(painel.colliderect(tiro.retangulo) for painel in self.paineis)

    def pode_observar(self):
        return self.visto

    def _pontos_do_cone(self, origem, angulo):
        """O cone é desenhado raio por raio, para a luz parar nos painéis, como acontece de verdade."""
        pontos = [origem]
        for numero in range(RAIOS_DO_CONE):
            direcao = angulo - self.dados["abertura"] / 2 + self.dados["abertura"] * numero / (RAIOS_DO_CONE - 1)
            fim = (origem[0] + math.cos(direcao) * self.dados["alcance"], origem[1] + math.sin(direcao) * self.dados["alcance"])
            fim = (fim[0], min(fim[1], self.arena.chao_y))
            for painel in self.paineis:
                trecho = painel.clipline(origem, fim)
                if trecho:
                    fim = trecho[0]
            pontos.append(fim)
        return pontos

    def desenhar_atras(self, tela, camera):
        camada = pygame.Surface(tela.get_size(), pygame.SRCALPHA)
        for indice, origem in enumerate(self._origens()):
            pontos = [(x - camera, y) for x, y in self._pontos_do_cone(origem, self.angulos[indice])]
            pygame.draw.polygon(camada, (255, 95, 168, 90) if self.visto else (247, 210, 122, 70), pontos)
        tela.blit(camada, (0, 0))

    def desenhar_frente(self, tela, camera):
        camada = pygame.Surface(tela.get_size(), pygame.SRCALPHA)
        for painel in self.paineis:
            pygame.draw.rect(camada, (40, 52, 70, 215), painel.move(-camera, 0))
        tela.blit(camada, (0, 0))
        for painel in self.paineis:
            pygame.draw.rect(tela, cor("vitrine.ciano"), painel.move(-camera, 0), 1)
        if self.arena.inimigo.tempo_aberto > 0:
            corpo = self.arena.inimigo.corpo
            fonte = self.arena.jogo.fonte
            texto = self.arena.textos["vigia_procurando"]
            fonte.desenhar(tela, corpo.centerx - fonte.largura(texto) // 2 - camera, max(27, corpo.top - 12), texto, cor("verde.limao"), cor("neutros.tinta"))


class ChecarManchetes(MecanicaArena):
    """ECO: ele passeia pelo palco do auditório. Manchetes passam pela arena, e o tiro decide o que se espalha.

    Atirar num BOATO desmente e baixa o Engajamento. Atirar num FATO sobe, porque silenciou a verdade. Com o Engajamento
    em zero, ele fica em silêncio: qualquer tiro nele vale o dobro. Depois, ele volta a gritar. Sem cópias: dá para
    ver tudo o que está acontecendo.
    """

    LARGURA = 40
    ALTURA = 12

    def __init__(self, arena):
        super().__init__(arena)
        self.linhas = arena.cenario["linhas_de_manchete"]
        self.alvos = []
        self.subida = self.dados["subida"]
        self.silenciado = False

    def preparar(self):
        self.luta.engajamento = max(1, self.luta.engajamento)
        for _ in range(self.dados["manchetes"]):
            self._nova_manchete()

    def _nova_manchete(self):
        ocupadas = {alvo["y"] for alvo in self.alvos}
        linhas = [y for y in self.linhas if y not in ocupadas] or self.linhas
        lado = self.sorte.choice((-1, 1))
        limites = self.arena.limites
        tem_boato = any(not alvo["fato"] for alvo in self.alvos)
        self.alvos.append({
            "x": float(limites.right if lado < 0 else limites.left - self.LARGURA),
            "y": self.sorte.choice(linhas),
            "vx": lado * self.dados["velocidade_das_manchetes"],
            "fato": tem_boato and self.sorte.random() < self.dados["parte_de_fatos"],
        })

    def _area(self, alvo):
        return pygame.Rect(int(alvo["x"]), alvo["y"] - self.ALTURA // 2, self.LARGURA, self.ALTURA)

    def atualizar(self, dt):
        inimigo = self.arena.inimigo
        limites = self.arena.limites
        for alvo in list(self.alvos):
            alvo["x"] += alvo["vx"] * dt
            if alvo["x"] > limites.right or alvo["x"] < limites.left - self.LARGURA:
                self.alvos.remove(alvo)
                self._nova_manchete()
        if self.silenciado:
            if inimigo.tempo_aberto <= 0:
                self.silenciado = False
                self.luta.engajamento = self.dados["volta_do_silencio"]
            return
        if self.luta.engajamento <= 0:
            self.silenciado = True
            inimigo.tempo_aberto = self.dados["silencio"]
            return
        self.subida -= dt
        if self.subida <= 0:
            self.subida = self.dados["subida"]
            self.luta.subir_engajamento()

    def tiro_parado_pelo_cenario(self, tiro):
        for alvo in self.alvos:
            if self._area(alvo).colliderect(tiro.retangulo):
                self.alvos.remove(alvo)
                self._nova_manchete()
                area = tiro.retangulo
                if alvo["fato"]:
                    self.luta.subir_engajamento()
                    texto, nome_cor = self.arena.textos["viralizou"], "vitrine.rosa"
                else:
                    self.luta.baixar_engajamento()
                    texto, nome_cor = self.arena.textos["desmentido"], "vila.sol"
                self.arena._soltar_faiscas(area.centerx, area.centery, 5, nome_cor)
                self.arena.numeros.append({"texto": texto, "x": area.centerx, "y": alvo["y"] - 12, "cor": nome_cor, "tempo": 0.7})
                return True
        return False

    def desenhar_frente(self, tela, camera):
        fonte = self.arena.jogo.fonte
        for alvo in self.alvos:
            r = self._area(alvo).move(-camera, 0)
            if alvo["fato"]:
                pygame.draw.rect(tela, cor("neutros.branco"), r)
                pygame.draw.rect(tela, cor("ceu.azul"), r, 1)
                fonte.desenhar(tela, r.left + 9, r.top - 2, self.arena.textos["fato"], cor("ceu.azul"))
            else:
                pygame.draw.rect(tela, cor("vitrine.rosa"), r)
                fonte.desenhar(tela, r.left + 4, r.top - 2, self.arena.textos["boato"], cor("neutros.branco"))
        if self.silenciado:
            corpo = self.arena.inimigo.corpo
            texto = self.arena.textos["silencio"]
            fonte.desenhar(tela, corpo.centerx - fonte.largura(texto) // 2 - camera, corpo.bottom + 2, texto, cor("vila.sol"), cor("neutros.tinta"))


class PilotoAutomatico(MecanicaArena):
    """ÍRIS: o Lume pede licença, e ela decide por você. Fios puxam a Ada para o olho e baixam a AUTONOMIA.

    O fio só puxa: o jogador sempre consegue reagir. O impulso solta a Ada, e um tiro corta qualquer fio. Cortar 3 para o
    anel. Por isso, o jogador passa a querer que ela atire. A cada turno, ela também corta a plataforma menos usada.

    Na segunda forma (D69), os fios miram para onde a Ada está indo, a Onda do Núcleo empurra para o vazio e cortar 3 fios
    também instala uma REVISÃO: o próximo turno dela tem um ataque a menos.

    A arena é a Câmara do Núcleo, bem maior que o normal, e aparece inteira na tela, que nunca anda. O olho fica no centro, com plataformas
    girando em volta, duas torres nas pontas e correntes de dados que levam a Ada para cima. Não há chão: quem cai volta
    para o último lugar onde pisou, mas perde AUTONOMIA.
    """

    def __init__(self, arena):
        super().__init__(arena)
        self.fios = []
        self.cortes = 0
        self.proximo_fio = self.dados["primeiro_fio"]
        self.uso = {}
        self.camada_vermelha = None
        self.camada_da_corrente = None
        self.velocidade_da_ada = (0.0, 0.0)
        self.ultima_posicao = None
        self.ondas = []
        self.proxima_onda = self.dados["primeira_onda"]

    def ritmo_da_orbita(self):
        return self.dados["ritmo_forma2"] if self.luta.forma == 2 else 1.0

    def preparar(self):
        # A Ada começa numa torre: aqui não há chão.
        self.correntes = [pygame.Rect(zona) for zona in self.arena.cenario["correntes"]]
        self.apoio = next(p["retangulo"] for p in self.arena.dados_das_plataformas if not p["dados"].get("orbita"))
        self._voltar_ao_apoio()

    def _voltar_ao_apoio(self):
        corpo = self.arena.ada.corpo
        corpo.x, corpo.y = float(self.apoio.centerx), float(self.apoio.top - corpo.altura)
        corpo.vel_y = 0.0
        corpo.no_chao = True

    def _maximo_de_fios(self):
        return self.dados["fios_forma2"] if self.luta.forma == 2 else self.dados["fios_forma1"]

    def _pontas(self, fio):
        return self.arena.inimigo.corpo.center, fio["ponta"]

    def _lancar(self):
        x, y = self.arena.ada.retangulo.center
        if self.luta.forma == 2:
            # O fio mira para onde a Ada está indo: quem mantém a direção é pego, e quem muda escapa.
            previsao = self.dados["previsao_do_fio"]
            limites = self.arena.limites
            x = max(limites.left, min(x + self.velocidade_da_ada[0] * previsao, limites.right))
            y = max(limites.top, min(y + self.velocidade_da_ada[1] * previsao, self.arena.chao_y))
        self.fios.append({"estado": "aviso", "t": self.dados["aviso_do_fio"], "ponta": (int(x), int(y))})

    def _cortar(self, fio):
        self.fios.remove(fio)
        self.cortes += 1
        x, y = fio["ponta"]
        self.arena._soltar_faiscas(x, y, 5, "vitrine.vidro")
        if self.cortes >= self.dados["cortes_para_abrir"]:
            self.cortes = 0
            self.arena.inimigo.tempo_aberto = self.dados["olho_exposto"]
            self.luta.instalar_revisao()

    def _contar_uso(self, dt):
        corpo = self.arena.ada.corpo
        if not corpo.no_chao:
            return
        for plataforma in self.arena.dados_das_plataformas:
            r = plataforma["retangulo"]
            if abs(corpo.y + corpo.altura - r.top) <= 1 and corpo.x + corpo.largura > r.left and corpo.x < r.right:
                self.uso[plataforma["indice"]] = self.uso.get(plataforma["indice"], 0.0) + dt
                self.apoio = r

    def _cair_no_vazio(self):
        """Não há chão: quem cai volta para o último lugar onde pisou, e a queda custa AUTONOMIA."""
        corpo = self.arena.ada.corpo
        if corpo.y + corpo.altura < self.arena.chao_y:
            return
        self._voltar_ao_apoio()
        self.luta.perder_autonomia(self.dados["perda_na_queda"])
        self.arena.combo = 0
        self.arena.ada.imune = max(self.arena.ada.imune, self.dados["imunidade_na_volta"])
        self.arena.tremor = self.arena.regras["tempo_do_tremor"]

    def _usar_correntes(self):
        """Dentro de uma corrente de dados, a Ada sobe sem pular. É o jeito de cruzar a altura da câmara."""
        corpo = self.arena.ada.corpo
        if corpo.retangulo.collidelist(self.correntes) != -1:
            corpo.vel_y = -self.dados["subida_da_corrente"]
            corpo.no_chao = False
            corpo.pulos_no_ar = corpo.pulos_no_ar_maximo

    def _medir_velocidade(self, dt):
        atual = self.arena.ada.retangulo.center
        if self.ultima_posicao is not None and dt > 0:
            self.velocidade_da_ada = ((atual[0] - self.ultima_posicao[0]) / dt, (atual[1] - self.ultima_posicao[1]) / dt)
        self.ultima_posicao = atual

    def _atualizar_ondas(self, dt):
        """Segunda forma: um anel de luz sai do olho, com aviso. Não tira vida, mas empurra para o vazio."""
        self.proxima_onda -= dt
        if self.proxima_onda <= 0:
            self.proxima_onda = self.dados["intervalo_da_onda"]
            self.ondas.append({"aviso": self.dados["aviso_da_onda"], "raio": float(self.dados["raio_inicial_da_onda"]), "pegou": False})
        olho = self.arena.inimigo.corpo.center
        ada = self.arena.ada
        vivas = []
        for onda in self.ondas:
            if onda["aviso"] > 0:
                onda["aviso"] -= dt
                vivas.append(onda)
                continue
            onda["raio"] += self.dados["velocidade_da_onda"] * dt
            distancia = math.hypot(ada.retangulo.centerx - olho[0], ada.retangulo.centery - olho[1])
            if not onda["pegou"] and abs(distancia - onda["raio"]) <= self.dados["largura_da_onda"]:
                onda["pegou"] = True
                self.arena._atingir_ada(olho[0])
            if onda["raio"] < self.dados["raio_final_da_onda"]:
                vivas.append(onda)
        self.ondas = vivas

    def atualizar(self, dt):
        self._cair_no_vazio()
        self._usar_correntes()
        self._contar_uso(dt)
        self._medir_velocidade(dt)
        if self.luta.forma == 2:
            self._atualizar_ondas(dt)
        ada = self.arena.ada
        self.proximo_fio -= dt
        if self.proximo_fio <= 0 and len(self.fios) < self._maximo_de_fios():
            self.proximo_fio = self.dados["intervalo_dos_fios"]
            self._lancar()
        for fio in list(self.fios):
            fio["t"] -= dt
            if fio["estado"] == "aviso" and fio["t"] <= 0:
                pegou = ada.retangulo.inflate(6, 6).collidepoint(fio["ponta"]) and ada.imune <= 0
                fio["estado"], fio["t"] = ("preso", 99.0) if pegou else ("solto", self.dados["tempo_do_fio_solto"])
            elif fio["estado"] == "solto" and fio["t"] <= 0:
                self.fios.remove(fio)
            elif fio["estado"] == "preso":
                if ada.impulso > 0:
                    self._cortar(fio)  # O impulso solta a Ada e conta como corte.
                    continue
                fio["ponta"] = ada.retangulo.center
                self._puxar(dt)

    def _puxar(self, dt):
        corpo = self.arena.ada.corpo
        olho = self.arena.inimigo.corpo.center
        forca = self.dados["puxao_na_arena"] * dt
        corpo.x += forca if olho[0] > corpo.x else -forca
        corpo.x = max(self.arena.limites.left, min(corpo.x, self.arena.limites.right - corpo.largura))
        self.luta.perder_autonomia(self.dados["queda_da_autonomia"] * dt)

    def tiro_parado_pelo_cenario(self, tiro):
        area = tiro.retangulo
        for fio in self.fios:
            if fio["estado"] != "aviso" and area.clipline(*self._pontas(fio)):
                self._cortar(fio)
                return True
        return False

    def ao_terminar(self):
        """Depois da transformação, a cada turno, ela corta a plataforma que menos serve."""
        if not self.luta.em_fase2:
            return
        if self.luta.plataforma_marcada is not None:
            self.luta.plataformas_cortadas.add(self.luta.plataforma_marcada)
            self.luta.plataforma_marcada = None
        candidatas = [
            p["indice"]
            for p in self.arena.dados_das_plataformas
            if p["dados"].get("cortavel") and p["indice"] not in self.luta.plataformas_cortadas
        ]
        if candidatas:
            self.luta.plataforma_marcada = min(candidatas, key=lambda indice: self.uso.get(indice, 0.0))

    def desenhar_atras(self, tela, camera):
        # As camadas transparentes são feitas uma vez só: a arena é grande, e refazer a cada quadro pesaria na web.
        if self.luta.forma == 2:
            if self.camada_vermelha is None:
                self.camada_vermelha = pygame.Surface(tela.get_size(), pygame.SRCALPHA)
                self.camada_vermelha.fill((180, 30, 40, 70))
            tela.blit(self.camada_vermelha, (0, 0))
        for zona in self.correntes:
            if self.camada_da_corrente is None:
                self.camada_da_corrente = pygame.Surface(zona.size, pygame.SRCALPHA)
                self.camada_da_corrente.fill((120, 220, 240, 40))
            tela.blit(self.camada_da_corrente, zona.topleft)
        deslocamento = int(self.arena.tempo * 90)
        for zona in self.correntes:
            for y in range(zona.bottom - (deslocamento % 24), zona.top, -24):
                pygame.draw.polygon(tela, cor("vitrine.vidro"), [(zona.centerx, y - 6), (zona.centerx - 5, y), (zona.centerx + 5, y)], 1)

    def desenhar_frente(self, tela, camera):
        olho = self.arena.inimigo.corpo.center
        for onda in self.ondas:
            if onda["aviso"] > 0:
                if int(onda["aviso"] * 12) % 2 == 0:
                    pygame.draw.circle(tela, cor("vitrine.rosa"), (olho[0] - camera, olho[1]), int(onda["raio"]), 2)
            else:
                pygame.draw.circle(tela, cor("vitrine.rosa"), (olho[0] - camera, olho[1]), int(onda["raio"]), self.dados["largura_da_onda"] // 2)
        for fio in self.fios:
            inicio, fim = self._pontas(fio)
            inicio, fim = (inicio[0] - camera, inicio[1]), (fim[0] - camera, fim[1])
            if fio["estado"] == "aviso":
                if int(fio["t"] * 12) % 2 == 0:
                    pygame.draw.line(tela, cor("vitrine.rosa"), inicio, fim, 3)
                    pygame.draw.circle(tela, cor("vitrine.rosa"), fim, 10, 3)
            else:
                pygame.draw.line(tela, cor("vitrine.vidro"), inicio, fim, 4)
        marcada = self.luta.plataforma_marcada
        for plataforma in self.arena.dados_das_plataformas:
            if plataforma["indice"] == marcada and int(self.arena.tempo * 8) % 2:
                pygame.draw.rect(tela, cor("vitrine.rosa"), plataforma["retangulo"].move(-camera, 0), 1)

    def desenhar_hud(self, tela):
        fonte = self.arena.jogo.fonte
        texto = f"{self.arena.textos['cortes']} {self.cortes}/{self.dados['cortes_para_abrir']}"
        fonte.desenhar(tela, 6, 39, texto, cor("vitrine.vidro"), cor("neutros.tinta"))
        if self.luta.revisao_pendente:
            fonte.desenhar(tela, 6, 51, self.arena.textos["revisao"], cor("vila.sol"), cor("neutros.tinta"))


class InvestidaNosPilares(MecanicaArena):
    """Exo: o padrão é fixo, porque quem pilota é uma pessoa. Bater num pilar faz ele empacar e esquenta o exo."""

    def __init__(self, arena):
        super().__init__(arena)
        altura = self.dados["altura_do_pilar"]
        largura = self.dados["largura_do_pilar"]
        self.pilares = [{"retangulo": pygame.Rect(x, arena.chao_y - altura, largura, altura), "vida": self.dados["vida_do_pilar"]} for x in arena.cenario["pilares"]]

    def _pilares_de_pe(self):
        return [p for p in self.pilares if p["vida"] > 0]

    def forca_do_vento(self):
        return self.dados["vento_fase2"] if self.luta.em_fase2 else 1.0

    def atualizar(self, dt):
        inimigo = self.arena.inimigo
        if not inimigo.em_investida:
            return
        corpo = inimigo.corpo
        for pilar in self._pilares_de_pe():
            if corpo.colliderect(pilar["retangulo"]):
                pilar["vida"] -= 1
                self.luta.exo_quente = True
                self.arena.tremor = self.arena.regras["tempo_do_tremor"] * 2
                self.arena._soltar_faiscas(pilar["retangulo"].centerx, corpo.centery, 10, "vila.sol")
                inimigo.empacar(self.dados["empacado_no_pilar"])
                return
        limites = self.arena.limites
        if (corpo.left <= limites.left and inimigo.sentido < 0) or (corpo.right >= limites.right and inimigo.sentido > 0):
            inimigo.empacar(self.dados["empacado_na_parede"])

    def tiro_parado_pelo_cenario(self, tiro):
        return any(p["retangulo"].colliderect(tiro.retangulo) for p in self._pilares_de_pe())

    def desenhar_atras(self, tela, camera):
        for pilar in self._pilares_de_pe():
            r = pilar["retangulo"].move(-camera, 0)
            pygame.draw.rect(tela, cor("neutros.cinza"), r)
            pygame.draw.rect(tela, cor("neutros.chumbo"), r, 1)
            if pilar["vida"] < self.dados["vida_do_pilar"]:
                pygame.draw.line(tela, cor("neutros.tinta"), (r.left + 2, r.top + 6), (r.right - 3, r.top + 18))
        inimigo = self.arena.inimigo
        if inimigo.preparando_investida and int(self.arena.tempo * 10) % 2 == 0:
            # O aviso: uma faixa no chão, do exo até a parede, para o lado onde ele vai correr.
            lado = 1 if self.arena.ada.retangulo.centerx >= inimigo.corpo.centerx else -1
            x = inimigo.corpo.centerx - camera
            fim = self.arena.limites.right - camera if lado > 0 else self.arena.limites.left - camera
            pygame.draw.rect(tela, cor("vitrine.rosa"), (min(x, fim), self.arena.chao_y - 2, abs(fim - x), 2))

    def desenhar_frente(self, tela, camera):
        # A biruta mostra para onde o vento sopra. Pisca quando ele está prestes a virar.
        vento = self.arena.cenario.get("vento")
        if not vento:
            return
        onda = math.sin(self.arena.tempo * math.tau / vento["periodo"])
        x, y = 160 - camera, 40
        if abs(onda) < 0.3 and int(self.arena.tempo * 10) % 2:
            return
        lado = 1 if onda >= 0 else -1
        pygame.draw.line(tela, cor("neutros.gelo"), (x, y), (x, y + 14))
        pygame.draw.polygon(tela, cor("vila.laranja_forte"), [(x, y), (x, y + 6), (x + lado * 14, y + 3)])


MECANICAS = {
    "rotulos": RotulosQuePesam,
    "dossie": EscondeEsconde,
    "engajamento": ChecarManchetes,
    "autonomia": PilotoAutomatico,
    "pilares": InvestidaNosPilares,
}


def criar_mecanica(arena):
    tipo = arena.luta.mecanica.get("tipo")
    return MECANICAS.get(tipo, MecanicaArena)(arena)
