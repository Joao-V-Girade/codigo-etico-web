"""Os tiros do Pulsor na arena."""

import pygame

from src.sistemas.recursos import carregar_imagem


class Tiro:
    def __init__(self, x, y, sentido, dados, carregado, mira=None):
        """mira é uma direção (x, y) de tamanho 1. Sem mira, o tiro vai reto para o lado da Ada."""
        self.x = float(x)
        self.y = float(y)
        self.sentido = sentido
        self.velocidade = dados["velocidade"]
        direcao = mira or (sentido, 0.0)
        self.vx = direcao[0] * self.velocidade
        self.vy = direcao[1] * self.velocidade
        self.dano = dados["dano"]
        self.carregado = carregado
        self.idade = 0.0
        self.avaliado = False  # O inimigo decide só uma vez se desvia deste tiro.
        self.origem = "chao"  # De onde saiu: serve para a memória dos chefes.
        nome = "tiro_carregado" if carregado else "tiro_normal"
        self.imagem = carregar_imagem(f"assets/sprites/ataques/{nome}.png")
        if sentido < 0:
            self.imagem = pygame.transform.flip(self.imagem, True, False)
        self.largura, self.altura = self.imagem.get_size()
        self.y -= self.altura / 2
        if sentido < 0:
            self.x -= self.largura

    @property
    def retangulo(self):
        return pygame.Rect(int(self.x), int(self.y), self.largura, self.altura)

    def atualizar(self, dt):
        self.idade += dt
        self.x += self.vx * dt
        self.y += self.vy * dt

    def desenhar(self, tela, camera):
        tela.blit(self.imagem, (int(self.x) - camera, int(self.y)))
