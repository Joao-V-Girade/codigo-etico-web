"""Os 10 ataques que a ÍRIS só usa na segunda forma (D69). Cada um pede uma coisa que nenhum outro ataque do jogo pede.

11. Fio-Guia: correr contra um puxão, sem encostar no pilar de luz.
12. Rota Ótima: mudar de direção, porque a mira calcula onde você vai estar.
13. Decisão em Lote: memorizar a ordem em que os pedaços do chão vão explodir.
14. Caixa-Preta: deduzir a regra, porque o que entra alto sai baixo.
15. Aguardando Aprovação: parar de andar quando ela manda, e correr logo depois.
16. Isso Também É Dado: não voltar pelo mesmo caminho, porque seus passos viram perigo.
17. Câmara em Órbita: pegar carona nas plataformas, porque o chão queima.
18. Quem Paga a Conta: escolher entre perder vida e perder AUTONOMIA.
19. Removendo Limites: cair para o teto e achar um lugar seguro antes de chegar lá.
20. Teto de Gastos: ler o relevo do teto que desce.

O tema é o mesmo da luta: um sistema que só persegue eficiência e decide pelas pessoas.
"""

import math

import pygame

from src.batalha.padroes import Padrao
from src.batalha.padroes_chefes import ComItens, _desenhar_texto
from src.batalha.padroes_iris import EmOndas, _olho, _raio
from src.sistemas.cores import cor

ALCANCE_DA_LINHA = 260


# 11
class FioGuia(Padrao):
    """Fios puxam a mini Ada para um pilar de luz no meio da caixa. No ar, ela escapa do puxão por um instante."""

    depende_do_jogador = True
    LARGURA_DO_PILAR = 14

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.golpes = []
        self.proximo = self.dados["aviso"]

    def _pilar(self):
        return pygame.Rect(self.caixa.centerx - self.LARGURA_DO_PILAR // 2, self.caixa.top, self.LARGURA_DO_PILAR, self.caixa.height)

    def _puxando(self):
        return self.dados["aviso"] <= self.tempo < self.dados["duracao"] and self.jogador is not None

    def empurrao(self):
        if not self._puxando() or self.jogador[1] < self.caixa.bottom - 12:
            return 0.0  # No ar, o fio não puxa: o pulo solta por um instante.
        lado = 1 if self.caixa.centerx > self.jogador[0] else -1
        return lado * self.dados["fios"] * self.dados["forca_do_fio"]

    def _novo_golpe(self):
        metade = self.dados["largura_do_golpe"] // 2
        c = self.caixa
        # O golpe nunca cai colado no pilar: entre os dois, sempre cabe a mini Ada.
        distancia_minima = self.LARGURA_DO_PILAR // 2 + metade + 24
        lado = self.sorte.choice((-1, 1))
        if self.alvo:
            x, self.alvo = self.alvo[0], None
            if abs(x - c.centerx) < distancia_minima:
                x = c.centerx + lado * distancia_minima
        else:
            x = c.centerx + lado * self.sorte.randint(distancia_minima, c.width // 2 - metade)
        self.golpes.append({"x": x, "aviso": self.dados["aviso"], "ativo": self.dados["ativo"]})

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proximo -= dt
        if self.proximo <= 0 and self.tempo < self.dados["duracao"]:
            self.proximo += self.dados["intervalo"]
            self._novo_golpe()
        for golpe in self.golpes:
            if golpe["aviso"] > 0:
                golpe["aviso"] -= dt
            else:
                golpe["ativo"] -= dt
        self.golpes = [g for g in self.golpes if g["ativo"] > 0]

    def terminou(self):
        return self.tempo >= self.dados["duracao"] and not self.golpes

    def _area_do_golpe(self, golpe):
        largura = self.dados["largura_do_golpe"]
        return pygame.Rect(golpe["x"] - largura // 2, self.caixa.top, largura, self.caixa.height)

    def perigos(self):
        lista = [self._area_do_golpe(g) for g in self.golpes if g["aviso"] <= 0]
        if self.dados["aviso"] <= self.tempo < self.dados["duracao"]:
            lista.append(self._pilar())
        return lista

    def desenhar(self, tela):
        pilar = self._pilar()
        if self.tempo < self.dados["aviso"]:
            if int(self.tempo * 12) % 2 == 0:
                pygame.draw.rect(tela, cor("vitrine.rosa"), pilar, 1)
        elif self.tempo < self.dados["duracao"]:
            pygame.draw.rect(tela, cor("vitrine.vidro"), pilar)
            pygame.draw.rect(tela, cor("neutros.branco"), pilar.inflate(-8, 0))
        if self._puxando():
            origem = _olho(self.caixa)
            for numero in range(self.dados["fios"]):
                destino = (self.jogador[0] + numero * 2 - self.dados["fios"], self.jogador[1])
                pygame.draw.line(tela, cor("vitrine.vidro"), origem, destino)
        for golpe in self.golpes:
            area = self._area_do_golpe(golpe)
            if golpe["aviso"] > 0:
                if int(golpe["aviso"] * 12) % 2 == 0:
                    pygame.draw.rect(tela, cor("vitrine.rosa"), area, 1)
            else:
                pygame.draw.rect(tela, cor("vitrine.rosa"), area)


# 12
class RotaOtima(Padrao):
    """A mira não segue a mini Ada: ela calcula onde a mini Ada vai estar. Quem mantém a direção entra no raio."""

    depende_do_jogador = True

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.restantes = self.dados["focos"]
        self.fase = "mira"
        self.tempo_fase = 0.0
        self.mira = alvo or caixa.center
        self.ultimo_x = None
        self.velocidade = 0.0

    def _angulo(self):
        origem = _olho(self.caixa)
        return math.atan2(self.mira[1] - origem[1], self.mira[0] - origem[0])

    def _calcular_mira(self, dt):
        if not self.jogador:
            return
        if self.ultimo_x is not None and dt > 0:
            # Uma média curta: um toque rápido no teclado não engana a conta.
            self.velocidade += ((self.jogador[0] - self.ultimo_x) / dt - self.velocidade) * 0.25
        self.ultimo_x = self.jogador[0]
        x = self.jogador[0] + self.velocidade * self.dados["previsao"]
        self.mira = (int(max(self.caixa.left + 4, min(x, self.caixa.right - 4))), self.jogador[1])

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        if self.fase == "mira":
            self._calcular_mira(dt)
            if self.tempo_fase >= self.dados["seguir"]:
                self.fase, self.tempo_fase = "travada", 0.0
        elif self.fase == "travada" and self.tempo_fase >= self.dados["aviso"]:
            self.fase, self.tempo_fase = "ativo", 0.0
        elif self.fase == "ativo" and self.tempo_fase >= self.dados["ativo"]:
            self.restantes -= 1
            self.tempo_fase = 0.0
            self.fase = "mira" if self.restantes > 0 else "fim"

    def terminou(self):
        return self.fase == "fim"

    def perigos(self):
        if self.fase != "ativo":
            return []
        return _raio(_olho(self.caixa), self._angulo(), self.caixa, self.dados["largura_do_raio"])

    def desenhar(self, tela):
        origem = _olho(self.caixa)
        if self.fase == "mira":
            pygame.draw.circle(tela, cor("neutros.gelo"), self.mira, 7, 1)
            pygame.draw.line(tela, cor("neutros.gelo"), (self.mira[0] - 3, self.mira[1]), (self.mira[0] + 3, self.mira[1]))
        elif self.fase == "travada":
            angulo = self._angulo()
            fim = (origem[0] + math.cos(angulo) * ALCANCE_DA_LINHA, origem[1] + math.sin(angulo) * ALCANCE_DA_LINHA)
            if int(self.tempo_fase * 14) % 2 == 0:
                pygame.draw.line(tela, cor("vitrine.rosa"), origem, fim, self.dados["largura_do_raio"] // 3)
            pygame.draw.circle(tela, cor("vitrine.rosa"), self.mira, 7, 1)
        elif self.fase == "ativo":
            for area in self.perigos():
                pygame.draw.rect(tela, cor("vitrine.vidro"), area)


# 13
class DecisaoEmLote(Padrao):
    """Pedaços do chão piscam em ordem e depois explodem na mesma ordem. Todos ficam marcados, mas a ordem é preciso lembrar."""

    COLUNAS = 8

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.sequencia = self.sorte.sample(range(self.COLUNAS), self.dados["sequencia"])
        if alvo:
            coluna = max(0, min(self.COLUNAS - 1, (alvo[0] - caixa.left) * self.COLUNAS // caixa.width))
            if coluna in self.sequencia:
                self.sequencia.remove(coluna)
            self.sequencia[0] = coluna
        self.fase = "mostrando"
        self.tempo_fase = 0.0
        self.indice = 0

    def _duracao_da_fase(self):
        return {"mostrando": self.dados["mostrar"] * len(self.sequencia), "espera": self.dados["aviso"], "golpes": self.dados["golpe"]}[self.fase]

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        if self.fase == "fim" or self.tempo_fase < self._duracao_da_fase():
            return
        self.tempo_fase = 0.0
        if self.fase == "mostrando":
            self.fase = "espera"
        elif self.fase == "espera":
            self.fase = "golpes"
        else:
            self.indice += 1
            if self.indice >= len(self.sequencia):
                self.fase = "fim"

    def terminou(self):
        return self.fase == "fim"

    def _coluna(self, indice):
        largura = self.caixa.width // self.COLUNAS
        return pygame.Rect(self.caixa.left + indice * largura, self.caixa.top, largura, self.caixa.height)

    def _explodindo(self):
        return self.fase == "golpes" and self.tempo_fase >= self.dados["golpe"] - self.dados["ativo"]

    def perigos(self):
        return [self._coluna(self.sequencia[self.indice])] if self._explodindo() else []

    def desenhar(self, tela):
        if self.fase == "fim":
            return
        restantes = self.sequencia if self.fase != "golpes" else self.sequencia[self.indice:]
        for numero in restantes:
            r = self._coluna(numero)
            pygame.draw.rect(tela, cor("vitrine.rosa_escuro"), (r.left + 1, self.caixa.bottom - 3, r.width - 2, 3))
        if self.fase == "mostrando":
            atual = min(int(self.tempo_fase / self.dados["mostrar"]), len(self.sequencia) - 1)
            r = self._coluna(self.sequencia[atual])
            pygame.draw.rect(tela, cor("vitrine.rosa"), r, 1)
            _desenhar_texto(self, tela, str(atual + 1), r.left + 8, r.top + 8, "vitrine.rosa")
        elif self.fase == "golpes":
            r = self._coluna(self.sequencia[self.indice])
            if self._explodindo():
                pygame.draw.rect(tela, cor("vitrine.rosa"), r)
                pygame.draw.rect(tela, cor("neutros.branco"), r.inflate(-10, 0))
            else:
                pygame.draw.rect(tela, cor("vitrine.rosa"), r, 1)


# 14
class CaixaPreta(ComItens):
    """Dados entram num bloco opaco e saem do outro lado. Quem entra alto sai baixo: é preciso deduzir a regra."""

    LARGURA_DO_BLOCO = 36
    ALTURA_ALTA = 34

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.bloco = pygame.Rect(caixa.centerx - self.LARGURA_DO_BLOCO // 2, caixa.top, self.LARGURA_DO_BLOCO, caixa.height)
        self.restantes = self.dados["dados"]
        self.proximo = self.dados["aviso"]
        self.enviados = 0

    def _altura(self, alta):
        altura = self.dados["altura_do_dado"]
        return self.caixa.bottom - self.ALTURA_ALTA if alta else self.caixa.bottom - altura - 1

    def _enviar(self):
        # A cada dois dados, o sentido muda: o jogador vê a entrada de um lado e a saída do outro.
        sentido = 1 if (self.enviados // 2) % 2 == 0 else -1
        self.enviados += 1
        alta = self.sorte.random() < 0.5
        largura = self.dados["largura_do_dado"]
        x = self.caixa.left - largura if sentido > 0 else self.caixa.right
        self._agendar(x=float(x), y=self._altura(alta), l=largura, a=self.dados["altura_do_dado"], vx=sentido * self.dados["velocidade"], alta=alta, trocou=False)

    def atualizar(self, dt):
        super().atualizar(dt)
        self.proximo -= dt
        if self.proximo <= 0 and self.restantes > 0:
            self.restantes -= 1
            self.proximo += self.dados["intervalo"]
            self._enviar()
        self._mover_itens(dt)
        for item in self.itens:
            passou = item["x"] + item["l"] / 2 > self.bloco.centerx if item["vx"] > 0 else item["x"] + item["l"] / 2 < self.bloco.centerx
            if passou and not item["trocou"]:
                item["trocou"] = True
                item["alta"] = not item["alta"]
                item["y"] = self._altura(item["alta"])
        # Quem saiu da caixa já cumpriu o trajeto.
        self.itens = [i for i in self.itens if i.get("aviso", 0) > 0 or (self.caixa.left - i["l"] <= i["x"] <= self.caixa.right)]

    def terminou(self):
        return self.restantes <= 0 and not self.itens

    def _visivel(self, item):
        return not self.bloco.colliderect(self._retangulo(item))

    def perigos(self):
        lista = [self._retangulo(i).inflate(-2, -2) for i in self.itens if i.get("aviso", 0) <= 0 and self._visivel(i)]
        if self.tempo >= self.dados["aviso"] and not self.terminou():
            lista.append(self.bloco)
        return lista

    def desenhar(self, tela):
        if self.tempo < self.dados["aviso"]:
            if int(self.tempo * 12) % 2 == 0:
                pygame.draw.rect(tela, cor("vitrine.rosa"), self.bloco, 1)
        elif not self.terminou():
            pygame.draw.rect(tela, cor("neutros.tinta"), self.bloco)
            pygame.draw.rect(tela, cor("vitrine.rosa"), self.bloco, 1)
            _desenhar_texto(self, tela, "?", self.bloco.centerx - 3, self.bloco.centery - 8, "vitrine.rosa")
        for item in self.itens:
            if item.get("aviso", 0) <= 0 and self._visivel(item):
                r = self._retangulo(item)
                pygame.draw.rect(tela, cor("vitrine.rosa"), r)
                pygame.draw.rect(tela, cor("neutros.branco"), r.inflate(-4, -4))


# 15
class AguardandoAprovacao(Padrao):
    """Com a placa AGUARDE, quem anda é atingido, mas pular é permitido. Com AVANCE, o lugar onde ela parou explode."""

    depende_do_jogador = True

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.ciclos = self.dados["ciclos"]
        self.fase = "aviso"
        self.tempo_fase = 0.0
        self.travado_x = caixa.centerx
        self.golpes = []

    def sem_puxao(self):
        return self.fase == "travado"

    def _preparar_golpes(self):
        largura = self.dados["largura_do_golpe"]
        metade = largura // 2
        c = self.caixa
        self.golpes = [max(c.left + metade, min(self.travado_x, c.right - metade))]
        for _ in range(self.dados["golpes"] - 1):
            # Os outros golpes ficam longe uns dos outros: sempre sobra para onde correr.
            for _tentativa in range(30):
                x = self.sorte.randint(c.left + metade, c.right - metade)
                if all(abs(x - outro) >= largura + 26 for outro in self.golpes):
                    self.golpes.append(x)
                    break

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        if self.fase == "aviso" and self.tempo_fase >= self.dados["aviso"]:
            self.fase, self.tempo_fase = "travado", 0.0
            self.travado_x = self.jogador[0] if self.jogador else self.caixa.centerx
        elif self.fase == "travado" and self.tempo_fase >= self.dados["travado"]:
            self.fase, self.tempo_fase = "avance", 0.0
            self._preparar_golpes()
        elif self.fase == "avance" and self.tempo_fase >= self.dados["aviso_do_golpe"]:
            self.fase, self.tempo_fase = "golpe", 0.0
        elif self.fase == "golpe" and self.tempo_fase >= self.dados["ativo"]:
            self.ciclos -= 1
            self.tempo_fase = 0.0
            self.fase = "aviso" if self.ciclos > 0 else "fim"

    def terminou(self):
        return self.fase == "fim"

    def _lados_proibidos(self):
        c = self.caixa
        margem = self.dados["margem"]
        return [
            pygame.Rect(c.left, c.top, max(0, self.travado_x - margem - c.left), c.height),
            pygame.Rect(self.travado_x + margem, c.top, max(0, c.right - self.travado_x - margem), c.height),
        ]

    def _area_do_golpe(self, x):
        largura = self.dados["largura_do_golpe"]
        return pygame.Rect(x - largura // 2, self.caixa.top, largura, self.caixa.height)

    def perigos(self):
        if self.fase == "travado":
            return self._lados_proibidos()
        if self.fase == "golpe":
            return [self._area_do_golpe(x) for x in self.golpes]
        return []

    def desenhar(self, tela):
        c = self.caixa
        if self.fase == "aviso":
            if int(self.tempo_fase * 10) % 2 == 0:
                _desenhar_texto(self, tela, self.dados["texto_aguarde"], c.centerx - 26, c.top + 2, "vitrine.rosa")
        elif self.fase == "travado":
            _desenhar_texto(self, tela, self.dados["texto_aguarde"], c.centerx - 26, c.top + 2, "neutros.branco")
            for area in self._lados_proibidos():
                for y in range(area.top, area.bottom, 6):
                    pygame.draw.line(tela, cor("vitrine.rosa"), (area.left, y), (area.right - 1, y))
        elif self.fase in ("avance", "golpe"):
            _desenhar_texto(self, tela, self.dados["texto_avance"], c.centerx - 24, c.top + 2, "vila.sol")
            for x in self.golpes:
                area = self._area_do_golpe(x)
                if self.fase == "golpe":
                    pygame.draw.rect(tela, cor("vitrine.rosa"), area)
                elif int(self.tempo_fase * 12) % 2 == 0:
                    pygame.draw.rect(tela, cor("vitrine.rosa"), area, 1)


# 16
class IssoTambemEDado(Padrao):
    """Por onde a mini Ada passa, fica uma marca que explode depois. Até ficar parada deixa marca: tudo vira dado."""

    depende_do_jogador = True
    PASSOS_PARA_MARCAR = 6

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.marcas = []
        self.proxima = 0.0
        self.tempo_parada = 0.0
        self.ultimo_x = None

    def _marcar(self, x):
        self.marcas.append({"x": x, "aviso": self.dados["aviso"], "ativo": self.dados["ativo"]})

    def atualizar(self, dt):
        super().atualizar(dt)
        for marca in self.marcas:
            if marca["aviso"] > 0:
                marca["aviso"] -= dt
            else:
                marca["ativo"] -= dt
        self.marcas = [m for m in self.marcas if m["ativo"] > 0]
        self.proxima -= dt
        self.tempo_parada += dt
        if self.jogador is None or self.tempo >= self.dados["duracao"] or self.proxima > 0:
            return
        x = self.jogador[0]
        andou = self.ultimo_x is None or abs(x - self.ultimo_x) >= self.PASSOS_PARA_MARCAR
        if andou or self.tempo_parada >= self.dados["tempo_parada"]:
            self._marcar(x)
            self.ultimo_x = x
            self.tempo_parada = 0.0
            self.proxima = self.dados["intervalo"]

    def terminou(self):
        return self.tempo >= self.dados["duracao"] and not self.marcas

    def _area(self, marca):
        largura = self.dados["largura_da_marca"]
        altura = self.dados["altura_da_marca"]
        return pygame.Rect(marca["x"] - largura // 2, self.caixa.bottom - altura, largura, altura)

    def perigos(self):
        return [self._area(m) for m in self.marcas if m["aviso"] <= 0]

    def desenhar(self, tela):
        for marca in self.marcas:
            area = self._area(marca)
            if marca["aviso"] > 0:
                pygame.draw.rect(tela, cor("vitrine.rosa_escuro"), (area.left, self.caixa.bottom - 3, area.width, 3))
                if int(marca["aviso"] * 14) % 2 == 0:
                    pygame.draw.rect(tela, cor("vitrine.rosa"), area, 1)
            else:
                pygame.draw.rect(tela, cor("vitrine.rosa"), area)
                pygame.draw.rect(tela, cor("neutros.branco"), area.inflate(-4, -4))


# 17
class CamaraEmOrbita(Padrao):
    """O chão queima, e só as plataformas em órbita salvam. Quem pisa é levado, e a plataforma some na parede: é preciso trocar."""

    depende_do_jogador = True
    ALTURA_DA_FILEIRA_BAIXA = 26
    ALTURA_DA_FILEIRA_ALTA = 50
    ALTURA_DO_FOGO = 6

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.andado = 0.0
        self.passo_x = 0.0

    def atualizar(self, dt):
        super().atualizar(dt)
        self.passo_x = self.dados["velocidade"] * dt
        self.andado += self.passo_x

    def terminou(self):
        return self.tempo >= self.dados["duracao"]

    def _posicao(self, numero):
        """O caminho é uma órbita achatada: para a direita na fileira de baixo e para a esquerda na de cima."""
        c = self.caixa
        volta = 2 * c.width
        andado = (self.andado + numero * volta / self.dados["plataformas"]) % volta
        if andado < c.width:
            return c.left + andado, c.bottom - self.ALTURA_DA_FILEIRA_BAIXA
        return c.right - (andado - c.width), c.bottom - self.ALTURA_DA_FILEIRA_ALTA

    def plataformas(self):
        largura = self.dados["largura_plataforma"]
        lista = []
        for numero in range(self.dados["plataformas"]):
            x, y = self._posicao(numero)
            lista.append(pygame.Rect(int(x) - largura // 2, int(y), largura, 4))
        return lista

    def carregar_corpo(self, corpo, dt, plataformas):
        if not corpo.no_chao:
            return
        base = corpo.y + corpo.altura
        for plataforma in plataformas:
            if base == plataforma.top and corpo.x + corpo.largura > plataforma.left and corpo.x < plataforma.right:
                baixa = plataforma.top == self.caixa.bottom - self.ALTURA_DA_FILEIRA_BAIXA
                corpo.x += self.passo_x if baixa else -self.passo_x
                return

    def perigos(self):
        if self.dados["aviso"] <= self.tempo < self.dados["duracao"]:
            c = self.caixa
            return [pygame.Rect(c.left, c.bottom - self.ALTURA_DO_FOGO, c.width, self.ALTURA_DO_FOGO)]
        return []

    def desenhar(self, tela):
        c = self.caixa
        for plataforma in self.plataformas():
            pygame.draw.rect(tela, cor("vitrine.ciano"), plataforma)
        if self.tempo < self.dados["aviso"]:
            if int(self.tempo * 12) % 2 == 0:
                pygame.draw.rect(tela, cor("vitrine.rosa"), (c.left, c.bottom - self.ALTURA_DO_FOGO, c.width, self.ALTURA_DO_FOGO), 1)
        else:
            for r in self.perigos():
                pygame.draw.rect(tela, cor("vitrine.rosa"), r)


# 18
class QuemPagaAConta(EmOndas):
    """Não há saída de graça: um lado tira vida, e o outro tira AUTONOMIA. O jogador escolhe quem paga. Sem AUTONOMIA, os dois tiram vida."""

    def iniciar(self, caixa, alvo=None):
        self.luta = None
        self.tempo_do_pagamento = 0.0
        self.lado_da_vida = 1
        super().iniciar(caixa, alvo)

    def receber_luta(self, luta):
        super().receber_luta(luta)
        self.luta = luta

    def _nova_onda(self):
        self.lado_da_vida = -self.lado_da_vida if self.onda else self.sorte.choice((-1, 1))

    def _lado(self, sentido):
        c = self.caixa
        if sentido < 0:
            return pygame.Rect(c.left, c.top, c.width // 2, c.height)
        return pygame.Rect(c.centerx, c.top, c.right - c.centerx, c.height)

    def _sem_como_pagar(self):
        return self.luta is not None and self.luta.autonomia < self.dados["custo"]

    def _areas(self):
        if self._sem_como_pagar():
            return [self._lado(-1), self._lado(1)]
        return [self._lado(self.lado_da_vida)]

    def _cobrar(self):
        if self.luta is None or self.jogador is None or self._sem_como_pagar():
            return
        lado_do_jogador = 1 if self.jogador[0] >= self.caixa.centerx else -1
        if lado_do_jogador != self.lado_da_vida:
            self.luta.perder_autonomia(self.dados["custo"])
            self.tempo_do_pagamento = self.dados["ativo"]

    def atualizar(self, dt):
        antes = self.fase
        super().atualizar(dt)
        self.tempo_do_pagamento = max(0.0, self.tempo_do_pagamento - dt)
        if antes == "aviso" and self.fase == "ativo":
            self._cobrar()

    def desenhar(self, tela):
        if self.fase == "fim":
            return
        super().desenhar(tela)
        vida = self._lado(self.lado_da_vida)
        outro = self._lado(-self.lado_da_vida)
        _desenhar_texto(self, tela, self.dados["texto_vida"], vida.centerx - 12, vida.top + 2, "vitrine.rosa")
        _desenhar_texto(self, tela, self.dados["texto_autonomia"], outro.centerx - 32, outro.top + 2, "vitrine.vidro")
        if self.tempo_do_pagamento > 0:
            pygame.draw.rect(tela, cor("vitrine.vidro"), outro, 2)


# 19
class RemovendoLimites(Padrao):
    """A gravidade inverte, com aviso, e o teto vira chão. O perigo fica onde a mini Ada vai cair: é preciso chegar antes."""

    depende_do_jogador = True

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        self.invertida = False
        self.inversoes = self.dados["inversoes"]
        self.fase = "aviso"
        self.tempo_fase = 0.0
        self._novas_pontas()

    def gravidade_invertida(self):
        return self.invertida

    def _novas_pontas(self):
        """As pontas ficam com o mesmo espaço entre elas, para sempre sobrar uma brecha de pelo menos 24 pixels."""
        c = self.caixa
        quantas = self.dados["pontas"]
        faixa = c.width // quantas
        largura = min(self.dados["largura_das_pontas"], faixa - 24)
        deslocamento = self.sorte.randint(0, faixa - largura)
        altura = self.dados["altura_das_pontas"]
        # O destino é o lado oposto ao que está valendo agora.
        y = c.bottom - altura if self.invertida else c.top
        self.pontas = [pygame.Rect(c.left + numero * faixa + deslocamento, y, largura, altura) for numero in range(quantas)]

    def atualizar(self, dt):
        super().atualizar(dt)
        self.tempo_fase += dt
        if self.fase == "aviso" and self.tempo_fase >= self.dados["aviso"]:
            self.fase, self.tempo_fase = "virada", 0.0
            self.invertida = not self.invertida
        elif self.fase == "virada" and self.tempo_fase >= self.dados["tempo_virada"]:
            self.inversoes -= 1
            self.tempo_fase = 0.0
            if self.inversoes > 0:
                self.fase = "aviso"
                self._novas_pontas()
            else:
                self.fase = "fim"
                self.invertida = False

    def terminou(self):
        return self.fase == "fim"

    def perigos(self):
        return list(self.pontas) if self.fase == "virada" else []

    def desenhar(self, tela):
        if self.fase == "fim":
            return
        c = self.caixa
        if self.fase == "virada":
            for ponta in self.pontas:
                pygame.draw.rect(tela, cor("vitrine.rosa"), ponta)
        elif int(self.tempo_fase * 12) % 2 == 0:
            for ponta in self.pontas:
                pygame.draw.rect(tela, cor("vitrine.rosa"), ponta, 1)
            # A seta diz para onde a mini Ada vai cair.
            sentido = 1 if self.invertida else -1
            y = c.centery - sentido * 8
            pygame.draw.polygon(tela, cor("vitrine.rosa"), [(c.centerx, y + sentido * 16), (c.centerx - 8, y), (c.centerx + 8, y)])


# 20
class TetoDeGastos(EmOndas):
    """O teto desce em degraus. Nas colunas altas cabe tudo, nas médias só dá para ficar no chão, e nas baixas não cabe nada."""

    COLUNAS = 7
    ESPACO_MEDIO = 22
    ESPACO_BAIXO = 8
    TEMPO_DESCENDO = 0.12

    def _nova_onda(self):
        self.centro = 3 if not self.onda else max(0, min(self.COLUNAS - 1, self.centro + self.sorte.randint(-2, 2)))
        altas = self.dados["altas"]
        inicio = max(0, min(self.COLUNAS - altas, self.centro - altas // 2))
        self.altas = set(range(inicio, inicio + altas))
        self.medias = {c for c in (inicio - 1, inicio + altas) if 0 <= c < self.COLUNAS}

    def _largura(self):
        return self.caixa.width // self.COLUNAS

    def _espaco(self, coluna):
        if coluna in self.altas:
            return None
        return self.ESPACO_MEDIO if coluna in self.medias else self.ESPACO_BAIXO

    def _colunas(self, fracao=1.0):
        c = self.caixa
        lista = []
        for coluna in range(self.COLUNAS):
            espaco = self._espaco(coluna)
            if espaco is not None:
                altura = int((c.height - espaco) * fracao)
                lista.append(pygame.Rect(c.left + coluna * self._largura(), c.top, self._largura(), altura))
        return lista

    def _areas(self):
        return self._colunas(min(1.0, self.tempo_fase / self.TEMPO_DESCENDO))

    def desenhar(self, tela):
        if self.fase == "fim":
            return
        if self.fase == "aviso":
            if int(self.tempo_fase * 12) % 2 == 0:
                for r in self._colunas():
                    pygame.draw.line(tela, cor("vitrine.rosa"), (r.left, r.bottom), (r.right - 1, r.bottom), 2)
        elif self.fase == "ativo":
            for r in self._areas():
                pygame.draw.rect(tela, cor("vitrine.rosa_escuro"), r)
                pygame.draw.rect(tela, cor("vitrine.rosa"), (r.left, r.bottom - 2, r.width, 2))


class AtaqueCombinado(Padrao):
    """Dois ataques ao mesmo tempo, escolhidos porque um aperta o que o outro pede (D69). Vale tudo o que cada um faz.

    Somados, eles pesam mais: por isso, cada parte sobe de nível mais devagar, e "ajustes" pode deixar uma parte mais leve.
    """

    depende_do_jogador = True

    def __init__(self, dados, sorte=None):
        from src.batalha.padroes import PADROES, dados_da_forma, dados_no_nivel

        self.partes = []
        super().__init__(dados, sorte)
        nivel = int(dados["nivel_das_partes"])
        for nome, parte in zip(dados["partes"], dados["dados_das_partes"]):
            numeros = {**dados_da_forma(parte, 2), **dados.get("ajustes", {}).get(nome, {})}
            self.partes.append(PADROES[nome](dados_no_nivel(numeros, nivel), self.sorte))

    @property
    def fator(self):
        return self._fator

    @fator.setter
    def fator(self, valor):
        self._fator = valor
        for parte in self.partes:
            parte.fator = valor

    def _ativas(self):
        return [parte for parte in self.partes if not parte.terminou()]

    def iniciar(self, caixa, alvo=None):
        super().iniciar(caixa, alvo)
        for parte in self.partes:
            parte.fonte = self.fonte
            parte.iniciar(caixa, alvo if parte is self.partes[0] else None)

    def ver_jogador(self, posicao):
        super().ver_jogador(posicao)
        for parte in self.partes:
            parte.ver_jogador(posicao)

    def receber_luta(self, luta):
        super().receber_luta(luta)
        for parte in self.partes:
            parte.receber_luta(luta)

    def atualizar(self, dt):
        super().atualizar(dt)
        for parte in self._ativas():
            parte.atualizar(dt)

    def terminou(self):
        return all(parte.terminou() for parte in self.partes)

    def perigos(self):
        return [perigo for parte in self._ativas() for perigo in parte.perigos()]

    def perigos_visiveis(self, centro):
        return [perigo for parte in self._ativas() for perigo in parte.perigos_visiveis(centro)]

    def plataformas(self):
        return [plataforma for parte in self._ativas() for plataforma in parte.plataformas()]

    def empurrao(self):
        return sum(parte.empurrao() for parte in self._ativas())

    def lentidao(self):
        return math.prod(parte.lentidao() for parte in self._ativas())

    def gravidade_invertida(self):
        return any(parte.gravidade_invertida() for parte in self._ativas())

    def sem_puxao(self):
        return any(parte.sem_puxao() for parte in self._ativas())

    def carregar_corpo(self, corpo, dt, plataformas):
        for parte in self._ativas():
            parte.carregar_corpo(corpo, dt, plataformas)

    def antecedencia(self):
        return max(parte.antecedencia() for parte in self.partes)

    def ao_atingir(self):
        for parte in self._ativas():
            parte.ao_atingir()

    def desenhar_avisos(self, tela):
        for parte in self._ativas():
            parte.desenhar_avisos(tela)

    def desenhar(self, tela):
        # A primeira parte fica atrás: é assim que o escuro do Protocolo Desligado nunca cobre o que vem depois.
        for parte in self._ativas():
            parte.desenhar(tela)

    def desenhar_por_cima(self, tela):
        for parte in self._ativas():
            parte.desenhar_por_cima(tela)


ATAQUES_COMBINADOS_DA_IRIS = {
    "puxao_calculado": AtaqueCombinado,
    "carona_na_mira": AtaqueCombinado,
    "sem_lugar_neutro": AtaqueCombinado,
    "apagao_de_gastos": AtaqueCombinado,
    "corte_e_ricochete": AtaqueCombinado,
}

ATAQUES_NOVOS_DA_IRIS = {
    "fio_guia": FioGuia,
    "rota_otima": RotaOtima,
    "decisao_em_lote": DecisaoEmLote,
    "caixa_preta": CaixaPreta,
    "aguardando_aprovacao": AguardandoAprovacao,
    "isso_tambem_e_dado": IssoTambemEDado,
    "camara_em_orbita": CamaraEmOrbita,
    "quem_paga_a_conta": QuemPagaAConta,
    "removendo_limites": RemovendoLimites,
    "teto_de_gastos": TetoDeGastos,
}
