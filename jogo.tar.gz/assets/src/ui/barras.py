"""Barras de vida, energia, Integridade e Estabilidade."""

import pygame

from src.sistemas.cores import cor


def desenhar_barra(tela, retangulo, fracao, cor_cheia):
    """fracao vai de 0 a 1. A barra tem uma borda fina e o fundo escuro."""
    area = pygame.Rect(retangulo)
    pygame.draw.rect(tela, cor("neutros.gelo"), area)
    pygame.draw.rect(tela, cor("neutros.tinta"), area.inflate(-2, -2))
    interior = area.inflate(-2, -2)
    largura = int(interior.width * max(0.0, min(1.0, fracao)))
    if fracao > 0 and largura == 0:
        largura = 1  # Enquanto restar qualquer coisa, a barra mostra pelo menos um pixel.
    pygame.draw.rect(tela, cor_cheia, (interior.left, interior.top, largura, interior.height))
