"""Telas que aparecem acima da caixa de fala: documento, tabela e gráfico de barras (data/telas.json).

São as provas da Fase 1: o pedido negado do Jonas, os pedidos gêmeos, o gráfico do Arquivo e a
tabela dos drones. Ficam desenhadas em papel claro, para parecerem documentos de verdade.
"""

import pygame

from src.sistemas.cores import cor
from src.sistemas.textos import resolver
from src.ui.caixa_texto import desenhar_caixa

AREA = pygame.Rect(16, 6, 288, 92)  # Acima da etiqueta com o nome de quem fala.
ALTURA_LINHA = 12


def desenhar_tela(tela, fonte, dados, nome_jogador):
    """Desenha uma tela de telas.json conforme o "tipo"."""
    tipo = dados.get("tipo")
    if tipo == "documento":
        _documento(tela, fonte, dados, nome_jogador)
    elif tipo == "tabela":
        _tabela(tela, fonte, dados, nome_jogador)
    elif tipo == "barras":
        _barras(tela, fonte, dados, nome_jogador)


def _papel(tela, fonte, largura, altura):
    caixa = pygame.Rect(0, 0, largura, altura)
    caixa.center = AREA.center
    desenhar_caixa(tela, caixa, fonte.cores["claro_texto"], fonte.cores["claro_fundo"])
    return caixa


def _escrever(tela, fonte, x, y, texto, destaque=False):
    if destaque:
        fonte.desenhar(tela, x, y, texto, cor("balanca.vinho_carimbo"), fonte.cores["claro_sombra"])
    else:
        fonte.desenhar(tela, x, y, texto, fonte.cores["claro_texto"], fonte.cores["claro_sombra"])


def _documento(tela, fonte, dados, nome):
    linhas = [resolver(linha, nome) for linha in dados["linhas"]]
    largura = max(fonte.largura(linha) for linha in linhas) + 24
    caixa = _papel(tela, fonte, largura, len(linhas) * ALTURA_LINHA + 12)
    for i, linha in enumerate(linhas):
        # A primeira linha é o título, e as que dizem o resultado ficam em vermelho, como um carimbo.
        destaque = i == 0 or "NEGADO" in linha
        _escrever(tela, fonte, caixa.left + 12, caixa.top + 6 + i * ALTURA_LINHA, linha, destaque)


def _tabela(tela, fonte, dados, nome):
    colunas = [resolver(c, nome) for c in dados["colunas"]]
    linhas = [[resolver(c, nome) for c in linha] for linha in dados["linhas"]]
    todas = [colunas] + linhas
    larguras = [max(fonte.largura(linha[i]) for linha in todas) + 10 for i in range(len(colunas))]
    caixa = _papel(tela, fonte, sum(larguras) + 12, len(todas) * ALTURA_LINHA + 10)
    y = caixa.top + 5
    for numero, linha in enumerate(todas):
        x = caixa.left + 6
        for i, celula in enumerate(linha):
            destaque = numero == 0 or celula in ("NEGADO", "APROVADO")
            _escrever(tela, fonte, x, y, celula, destaque)
            x += larguras[i]
        if numero == 0:
            pygame.draw.line(tela, fonte.cores["claro_sombra"], (caixa.left + 4, y + ALTURA_LINHA - 1), (caixa.right - 5, y + ALTURA_LINHA - 1))
        y += ALTURA_LINHA


def _barras(tela, fonte, dados, nome):
    barras = dados["barras"]
    caixa = _papel(tela, fonte, 240, 34 + len(barras) * 18)
    _escrever(tela, fonte, caixa.left + 10, caixa.top + 6, resolver(dados["titulo"], nome), True)
    rotulos = [resolver(b["rotulo"], nome) for b in barras]
    x_barra = caixa.left + 14 + max(fonte.largura(r) for r in rotulos)
    largura_maxima = caixa.right - 40 - x_barra
    for i, barra in enumerate(barras):
        y = caixa.top + 24 + i * 18
        _escrever(tela, fonte, caixa.left + 10, y, rotulos[i])
        largura = int(largura_maxima * barra["valor"] / 100)
        pygame.draw.rect(tela, cor("balanca.vinho_carimbo" if barra["valor"] >= 50 else "balanca.ocre"), (x_barra, y + 2, largura, 8))
        _escrever(tela, fonte, x_barra + largura + 4, y, barra["texto"])
