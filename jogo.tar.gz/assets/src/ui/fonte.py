"""Desenha texto com a fonte própria do jogo, lida de assets/fontes/fonte_jogo.json (D35)."""

import math

import pygame

from src.sistemas.recursos import ler_json

Y_BASE_PADRAO = 2


class Fonte:
    def __init__(self):
        dados = ler_json("assets/fontes/fonte_jogo.json")
        self.altura_linha = dados["altura_linha"]
        self.espaco = dados["espaco_entre_letras"]
        self.sombra_dx = dados["sombra"]["dx"]
        self.sombra_dy = dados["sombra"]["dy"]
        self.cores = dados["cores"]
        self._glifos = {}
        self._cache = {}
        self._montar_glifos(dados)

    def _pixels(self, linhas, x0, y0):
        return [
            (x0 + c, y0 + r)
            for r, linha in enumerate(linhas)
            for c, valor in enumerate(linha)
            if valor == "#"
        ]

    def _montar_glifos(self, dados):
        y_glifo = dados.get("y_glifo", Y_BASE_PADRAO)
        for glifo in dados["glifos"]:
            linhas = glifo["linhas"]
            self._glifos[glifo["c"]] = {
                "largura": max(len(linha) for linha in linhas),
                "pixels": self._pixels(linhas, 0, y_glifo),
            }

        # Letras com acento são a letra básica + o desenho do acento ou da cedilha.
        for composto in dados["compostos"]:
            base = self._glifos[composto["base"]]
            acento = dados["acentos"][composto["acento"]]
            largura_acento = max(len(linha) for linha in acento)
            if composto["acento"] == "cedilha":
                y0 = dados["y_cedilha"]
            elif composto["base"].isupper():
                y0 = dados["y_acento_maiuscula"]
            else:
                y0 = dados["y_acento_minuscula"]
            x0 = max(0, math.ceil((base["largura"] - largura_acento) / 2))
            self._glifos[composto["c"]] = {
                "largura": max(base["largura"], x0 + largura_acento),
                "pixels": base["pixels"] + self._pixels(acento, x0, y0),
            }

    def _glifo(self, letra):
        return self._glifos.get(letra, self._glifos["?"])

    def largura(self, texto):
        if not texto:
            return 0
        return sum(self._glifo(letra)["largura"] + self.espaco for letra in texto) - self.espaco

    def _superficie_da_letra(self, letra, cor):
        """Guarda cada letra pronta em cada cor, para não redesenhar pixel a pixel a cada quadro."""
        chave = (letra, cor)
        if chave not in self._cache:
            glifo = self._glifo(letra)
            superficie = pygame.Surface((glifo["largura"], self.altura_linha), pygame.SRCALPHA)
            for ponto in glifo["pixels"]:
                superficie.set_at(ponto, pygame.Color(cor))
            self._cache[chave] = superficie
        return self._cache[chave]

    def _escrever(self, tela, x, y, texto, cor):
        for letra in texto:
            tela.blit(self._superficie_da_letra(letra, cor), (x, y))
            x += self._glifo(letra)["largura"] + self.espaco

    def desenhar(self, tela, x, y, texto, cor=None, sombra=None):
        """Escreve o texto. Por padrão, usa as cores da fonte: branco com sombra cinza."""
        cor = cor or self.cores["texto"]
        sombra = sombra or self.cores["sombra"]
        self._escrever(tela, x + self.sombra_dx, y + self.sombra_dy, texto, sombra)
        self._escrever(tela, x, y, texto, cor)

    def desenhar_centralizado(self, tela, y, texto, cor=None, sombra=None):
        self.desenhar(tela, (tela.get_width() - self.largura(texto)) // 2, y, texto, cor, sombra)

    def grande(self, texto, escala, cor=None, sombra=None):
        """Devolve o texto ampliado, para títulos. Os pixels continuam quadrados, sem borrar."""
        superficie = pygame.Surface((self.largura(texto) + self.sombra_dx, self.altura_linha + self.sombra_dy), pygame.SRCALPHA)
        self.desenhar(superficie, 0, 0, texto, cor, sombra)
        largura, altura = superficie.get_size()
        return pygame.transform.scale(superficie, (largura * escala, altura * escala))
