"""Lista de opções com cursor, usada no título, no menu de pausa e nas configurações."""

import pygame

from src.ui.caixa_texto import desenhar_caixa

ALTURA_OPCAO = 13


class ListaDeOpcoes:
    def __init__(self, textos, desativadas=()):
        self.textos = list(textos)
        self.desativadas = set(desativadas)
        self.indice = 0

    def mover(self, passo):
        self.indice = (self.indice + passo) % len(self.textos)

    def tratar_acao(self, acao):
        """Move o cursor com as setas. Devolve o índice escolhido ao confirmar, ou None."""
        if acao == "cima":
            self.mover(-1)
        elif acao == "baixo":
            self.mover(1)
        elif acao == "confirmar":
            return self.indice
        return None

    def opcao_no_ponto(self, ponto, x, y, largura):
        """Diz qual opção está embaixo do mouse, para dar para escolher clicando."""
        for i in range(len(self.textos)):
            if pygame.Rect(x, y + i * ALTURA_OPCAO, largura, ALTURA_OPCAO).collidepoint(ponto):
                return i
        return None

    def largura(self, fonte):
        return max(fonte.largura(texto) for texto in self.textos) + 22

    def altura(self):
        return len(self.textos) * ALTURA_OPCAO + 8

    def desenhar(self, tela, fonte, x, y, com_caixa=True):
        """Desenha a lista. O cursor é o ▶, como nas escolhas dos diálogos."""
        if com_caixa:
            caixa = pygame.Rect(x, y, self.largura(fonte), self.altura())
            desenhar_caixa(tela, caixa, fonte.cores["borda_caixa"], fonte.cores["fundo_caixa"])
        for i, texto in enumerate(self.textos):
            linha_y = y + 4 + i * ALTURA_OPCAO
            if i in self.desativadas:
                cor, sombra = fonte.cores["desativado"], fonte.cores["sombra_desativado"]
            elif i == self.indice:
                cor, sombra = fonte.cores["selecionado"], fonte.cores["sombra"]
            else:
                cor, sombra = fonte.cores["texto"], fonte.cores["sombra"]
            if i == self.indice:
                fonte.desenhar(tela, x + 6, linha_y, "▶", cor, sombra)
            fonte.desenhar(tela, x + 14, linha_y, texto, cor, sombra)
