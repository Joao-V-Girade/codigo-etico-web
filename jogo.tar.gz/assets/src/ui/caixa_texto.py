"""Desenha as caixas da interface e quebra o texto em linhas, medindo com a fonte do jogo."""

import pygame


def desenhar_caixa(tela, retangulo, cor_borda, cor_fundo, espessura=2):
    pygame.draw.rect(tela, cor_borda, retangulo)
    pygame.draw.rect(tela, cor_fundo, pygame.Rect(retangulo).inflate(-2 * espessura, -2 * espessura))


def quebrar_em_linhas(fonte, texto, largura):
    linhas = []
    atual = ""
    for palavra in texto.split(" "):
        tentativa = f"{atual} {palavra}" if atual else palavra
        if fonte.largura(tentativa) <= largura:
            atual = tentativa
        else:
            if atual:
                linhas.append(atual)
            atual = palavra
    if atual:
        linhas.append(atual)
    return linhas


def paginar(fonte, texto, largura, max_linhas):
    """Divide um texto longo em partes que cabem na caixa, sem cortar nenhuma palavra."""
    linhas = quebrar_em_linhas(fonte, texto, largura)
    return [" ".join(linhas[i : i + max_linhas]) for i in range(0, len(linhas), max_linhas)]
